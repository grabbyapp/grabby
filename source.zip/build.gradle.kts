// Top-level build file
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("com.chaquo.python") version "17.2.0" apply false   // runs Python (Flask + yt-dlp) inside the app
}
