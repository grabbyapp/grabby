What's new in Grabby 4.1

- Get the app: download Grabby for Android straight from the website
- Updates: the app tells you when a new version is out
- Photo mode: save every slide of a carousel
- Paste many links at once, or a whole playlist
- Messenger size: videos under 25 MB
- Subtitles, ringtone, GIF and clip maker
- My Videos: folders, sorting, continue watching
- The Grabby tab: daily gift, outfits, sticker album, Hugot of the Day
