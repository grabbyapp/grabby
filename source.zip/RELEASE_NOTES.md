What's new in Grabby 4.3

- YouTube now works in the phone app! Grabby has its own YouTube unlocker built in
- HD videos (720p, 1080p and up) with sound, from YouTube, Reddit, Vimeo and more
- MP3 downloads, trimming, ringtones, GIFs and Messenger-size videos now work on the phone too
- Sign in to sites (Settings): download private posts, Stories and Instagram reliably, using your own account
- The download engine now updates itself, so when a site changes, Grabby keeps working without waiting for a new app
- Clearer messages when a site blocks a download (and what to do about it)
