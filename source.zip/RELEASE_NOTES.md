What's new in Grabby 5.0

- New music player: big play / pause with previous and next, a seek bar, shuffle and repeat
- Music keeps playing when you close the player, with no restart or pause
- Cleaner layout everywhere: tidier buttons, headers and spacing
- Windows: Grabby is now a real PC app with its own window, Start menu and desktop shortcut, and it updates itself
