What's new in Grabby 4.2

- Fixed: the Download button didn't work in the phone app. It works now!
- Downloads are now saved to your phone too (Downloads/Grabby), so they show in your Gallery and music apps
- Copied links: come back to Grabby after copying a link and it offers to download it (or turn on "Download copied links right away")
- New Settings page (gear button at the top): Grabby, downloads, updates and more
- Grabby can fly around the whole app: Settings > How Grabby moves > Always flying. Drag him anywhere!
- Turn Grabby off or hide his speech bubbles in Settings
- Problem report in Settings, to share if a download fails
