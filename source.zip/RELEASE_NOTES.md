What's new in Grabby 4.6

- Grabby now sends a few anonymous counts (the app was opened, a download finished on a site, the Tip button was tapped) so Zypher can see how many people use Grabby and from which country. No names, links, videos or IP addresses. You can turn it off in Settings → App → Send anonymous counts
- Owner Admin page on the PC version: downloads per version, website visitors, countries, app users, tip taps and a log of tips received
