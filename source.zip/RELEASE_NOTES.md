What's new in Grabby 5.1

- Vault: open it with a PIN or your fingerprint / face, not just the password (set it up in the Vault under Unlock options)
- Fixed: the player and buttons no longer go off the edge on smaller phones
- Fixed: deleting videos with very long names (Facebook posts) now works, and long names are shortened
