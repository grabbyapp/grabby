What's new in Grabby 4.4

- NEW Vault: lock videos, music and pictures with a password. They're encrypted, so they never show in your Gallery, Downloads or any other app. Only inside Grabby, after you unlock
- Add to the vault from My Videos (tap ⋯ > Lock in vault, or Select > Vault) or straight from your phone
- The vault locks itself when you leave the app, and blocks screenshots while it's open
- Full screen in the video player: tap the full screen button (or double-tap the video). Wide videos turn your phone sideways
- Fixed the phone layout: the top bar no longer hides under the status bar, Settings have no more big gaps, and the keyboard no longer covers what you type
