What's new in Grabby 4.5

- Vault auto-lock: choose when it locks itself (as soon as you leave the Vault, or after 1, 5 or 15 minutes unused)
- A small countdown shows when it will lock. Any tap, scroll or playing video keeps it open
- It still locks the moment you leave Grabby or turn off your screen
- Tipping in one tap: pick how many coffees, tap "Tip with GCash" or "Tip with Maya". Grabby saves a QR with the amount already in it and opens the app for you
- Phone notifications: a progress bar for every download (with speed, time left and a Cancel button), plus "Downloaded!" with Play / My Videos buttons, or why it failed
- Downloads keep going when you leave the app
- A notification when a new Grabby is out (turn any of these off in Settings)
- The app fits your screen exactly: it no longer slides left and right or zooms by accident, and Grabby's speech bubbles stay on screen
- Incognito Grabby: in the Vault he puts on a fedora, dark shades, a trench coat and a fake moustache, and keeps glancing around 🕵️
- Music keeps playing in the background (other pages, other apps, screen off) until you press Stop, with controls in the notification, on the lock screen and on your headphones
- Fixed: pressing Back (for example in My Videos) could leave Grabby stuck on the loading screen. Back now closes the player or pop-up first, then goes to the page you were on before, and only then leaves the app
- Fixed: the PC app no longer re-reads your GCash QR picture on every page load
- NEW: Grabby for Windows (Grabby-Windows.exe). Download it from the Grabby website; it updates itself like the phone app
