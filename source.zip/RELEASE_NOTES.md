[optional]
What's new in Grabby 4.9

- Just fixing small bugs
