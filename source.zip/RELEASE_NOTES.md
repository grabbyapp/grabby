What's new in Grabby 5.2

- Direct Download to Vault: flip "Save straight to Vault" to encrypt downloads straight into your Vault without touching My Videos, History, or your Gallery
- Dark Mode: switch between Auto, Light, and Dark in Settings (with matching Android status & navigation bars)
- Playback Speed & Music Sleep Timer: adjust speed (0.5x to 2x) for videos and songs, and set a sleep timer (15–60 min or End of song) that gently fades out music
- My Videos tools: extract MP3 audio offline from any saved video, and rename files right inside My Videos or the Vault
- Windows: Send to phone (QR) now works in Grabby for Windows, and Windows Settings > Apps updates the version number after self-updating
- Smaller Android APK download & tighter Vault privacy and security
