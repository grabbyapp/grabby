[optional]
What's new in Grabby 4.8

- Fixed: the owner unlock in Settings now works on all phones (tap Version 5 times, or press and hold it)
