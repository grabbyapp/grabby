"""Grabby for Windows (Grabby-Windows.exe) - a real desktop app.

- Grabby opens in its own window (Microsoft Edge WebView2, built into Windows 10 and 11). No browser tabs.
- The first time you open it, it installs itself for your Windows account (no admin needed):
    %LOCALAPPDATA%\\Programs\\Grabby\\Grabby.exe, a Start menu entry, a desktop shortcut, and an entry in
    Settings > Apps (so it can be uninstalled like any other program).
- Opening it again just brings the Grabby window to the front.
- Updates download and install by themselves, then Grabby restarts.
Your videos go to  Videos\\Grabby , settings to  %LOCALAPPDATA%\\Grabby .
"""
import ctypes
import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser

HERE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
FROZEN = getattr(sys, "frozen", False)
LOCAL = os.getenv("LOCALAPPDATA") or os.path.expanduser("~")
DATA = os.path.join(LOCAL, "Grabby")
INSTALL_DIR = os.path.join(LOCAL, "Programs", "Grabby")
INSTALL_EXE = os.path.join(INSTALL_DIR, "Grabby.exe")
UNINSTALL_KEY = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\Grabby"
PORTS = range(5000, 5011)
NO_WINDOW = 0x08000000          # CREATE_NO_WINDOW
DETACHED = 0x00000008 | 0x00000200   # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP


# ------------------------------------------------------------------ small helpers
def setup_env():
    os.makedirs(DATA, exist_ok=True)
    os.environ.setdefault("VIDGRAB_DATA", DATA)
    os.environ["VIDGRAB_DESKTOP"] = "1"
    qjs = os.path.join(HERE, "qjs.exe")
    if os.path.isfile(qjs):
        os.environ["VIDGRAB_QJS"] = qjs           # YouTube needs a JavaScript engine
    if sys.stdout is None or sys.stderr is None:  # no console window: keep a log instead
        log = open(os.path.join(DATA, "grabby.log"), "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stdout or log
        sys.stderr = sys.stderr or log


def log(*a):
    try:
        print(time.strftime("%Y-%m-%d %H:%M:%S"), *a, flush=True)
    except Exception:  # noqa
        pass


def my_version():
    try:
        return open(os.path.join(HERE, "vidgrab", "VERSION"), encoding="utf-8").read().strip()
    except OSError:
        return "0"


def vt(v):
    return tuple(int(x) for x in str(v).split(".") if x.isdigit())


def grabby_on(port):
    """The version of a Grabby already running on this port, or None."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=1.5) as r:
            d = json.load(r)
        return d.get("version") if d.get("app") == "Grabby" else None
    except Exception:  # noqa
        return None


def post(port, path):
    try:
        urllib.request.urlopen(urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=b"{}",
                                                      headers={"Content-Type": "application/json"}), timeout=3)
        return True
    except Exception:  # noqa
        return False


def port_free(port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("0.0.0.0", port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def message(text, title="Grabby", error=False):
    try:
        ctypes.windll.user32.MessageBoxW(None, text, title, 0x10 if error else 0x40)
    except Exception:  # noqa
        log(title, text)


def same_file(a, b):
    try:
        return os.path.normcase(os.path.abspath(a)) == os.path.normcase(os.path.abspath(b))
    except Exception:  # noqa
        return False


def launch(exe, *args):
    subprocess.Popen([exe, *args], creationflags=DETACHED, close_fds=True, cwd=os.path.dirname(exe))


# ------------------------------------------------------------------ install / uninstall (per user, no admin)
def shell_folder(name):
    """Desktop / Programs folder, also when OneDrive moved them."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders") as k:
            return os.path.expandvars(winreg.QueryValueEx(k, name)[0])
    except Exception:  # noqa
        return {"Desktop": os.path.join(os.path.expanduser("~"), "Desktop"),
                "Programs": os.path.join(os.getenv("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs")}[name]


def shortcut_paths():
    return [os.path.join(shell_folder("Programs"), "Grabby.lnk"), os.path.join(shell_folder("Desktop"), "Grabby.lnk")]


def make_shortcut(lnk, target):
    os.makedirs(os.path.dirname(lnk), exist_ok=True)
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:G_LNK);"
          "$s.TargetPath=$env:G_EXE;$s.WorkingDirectory=$env:G_DIR;$s.IconLocation=$env:G_EXE+',0';"
          "$s.Description='Grabby - save any video in HD';$s.Save()")
    env = dict(os.environ, G_LNK=lnk, G_EXE=target, G_DIR=os.path.dirname(target))
    subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps],
                   env=env, creationflags=NO_WINDOW, timeout=30, check=False)


def register_uninstall(version):
    import winreg
    size_kb = int(os.path.getsize(INSTALL_EXE) / 1024) if os.path.exists(INSTALL_EXE) else 0
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY) as k:
        for name, value in (("DisplayName", "Grabby"), ("DisplayVersion", version), ("Publisher", "Zypher"),
                            ("DisplayIcon", INSTALL_EXE + ",0"), ("InstallLocation", INSTALL_DIR),
                            ("UninstallString", f'"{INSTALL_EXE}" --uninstall'),
                            ("URLInfoAbout", "https://grabbyapp.github.io/grabby/")):
            winreg.SetValueEx(k, name, 0, winreg.REG_SZ, value)
        winreg.SetValueEx(k, "EstimatedSize", 0, winreg.REG_DWORD, size_kb)
        winreg.SetValueEx(k, "NoModify", 0, winreg.REG_DWORD, 1)
        winreg.SetValueEx(k, "NoRepair", 0, winreg.REG_DWORD, 1)


def copy_in(src, version):
    """Put this exe into the install folder (replacing an older one) + shortcuts + Apps entry."""
    os.makedirs(INSTALL_DIR, exist_ok=True)
    tmp = INSTALL_EXE + ".new"
    shutil.copy2(src, tmp)
    if os.path.exists(INSTALL_EXE):
        old = INSTALL_EXE + ".old"
        try:
            os.remove(old)
        except OSError:
            pass
        os.replace(INSTALL_EXE, old)          # works even while the old one is still closing
    os.replace(tmp, INSTALL_EXE)
    for lnk in shortcut_paths():
        try:
            make_shortcut(lnk, INSTALL_EXE)
        except Exception as e:  # noqa
            log("shortcut", lnk, e)
    try:
        register_uninstall(version)
    except Exception as e:  # noqa
        log("register", e)


def installed_version():
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY) as k:
            return winreg.QueryValueEx(k, "DisplayVersion")[0]
    except Exception:  # noqa
        return None


def ensure_installed(version):
    """Running a downloaded Grabby-Windows.exe: install it (or update the installed one) and start that copy.
    Returns True when this process should simply exit because the installed copy took over."""
    if not FROZEN or same_file(sys.executable, INSTALL_EXE) or "--portable" in sys.argv:
        return False
    have = installed_version() if os.path.exists(INSTALL_EXE) else None
    try:
        if have is None or vt(version) > vt(have):
            for p in PORTS:                          # an older Grabby is running: close it first
                if grabby_on(p):
                    post(p, "/api/quit")
            time.sleep(1.0)
            copy_in(sys.executable, version)
            log("installed", version, "to", INSTALL_EXE)
        launch(INSTALL_EXE)
        return True
    except Exception as e:  # noqa - can't install (locked down PC): just run from where it is
        log("install failed, running portable:", e)
        return False


def uninstall():
    if ctypes.windll.user32.MessageBoxW(None, "Remove Grabby from this computer?\n\n"
                                        "Your downloaded videos in Videos\\Grabby are kept.",
                                        "Uninstall Grabby", 0x24) != 6:      # Yes / No
        return
    for p in PORTS:
        if grabby_on(p):
            post(p, "/api/quit")
    for lnk in shortcut_paths():
        try:
            os.remove(lnk)
        except OSError:
            pass
    try:
        import winreg
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY)
    except Exception:  # noqa
        pass
    # the exe can't delete itself while it runs: a tiny background command removes the folder a moment later
    cmd = f'ping 127.0.0.1 -n 3 > nul & rmdir /s /q "{INSTALL_DIR}"'
    subprocess.Popen(["cmd", "/c", cmd], creationflags=NO_WINDOW | DETACHED, cwd=os.path.expanduser("~"))
    message("Grabby was removed. Your videos are still in Videos\\Grabby.")


# ------------------------------------------------------------------ clipboard (Windows API, no permission prompts)
def clipboard_text():
    u, k = ctypes.windll.user32, ctypes.windll.kernel32
    u.GetClipboardData.restype = ctypes.c_void_p
    k.GlobalLock.restype = ctypes.c_void_p
    k.GlobalLock.argtypes = [ctypes.c_void_p]
    k.GlobalUnlock.argtypes = [ctypes.c_void_p]
    for _ in range(5):
        if u.OpenClipboard(None):
            break
        time.sleep(0.05)
    else:
        return ""
    try:
        h = u.GetClipboardData(13)              # CF_UNICODETEXT
        if not h:
            return ""
        p = k.GlobalLock(h)
        try:
            return ctypes.wstring_at(p) if p else ""
        finally:
            k.GlobalUnlock(h)
    finally:
        u.CloseClipboard()


# ------------------------------------------------------------------ the app window
WINDOW = {"w": None}
STATE = os.path.join(DATA, "window.json")


class Api:
    """What the Grabby page can ask the Windows app to do (window.pywebview.api.*)."""

    def open_url(self, url):
        if isinstance(url, str) and url.startswith(("http://", "https://")):
            webbrowser.open(url)
        return True

    def clipboard(self):
        try:
            return clipboard_text()
        except Exception:  # noqa
            return ""

    def update(self, url):
        threading.Thread(target=self_update, args=(url,), daemon=True).start()
        return True


def js(code):
    w = WINDOW["w"]
    if w:
        try:
            w.evaluate_js(code)
        except Exception:  # noqa
            pass


def self_update(url):
    """Download the new Grabby-Windows.exe, swap it in, restart."""
    try:
        import ssl
        try:
            import certifi
            ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:  # noqa
            ctx = ssl.create_default_context()
        part = os.path.join(DATA, "update.exe.part")
        req = urllib.request.Request(url, headers={"User-Agent": "Grabby-Windows"})
        with urllib.request.urlopen(req, timeout=60, context=ctx) as r, open(part, "wb") as f:
            total, got, last = int(r.headers.get("Content-Length") or 0), 0, -1
            while True:
                b = r.read(256 * 1024)
                if not b:
                    break
                f.write(b)
                got += len(b)
                pct = int(got * 100 / total) if total else 0
                if pct != last and pct % 5 == 0:
                    last = pct
                    js(f"window.grabbyUpdateProgress && grabbyUpdateProgress({pct})")
        if os.path.getsize(part) < 5_000_000:
            raise RuntimeError("the download was incomplete")
        js("window.grabbyUpdateProgress && grabbyUpdateProgress(100, 'Installing the update… Grabby restarts now')")
        target = sys.executable if FROZEN else None
        if not target:
            raise RuntimeError("not running as Grabby.exe")
        old = target + ".old"
        try:
            os.remove(old)
        except OSError:
            pass
        os.replace(target, old)                 # Windows lets a running exe be renamed
        os.replace(part, target)
        time.sleep(0.6)
        launch(target, "--updated")
        os._exit(0)
    except Exception as e:  # noqa
        log("update failed:", e)
        js("window.grabbyUpdateProgress && grabbyUpdateProgress(0, %s)" %
           json.dumps("The update didn't finish. Check your internet and try again."))


def load_state():
    try:
        with open(STATE, encoding="utf-8") as f:
            d = json.load(f)
        return {k: int(d[k]) for k in ("width", "height", "x", "y") if k in d}, bool(d.get("max"))
    except Exception:  # noqa
        return {}, False


def save_state(w):
    try:
        d = {"width": w.width, "height": w.height, "x": w.x, "y": w.y, "max": False}
        if d["width"] > 300 and d["height"] > 300 and d["x"] > -5000:
            with open(STATE, "w", encoding="utf-8") as f:
                json.dump(d, f)
    except Exception:  # noqa
        pass


def show_window():
    w = WINDOW["w"]
    if not w:
        return
    try:
        w.restore()
        w.show()
        w.on_top = True                          # pull it in front of other windows, then let go
        time.sleep(0.15)
        w.on_top = False
    except Exception:  # noqa
        pass


def run_window(url, version):
    import webview
    try:
        webview.settings["ALLOW_DOWNLOADS"] = True
        webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True
        webview.settings["OPEN_DEVTOOLS_IN_DEBUG"] = False
    except Exception:  # noqa
        pass
    geo, _ = load_state()
    w = webview.create_window(
        "Grabby", url, js_api=Api(), width=geo.get("width", 1240), height=geo.get("height", 820),
        x=geo.get("x"), y=geo.get("y"), min_size=(400, 560), text_select=True, background_color="#FFFFFF")
    WINDOW["w"] = w
    w.events.closing += lambda: save_state(w)
    webview.start(gui="edgechromium", private_mode=False, storage_path=os.path.join(DATA, "window-data"),
                  icon=os.path.join(HERE, "grabby.ico"))


def fallback_window(url, version):
    """No WebView2 on this PC (very old Windows 10): open in the browser and show a small control window."""
    webbrowser.open(url)
    try:
        import tkinter as tk
        root = tk.Tk()
    except Exception:  # noqa
        while True:
            time.sleep(3600)
    root.title("Grabby")
    root.geometry("360x190")
    root.resizable(False, False)
    root.configure(bg="white")
    ico = os.path.join(HERE, "grabby.ico")
    if os.path.isfile(ico):
        try:
            root.iconbitmap(ico)
        except Exception:  # noqa
            pass
    tk.Label(root, text="Grabby is running", font=("Segoe UI", 15, "bold"), bg="white", fg="#111").pack(pady=(20, 2))
    tk.Label(root, text=f"Version {version}. Install Microsoft Edge WebView2\nto get Grabby in its own window.",
             font=("Segoe UI", 9), bg="white", fg="#555").pack(pady=6)
    row = tk.Frame(root, bg="white")
    row.pack(pady=6)
    tk.Button(row, text="Open Grabby", font=("Segoe UI", 10, "bold"), bg="#111", fg="white", relief="flat",
              padx=16, pady=6, command=lambda: webbrowser.open(url)).pack(side="left", padx=6)
    tk.Button(row, text="Quit", font=("Segoe UI", 10), bg="white", fg="#111", relief="solid", bd=1, padx=16, pady=5,
              command=lambda: os._exit(0)).pack(side="left", padx=6)
    root.protocol("WM_DELETE_WINDOW", lambda: os._exit(0))
    root.mainloop()


# ------------------------------------------------------------------ start
def main():
    setup_env()
    version = my_version()
    if "--uninstall" in sys.argv:
        uninstall()
        return
    for leftover in (sys.executable + ".old", INSTALL_EXE + ".old"):      # after an update
        try:
            os.remove(leftover)
        except OSError:
            pass
    if ensure_installed(version):
        return
    if FROZEN and same_file(sys.executable, INSTALL_EXE) and installed_version() != version:
        try:
            register_uninstall(version)
        except Exception as e:  # noqa
            log("register", e)

    # Already running?  Same or newer: bring its window to the front.  Older: close it and take over.
    if "--updated" in sys.argv:
        time.sleep(1.0)
    for p in PORTS:
        v = grabby_on(p)
        if v and vt(v) >= vt(version):
            if not post(p, "/api/desktop/show"):
                webbrowser.open(f"http://localhost:{p}")
            return
        if v:
            post(p, "/api/quit")
            for _ in range(40):
                if port_free(p):
                    break
                time.sleep(0.25)

    port = next((p for p in PORTS if port_free(p)), 5000)
    url = f"http://localhost:{port}/"

    from vidgrab import app as g             # the same Grabby as the phone app
    g.APP_PORT = port

    @g.app.post("/api/desktop/show")
    def _desktop_show():                     # a second Grabby.exe was opened: show this window instead
        if not g.is_local():
            return g.jsonify(error="no"), 403
        threading.Thread(target=show_window, daemon=True).start()
        return g.jsonify(ok=True)

    g.start_background()
    threading.Thread(target=lambda: g.app.run(host="0.0.0.0", port=port, threaded=True, use_reloader=False),
                     daemon=True).start()
    for _ in range(120):
        if grabby_on(port):
            break
        time.sleep(0.25)

    try:
        run_window(url, version)
    except Exception as e:  # noqa
        log("app window failed, using the browser:", e)
        fallback_window(url, version)
    os._exit(0)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # noqa
        log("crash:", e)
        message(f"Grabby couldn't start:\n{e}", error=True)
        raise
