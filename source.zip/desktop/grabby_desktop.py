"""Grabby for Windows (Grabby-Windows.exe).

Starts Grabby in the background, opens it in your browser, and shows a small window:
  - "Open Grabby" opens it again in the browser
  - closing the window (or "Quit") stops Grabby
Your videos go to  Videos\\Grabby , settings to  %LOCALAPPDATA%\\Grabby .
Opening Grabby-Windows.exe again just opens the browser; a newer version replaces the old one.
"""
import json
import os
import socket
import sys
import threading
import time
import urllib.request
import webbrowser

HERE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(os.getenv("LOCALAPPDATA") or os.path.expanduser("~"), "Grabby")
PORTS = range(5000, 5011)


def setup_env():
    os.makedirs(DATA, exist_ok=True)
    os.environ.setdefault("VIDGRAB_DATA", DATA)
    os.environ["VIDGRAB_DESKTOP"] = "1"
    qjs = os.path.join(HERE, "qjs.exe")
    if os.path.isfile(qjs):
        os.environ["VIDGRAB_QJS"] = qjs           # YouTube needs a JavaScript engine
    # no console window: send any output to a log file instead of nowhere
    if sys.stdout is None or sys.stderr is None:
        log = open(os.path.join(DATA, "grabby.log"), "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stdout or log
        sys.stderr = sys.stderr or log


def grabby_on(port):
    """The version of a Grabby already running on this port, or None."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=1.5) as r:
            d = json.load(r)
        return d.get("version") if d.get("app") == "Grabby" else None
    except Exception:  # noqa
        return None


def port_free(port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("0.0.0.0", port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def vt(v):
    return tuple(int(x) for x in str(v).split(".") if x.isdigit())


def main():
    setup_env()
    my_version = open(os.path.join(HERE, "vidgrab", "VERSION"), encoding="utf-8").read().strip()

    # Already running?  Same or newer: just open it.  Older: ask it to close and take over.
    for p in PORTS:
        v = grabby_on(p)
        if v and vt(v) >= vt(my_version):
            webbrowser.open(f"http://localhost:{p}")
            return
        if v:
            try:
                urllib.request.urlopen(urllib.request.Request(f"http://127.0.0.1:{p}/api/quit", data=b"{}",
                                                              headers={"Content-Type": "application/json"}), timeout=3)
            except Exception:  # noqa
                pass
            for _ in range(40):
                if port_free(p):
                    break
                time.sleep(0.25)

    port = next((p for p in PORTS if port_free(p)), 5000)
    url = f"http://localhost:{port}"

    from vidgrab import app as g             # the same Grabby as the phone app and the PC version
    g.APP_PORT = port
    g.start_background()
    threading.Thread(target=lambda: g.app.run(host="0.0.0.0", port=port, threaded=True, use_reloader=False),
                     daemon=True).start()

    def open_when_ready():
        for _ in range(80):
            if grabby_on(port):
                break
            time.sleep(0.25)
        webbrowser.open(url)
    threading.Thread(target=open_when_ready, daemon=True).start()

    window(url, my_version)


def window(url, version):
    """A small "Grabby is running" window. Closing it quits Grabby."""
    try:
        import tkinter as tk
        root = tk.Tk()
    except Exception:  # noqa  - no window toolkit: just keep running
        while True:
            time.sleep(3600)
    root.title("Grabby")
    root.geometry("340x210")
    root.resizable(False, False)
    root.configure(bg="white")
    ico = os.path.join(HERE, "grabby.ico")
    if os.path.isfile(ico):
        try:
            root.iconbitmap(ico)
        except Exception:  # noqa
            pass
    tk.Label(root, text="Grabby is running", font=("Segoe UI", 15, "bold"), bg="white", fg="#111").pack(pady=(22, 2))
    tk.Label(root, text=f"Version {version}  ·  your videos go to Videos\\Grabby", font=("Segoe UI", 9),
             bg="white", fg="#666").pack()
    tk.Label(root, text="Keep this window open while you use Grabby.\nClose it to stop Grabby.",
             font=("Segoe UI", 9), bg="white", fg="#444").pack(pady=10)
    row = tk.Frame(root, bg="white")
    row.pack(pady=4)
    tk.Button(row, text="Open Grabby", font=("Segoe UI", 10, "bold"), bg="#111", fg="white", activebackground="#333",
              activeforeground="white", relief="flat", padx=16, pady=6, command=lambda: webbrowser.open(url)).pack(side="left", padx=6)
    tk.Button(row, text="Quit", font=("Segoe UI", 10), bg="white", fg="#111", relief="solid", bd=1, padx=16, pady=5,
              command=lambda: os._exit(0)).pack(side="left", padx=6)
    root.protocol("WM_DELETE_WINDOW", lambda: os._exit(0))
    root.mainloop()
    os._exit(0)


if __name__ == "__main__":
    main()
