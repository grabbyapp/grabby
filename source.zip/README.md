# Grabby for Android

Save any video in HD (Facebook, Instagram, TikTok, X, YouTube and more) as MP4 or MP3.
Tap **Share → Grabby** in any app and it downloads right away.

**Download:** open the Releases page and get `Grabby.apk`, or use the link on the Grabby website.

Made with ♥ by Zypher

## For the maintainer

- The version number is in `app/src/main/python/vidgrab/VERSION`.
- To publish a new version: change VERSION, update RELEASE_NOTES.md, then on GitHub open
  **Actions → Build Grabby app → Run workflow**. The APK is built and published, and installed apps show "Update available".
- Never upload `grabby-release.jks` or `keystore.properties`. They are kept on your computer and in the repository secrets.
