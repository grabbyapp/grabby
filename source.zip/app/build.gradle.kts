import java.util.Properties

plugins {
    id("com.android.application")
    id("com.chaquo.python")
}

// The version lives in one file shared with the Python app:  app/src/main/python/vidgrab/VERSION  (e.g. 4.1)
val grabbyVersion = file("src/main/python/vidgrab/VERSION").readText().trim()
val grabbyCode = grabbyVersion.split(".").map { it.toIntOrNull() ?: 0 }.let { (it.getOrElse(0) { 0 }) * 10000 + (it.getOrElse(1) { 0 }) * 100 + (it.getOrElse(2) { 0 }) }

// Release signing key. Every version MUST be signed with the same key, or phones can't update.
// Locally: grabby-release.jks + keystore.properties next to this project (never upload them).
// On GitHub: the key comes from the GRABBY_KEYSTORE / GRABBY_KS_PASS secrets.
val ksFile = rootProject.file("grabby-release.jks")
val ksProps = Properties().apply { rootProject.file("keystore.properties").takeIf { it.exists() }?.inputStream()?.use { load(it) } }
val ksPass: String? = System.getenv("GRABBY_KS_PASS") ?: ksProps.getProperty("password")

android {
    namespace = "com.vidgrab.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vidgrab.app"
        minSdk = 24                      // Chaquopy needs Android 7.0+
        targetSdk = 35
        versionCode = grabbyCode
        versionName = grabbyVersion
        ndk {
            // phones (arm64) + emulator (x86_64); Python 3.12 is 64-bit only
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }

    signingConfigs {
        create("grabby") {
            if (ksFile.exists() && ksPass != null) {
                storeFile = ksFile
                storePassword = ksPass
                keyAlias = "grabby"
                keyPassword = ksPass
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (ksFile.exists() && ksPass != null) signingConfigs.getByName("grabby")
                            else signingConfigs.getByName("debug")
        }
    }
    packaging {
        // ffmpeg + QuickJS are programs, not libraries: keep them as real files on the phone so they can run
        jniLibs { useLegacyPackaging = true }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

chaquopy {
    defaultConfig {
        version = "3.12"
        // Python 3.12 on the computer that builds the app (found automatically on Windows, Mac and Linux)
        val winPy = System.getenv("LOCALAPPDATA")?.let { "$it/Programs/Python/Python312/python.exe" }
        if (winPy != null && file(winPy).exists()) buildPython(winPy)
        pip {
            install("markupsafe==3.0.3")   // Android build available for Python 3.12
            install("flask")
            install("yt-dlp")
            install("yt-dlp-ejs")          // YouTube's unlock scripts (run by the built-in QuickJS)
            install("certifi")
        }
        // Flask needs the page and design files as real files on the phone
        extractPackages("vidgrab")
    }
}
