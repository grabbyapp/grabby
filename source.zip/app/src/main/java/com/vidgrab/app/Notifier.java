package com.vidgrab.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

/**
 * Grabby's phone notifications. Called from Python (vidgrab/app.py, notify_loop) and from the page.
 *  - a progress bar for every download, with a Cancel button
 *  - "Downloaded!" with Play / My Videos buttons, or "Download failed" with the reason
 *  - a small "Grabby is downloading" note that keeps downloads going when you leave the app
 *  - app updates and other news
 */
public final class Notifier {
    static final String CH_PROGRESS = "downloads", CH_DONE = "finished", CH_NEWS = "news";
    static final int SERVICE_ID = 1;
    static final String GROUP = "grabby_downloads";
    static Context app;
    static int port;
    private static int active = 0;

    private Notifier() { }

    public static void init(Context c, int serverPort) {
        app = c.getApplicationContext();
        port = serverPort;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = nm();
            NotificationChannel p = new NotificationChannel(CH_PROGRESS, "Downloads in progress", NotificationManager.IMPORTANCE_LOW);
            p.setDescription("Progress bars while Grabby downloads");
            p.setShowBadge(false);
            NotificationChannel d = new NotificationChannel(CH_DONE, "Finished downloads", NotificationManager.IMPORTANCE_DEFAULT);
            d.setDescription("When a download is done or fails");
            NotificationChannel n = new NotificationChannel(CH_NEWS, "Updates and news", NotificationManager.IMPORTANCE_DEFAULT);
            n.setDescription("New versions of Grabby and other news");
            nm.createNotificationChannel(p);
            nm.createNotificationChannel(d);
            nm.createNotificationChannel(n);
        }
    }

    static NotificationManager nm() { return (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE); }

    static SharedPreferences prefs() { return app.getSharedPreferences("grabby", Context.MODE_PRIVATE); }

    /** The page's notification switches ("downloads", "updates"). */
    public static void setEnabled(String kind, boolean on) {
        if (app != null) prefs().edit().putBoolean("notify_" + kind, on).apply();
    }

    static boolean enabled(String kind) {
        if (app == null) return false;
        if (Build.VERSION.SDK_INT >= 33 &&
                app.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false;
        return prefs().getBoolean("notify_" + kind, true);
    }

    static int idFor(String key) { return 1000 + (key.hashCode() & 0x0fffffff); }

    static Notification.Builder builder(String channel) {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(app, channel) : new Notification.Builder(app);
    }

    /** Opens Grabby; goTo = a page (library, apps, download...), play = a file in My Videos to play. */
    static PendingIntent openApp(int req, String goTo, String play) {
        Intent i = new Intent(app, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (goTo != null) i.putExtra("grabby_goto", goTo);
        if (play != null) i.putExtra("grabby_play", play);
        i.setAction("grabby.open." + req);                   // keeps each notification's tap separate
        return PendingIntent.getActivity(app, req, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static Notification.Action action(int icon, String label, PendingIntent pi) {
        return new Notification.Action.Builder(icon, label, pi).build();
    }

    // ---------------------------------------------------------------- downloads
    /** percent -1 = still starting (moving bar). */
    public static void progress(String jobId, String title, int percent, String detail) {
        if (!enabled("downloads")) return;
        int id = idFor(jobId);
        Intent c = new Intent(app, CancelReceiver.class).putExtra("job", jobId).setAction("grabby.cancel." + jobId);
        PendingIntent cancel = PendingIntent.getBroadcast(app, id, c, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = builder(CH_PROGRESS)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(title == null || title.isEmpty() ? "Downloading…" : title)
                .setContentText(detail)
                .setProgress(100, Math.max(0, percent), percent < 0)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setGroup(GROUP)
                .setContentIntent(openApp(id, "download", null))
                .addAction(action(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancel));
        if (percent >= 0) b.setSubText(percent + "%");
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        nm().notify(id, b.build());
    }

    public static void done(String jobId, String title, String text, String libName) {
        nm().cancel(idFor(jobId));
        if (!enabled("downloads")) return;
        int id = idFor(jobId);
        Notification.Builder b = builder(CH_DONE)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Downloaded: " + (title == null ? "your video" : title))
                .setContentText(text)
                .setAutoCancel(true)
                .setGroup(GROUP + "_done")
                .setContentIntent(openApp(id, libName != null ? "library" : "download", libName));
        if (libName != null) {
            b.addAction(action(android.R.drawable.ic_media_play, "Play", openApp(id + 1, "library", libName)));
            b.addAction(action(android.R.drawable.ic_menu_gallery, "My Videos", openApp(id + 2, "library", null)));
        }
        nm().notify(id, b.build());
    }

    public static void failed(String jobId, String title, String error) {
        nm().cancel(idFor(jobId));
        if (!enabled("downloads")) return;
        int id = idFor(jobId);
        Notification.Builder b = builder(CH_DONE)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("Download failed" + (title == null || title.isEmpty() ? "" : ": " + title))
                .setContentText(error)
                .setStyle(new Notification.BigTextStyle().bigText(error))
                .setAutoCancel(true)
                .setContentIntent(openApp(id, "download", null));
        nm().notify(id, b.build());
    }

    public static void clear(String jobId) { nm().cancel(idFor(jobId)); }

    /** How many downloads are running: keeps a foreground service alive while there are any. */
    public static void active(int n) {
        if (app == null) return;
        int before = active;
        active = n;
        try {
            Intent s = new Intent(app, DownloadService.class).putExtra("count", n);
            if (n > 0) {
                if (Build.VERSION.SDK_INT >= 26 && before == 0) app.startForegroundService(s);
                else app.startService(s);
            } else if (before > 0) {
                app.stopService(new Intent(app, DownloadService.class));
            }
        } catch (Exception ignored) {
            // Android may refuse to start it from the background (e.g. "download later" on Wi-Fi). Downloads still run.
        }
    }

    static Notification serviceNotification(int n) {
        Notification.Builder b = builder(CH_PROGRESS)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Grabby is downloading")
                .setContentText(n == 1 ? "1 download. You can leave the app." : n + " downloads. You can leave the app.")
                .setOngoing(true)
                .setShowWhen(false)
                .setGroup(GROUP)
                .setGroupSummary(true)
                .setContentIntent(openApp(SERVICE_ID, "download", null));
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }

    // ---------------------------------------------------------------- news
    /** A general notification: kind = "updates" (or "downloads"), goTo = page to open when tapped. */
    public static void news(String key, String kind, String title, String text, String goTo) {
        if (!enabled(kind)) return;
        int id = idFor("news:" + key);
        Notification.Builder b = builder(CH_NEWS)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(openApp(id, goTo, null));
        nm().notify(id, b.build());
    }
}
