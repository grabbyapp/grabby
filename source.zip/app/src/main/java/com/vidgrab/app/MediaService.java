package com.vidgrab.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.IBinder;

/**
 * Background music: keeps Grabby playing when you leave the app or lock the phone, with a media
 * notification and lock-screen / headphone controls (play, pause, next, previous, stop, seek).
 * The music itself plays in the page; this service keeps the app alive and passes the buttons back.
 */
public class MediaService extends Service {
    static final int ID = 2;
    static final String CHANNEL = "music";
    private MediaSession session;

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Music playing", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Controls for music playing in the background");
            ch.setShowBadge(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        session = new MediaSession(this, "Grabby");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { MainActivity.mediaCommand("play"); }
            @Override public void onPause() { MainActivity.mediaCommand("pause"); }
            @Override public void onSkipToNext() { MainActivity.mediaCommand("next"); }
            @Override public void onSkipToPrevious() { MainActivity.mediaCommand("prev"); }
            @Override public void onStop() { MainActivity.mediaCommand("stop"); }
            @Override public void onSeekTo(long pos) { MainActivity.mediaCommand("seek:" + pos); }
        });
        session.setActive(true);
    }

    private PendingIntent cmd(String c, int req) {
        Intent i = new Intent(this, MediaService.class).putExtra("cmd", c).setAction("grabby.media." + c);
        return PendingIntent.getService(this, req, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String c = intent.getStringExtra("cmd");
        if (c != null) {                         // a button on the notification
            MainActivity.mediaCommand(c);
            return START_NOT_STICKY;
        }
        String title = intent.getStringExtra("title"), artist = intent.getStringExtra("artist");
        boolean playing = intent.getBooleanExtra("playing", false);
        boolean hasPrev = intent.getBooleanExtra("prev", false), hasNext = intent.getBooleanExtra("next", false);
        long pos = intent.getLongExtra("pos", 0), dur = intent.getLongExtra("dur", 0);

        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, dur)
                .build());
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO;
        if (hasNext) actions |= PlaybackState.ACTION_SKIP_TO_NEXT;
        if (hasPrev) actions |= PlaybackState.ACTION_SKIP_TO_PREVIOUS;
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(actions)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, pos, playing ? 1f : 0f)
                .build());

        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Intent open = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        b.setSmallIcon(playing ? android.R.drawable.ic_media_play : android.R.drawable.ic_media_pause)
                .setContentTitle(title)
                .setContentText(artist)
                .setContentIntent(PendingIntent.getActivity(this, 20, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT))
                .setDeleteIntent(cmd("stop", 26))          // swiping it away (when paused) stops the music
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setShowWhen(false)
                .setOngoing(playing)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous, "Previous", cmd("prev", 21)).build())
                .addAction(new Notification.Action.Builder(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                        playing ? "Pause" : "Play", cmd("toggle", 22)).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next, "Next", cmd("next", 23)).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", cmd("stop", 24)).build())
                .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0, 1, 2));
        Notification n = b.build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(ID, n);
            if (!playing) {                          // paused: let it be swiped away
                if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_DETACH);
                ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(ID, n);
            }
        } catch (Exception e) {
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(ID, n);
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        if (session != null) { session.setActive(false); session.release(); }
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(ID);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
