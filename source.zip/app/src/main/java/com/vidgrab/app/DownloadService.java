package com.vidgrab.app;

import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** Keeps Grabby's downloads running while you use other apps (shows "Grabby is downloading"). */
public class DownloadService extends Service {
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        int n = intent != null ? intent.getIntExtra("count", 1) : 1;
        try {
            if (Build.VERSION.SDK_INT >= 29)
                startForeground(Notifier.SERVICE_ID, Notifier.serviceNotification(n), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else
                startForeground(Notifier.SERVICE_ID, Notifier.serviceNotification(n));
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onTimeout(int startId, int fgsType) { stopSelf(); }     // Android 15 daily limit reached

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
