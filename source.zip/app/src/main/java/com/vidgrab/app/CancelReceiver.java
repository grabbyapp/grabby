package com.vidgrab.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.net.HttpURLConnection;
import java.net.URL;

/** The "Cancel" button on a download notification. */
public class CancelReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        final String job = intent.getStringExtra("job");
        if (job == null || !job.matches("[0-9a-f]{8,64}")) return;
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL("http://127.0.0.1:" + Notifier.port + "/api/cancel/" + job).openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(2000);
                c.setReadTimeout(3000);
                c.getResponseCode();
                c.disconnect();
            } catch (Exception ignored) {
            } finally {
                Notifier.clear(job);
                pr.finish();
            }
        }).start();
    }
}
