package com.vidgrab.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.chaquo.python.Python;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Grabby for Android.
 * Starts the VidGrab Python server (Flask + yt-dlp) inside the app on 127.0.0.1
 * and shows the same web interface in a full-screen WebView.
 */
public class MainActivity extends Activity {

    static final int PORT = 8765;
    static final String BASE = "http://127.0.0.1:" + PORT;
    static volatile boolean serverStarted = false;
    static volatile boolean serverReady = false;

    private WebView web;
    private String pendingShare = null;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // keeps History and settings
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);   // thumbnails from https sites
        s.setTextZoom(100);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("127.0.0.1".equals(u.getHost()) || "file".equals(u.getScheme())) return false;
                // PayPal, Ko-fi and other links open in the phone's browser
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "VidGrabAndroid");
        web.setDownloadListener((url, ua, disposition, mime, length) -> saveToDownloads(url, disposition, mime));

        if (Build.VERSION.SDK_INT <= 28 &&
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }

        handleIntent(getIntent());
        if (serverReady) {
            loadApp();
        } else {
            web.loadUrl("file:///android_asset/splash.html");
            startServer();
        }
    }

    /** Start the Python server once, then wait until it answers. */
    private void startServer() {
        new Thread(() -> {
            if (!serverStarted) {
                serverStarted = true;
                Python py = Python.getInstance();
                py.getModule("vidgrab.server").callAttr("start", PORT,
                        getFilesDir().getAbsolutePath(), getCacheDir().getAbsolutePath());
            }
            for (int i = 0; i < 240 && !serverReady; i++) {       // up to 60 s on first launch
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(BASE + "/api/health").openConnection();
                    c.setConnectTimeout(500);
                    c.setReadTimeout(1000);
                    if (c.getResponseCode() == 200) serverReady = true;
                    c.disconnect();
                } catch (Exception e) {
                    try { Thread.sleep(250); } catch (InterruptedException ignored) { }
                }
            }
            runOnUiThread(this::loadApp);
        }).start();
    }

    private void loadApp() {
        if (!serverReady) {
            web.loadUrl("file:///android_asset/splash.html#error");
            return;
        }
        String target = BASE + "/";
        if (pendingShare != null) {
            try { target = BASE + "/share?text=" + URLEncoder.encode(pendingShare, "UTF-8"); } catch (Exception ignored) { }
            pendingShare = null;
        }
        web.loadUrl(target);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
        if (serverReady && pendingShare != null) loadApp();
    }

    private void handleIntent(Intent intent) {
        if (intent != null && Intent.ACTION_SEND.equals(intent.getAction())) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (text != null && !text.trim().isEmpty()) pendingShare = text.trim();
        }
    }

    /** Finished files are saved to Downloads/Grabby by Android's download manager. */
    private void saveToDownloads(String url, String disposition, String mime) {
        try {
            String name = fileName(url, disposition, mime);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.setTitle(name);
            r.setDescription("Grabby");
            if (mime != null) r.setMimeType(mime);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.allowScanningByMediaScanner();          // show it in the Gallery / Music apps
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Grabby/" + name);
            ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't save: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static String fileName(String url, String disposition, String mime) {
        String name = null;
        if (disposition != null) {
            Matcher m = Pattern.compile("filename\\*=UTF-8''([^;]+)", Pattern.CASE_INSENSITIVE).matcher(disposition);
            if (m.find()) {
                try { name = URLDecoder.decode(m.group(1), "UTF-8"); } catch (Exception ignored) { }
            }
            if (name == null) {
                m = Pattern.compile("filename=\"?([^\";]+)\"?", Pattern.CASE_INSENSITIVE).matcher(disposition);
                if (m.find()) name = m.group(1);
            }
        }
        if (name == null || name.trim().isEmpty()) name = URLUtil.guessFileName(url, disposition, mime);
        return name.replaceAll("[\\\\/:*?\"<>|]", " ").trim();
    }

    /** When you come back to Grabby, hand a freshly copied link to the page.
     *  (Android only lets the app read the clipboard while it has focus.) */
    private String lastClip = "";

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus || !serverReady || web == null) return;
        web.postDelayed(() -> {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm == null || !cm.hasPrimaryClip()) return;
                ClipData clip = cm.getPrimaryClip();
                if (clip == null || clip.getItemCount() == 0) return;
                CharSequence t = clip.getItemAt(0).coerceToText(this);
                String text = t == null ? "" : t.toString().trim();
                if (text.isEmpty() || text.equals(lastClip) || !text.contains("http")) return;
                lastClip = text;
                web.evaluateJavascript("window.grabbyClipboard && window.grabbyClipboard(" + org.json.JSONObject.quote(text) + ")", null);
            } catch (Exception ignored) { }
        }, 350);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else moveTaskToBack(true);     // keep downloads running in the background
    }

    /** Small helpers the web page can call (window.VidGrabAndroid). */
    public class Bridge {
        @JavascriptInterface
        public String getClipboard() {
            // the clipboard must be read on the main thread while the app has focus
            final String[] out = {""};
            final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
            runOnUiThread(() -> {
                try {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null && cm.hasPrimaryClip()) {
                        ClipData clip = cm.getPrimaryClip();
                        if (clip != null && clip.getItemCount() > 0) {
                            CharSequence t = clip.getItemAt(0).coerceToText(MainActivity.this);
                            out[0] = t == null ? "" : t.toString();
                        }
                    }
                } catch (Exception ignored) { }
                done.countDown();
            });
            try { done.await(2, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            return out[0];
        }

        @JavascriptInterface
        public void openDownloads() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public String platform() { return "android"; }

        /** Opens a web link outside the app (used to download a new version of Grabby). */
        @JavascriptInterface
        public void openUrl(String url) {
            if (url == null || !url.startsWith("https://")) return;
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Open this link in your browser: " + url, Toast.LENGTH_LONG).show(); }
            });
        }
    }
}
