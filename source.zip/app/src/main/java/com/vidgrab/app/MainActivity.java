package com.vidgrab.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.chaquo.python.Python;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.util.HashSet;
import java.util.Set;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Grabby for Android.
 * Starts the VidGrab Python server (Flask + yt-dlp) inside the app on 127.0.0.1
 * and shows the same web interface in a full-screen WebView.
 */
public class MainActivity extends Activity {

    static final int PORT = 8765;
    static final String BASE = "http://127.0.0.1:" + PORT;
    static volatile boolean serverStarted = false;
    static volatile boolean serverReady = false;

    private WebView web;
    private String pendingShare = null;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        current = this;
        Notifier.init(this, PORT);                  // phone notifications (downloads, updates)
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
        web = new WebView(this);
        // Keep the page clear of the status bar and the gesture/nav bar (Android 15 draws apps edge to edge)
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (Build.VERSION.SDK_INT >= 30) {             // we place the page ourselves, the same way on every Android
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets b = insets.getInsets(android.view.WindowInsets.Type.systemBars()
                        | android.view.WindowInsets.Type.displayCutout() | android.view.WindowInsets.Type.ime());
                v.setPadding(b.left, b.top, b.right, b.bottom);     // ime: the keyboard never covers what you type
                return insets;
            });
        }
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 23) {          // white status bar with dark icons, to match the app
            getWindow().setStatusBarColor(Color.WHITE);
            getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        root.requestApplyInsets();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // keeps History and settings
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);   // thumbnails from https sites
        s.setTextZoom(100);
        // the page fits the screen exactly: no zooming, no sliding left/right
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setOverScrollMode(android.view.View.OVER_SCROLL_NEVER);

        web.setWebChromeClient(new WebChromeClient() {
            // full screen for the video player (the page's Full screen button and the video's own button)
            @Override
            public void onShowCustomView(android.view.View view, CustomViewCallback callback) {
                if (fullView != null) { callback.onCustomViewHidden(); return; }
                fullView = view;
                fullCallback = callback;
                view.setBackgroundColor(Color.BLACK);
                ((FrameLayout) getWindow().getDecorView()).addView(view,
                        new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                systemBars(false);
            }

            @Override
            public void onHideCustomView() { leaveFullScreen(); }

            // "Add from this device" in the vault: pick videos, music or pictures
            @Override
            public boolean onShowFileChooser(WebView w, android.webkit.ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                picking = true;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                String[] types = params.getAcceptTypes();
                boolean any = types != null && types.length > 0 && !(types.length == 1 && types[0].isEmpty());
                if (any) {
                    java.util.List<String> t = new java.util.ArrayList<>();
                    for (String a : types) for (String x : a.split(",")) if (!x.trim().isEmpty()) t.add(x.trim());
                    i.putExtra(Intent.EXTRA_MIME_TYPES, t.toArray(new String[0]));
                }
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(Intent.createChooser(i, "Choose files"), PICK_FILES);
                } catch (Exception e) {
                    fileCallback = null;
                    picking = false;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                // once Grabby is showing, forget the start-up screen so nothing can go back to it
                if (url != null && url.startsWith(BASE)) view.clearHistory();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("127.0.0.1".equals(u.getHost()) || "file".equals(u.getScheme())) return false;
                // PayPal, Ko-fi and other links open in the phone's browser
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "VidGrabAndroid");
        web.setDownloadListener((url, ua, disposition, mime, length) -> saveToDownloads(url, disposition, mime));

        if (Build.VERSION.SDK_INT <= 28 &&
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }

        handleIntent(getIntent());
        if (serverReady) {
            loadApp();
        } else {
            web.loadUrl("file:///android_asset/splash.html");
            startServer();
        }
    }

    /** Start the Python server once, then wait until it answers. */
    private void startServer() {
        new Thread(() -> {
            if (!serverStarted) {
                serverStarted = true;
                Python py = Python.getInstance();
                py.getModule("vidgrab.server").callAttr("start", PORT,
                        getFilesDir().getAbsolutePath(), getCacheDir().getAbsolutePath(),
                        getApplicationInfo().nativeLibraryDir);   // ffmpeg + QuickJS live here
            }
            for (int i = 0; i < 240 && !serverReady; i++) {       // up to 60 s on first launch
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(BASE + "/api/health").openConnection();
                    c.setConnectTimeout(500);
                    c.setReadTimeout(1000);
                    if (c.getResponseCode() == 200) serverReady = true;
                    c.disconnect();
                } catch (Exception e) {
                    try { Thread.sleep(250); } catch (InterruptedException ignored) { }
                }
            }
            runOnUiThread(this::loadApp);
        }).start();
    }

    private void loadApp() {
        if (!serverReady) {
            web.loadUrl("file:///android_asset/splash.html#error");
            return;
        }
        String target = BASE + "/";
        if (pendingShare != null) {
            try { target = BASE + "/share?text=" + URLEncoder.encode(pendingShare, "UTF-8"); } catch (Exception ignored) { }
            pendingShare = null;
        }
        web.loadUrl(target);          // the page asks takeOpen() when it starts
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
        if (serverReady && pendingShare != null) loadApp();
    }

    // ---------- background music: buttons on the media notification / lock screen come back here
    static MainActivity current;

    static void mediaCommand(String cmd) {
        MainActivity a = current;
        if (a == null || a.web == null) return;
        String js = "window.grabbyMedia && window.grabbyMedia(" + org.json.JSONObject.quote(cmd) + ")";
        a.runOnUiThread(() -> a.web.evaluateJavascript(js, null));
    }

    @Override
    protected void onDestroy() {
        if (current == this) {
            current = null;
            stopService(new Intent(this, MediaService.class));   // the music lives in this screen
        }
        super.onDestroy();
    }

    private String openGoTo = null, openPlay = null;     // from tapping a notification

    private void openFromNotification() {
        if (!serverReady || openGoTo == null) return;
        String js = "window.grabbyOpen && window.grabbyOpen(" + org.json.JSONObject.quote(openGoTo) + ","
                + (openPlay == null ? "null" : org.json.JSONObject.quote(openPlay)) + ")";
        openGoTo = null;
        openPlay = null;
        web.postDelayed(() -> web.evaluateJavascript(js, null), 600);
    }

    private void handleIntent(Intent intent) {
        if (intent != null && intent.getStringExtra("grabby_goto") != null) {
            openGoTo = intent.getStringExtra("grabby_goto");
            openPlay = intent.getStringExtra("grabby_play");
            openFromNotification();
        }
        if (intent != null && Intent.ACTION_SEND.equals(intent.getAction())) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (text != null && !text.trim().isEmpty()) pendingShare = text.trim();
        }
    }

    /** Finished files are saved to Downloads/Grabby by Android's download manager. */
    private void saveToDownloads(String url, String disposition, String mime) {
        try {
            String name = fileName(url, disposition, mime);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.setTitle(name);
            r.setDescription("Grabby");
            if (mime != null) r.setMimeType(mime);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.allowScanningByMediaScanner();          // show it in the Gallery / Music apps
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Grabby/" + name);
            ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't save: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static String fileName(String url, String disposition, String mime) {
        String name = null;
        if (disposition != null) {
            Matcher m = Pattern.compile("filename\\*=UTF-8''([^;]+)", Pattern.CASE_INSENSITIVE).matcher(disposition);
            if (m.find()) {
                try { name = URLDecoder.decode(m.group(1), "UTF-8"); } catch (Exception ignored) { }
            }
            if (name == null) {
                m = Pattern.compile("filename=\"?([^\";]+)\"?", Pattern.CASE_INSENSITIVE).matcher(disposition);
                if (m.find()) name = m.group(1);
            }
        }
        if (name == null || name.trim().isEmpty()) name = URLUtil.guessFileName(url, disposition, mime);
        return name.replaceAll("[\\\\/:*?\"<>|]", " ").trim();
    }

    /** When you come back to Grabby, hand a freshly copied link to the page.
     *  (Android only lets the app read the clipboard while it has focus.) */
    private String lastClip = "";

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus || !serverReady || web == null) return;
        web.postDelayed(() -> {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm == null || !cm.hasPrimaryClip()) return;
                ClipData clip = cm.getPrimaryClip();
                if (clip == null || clip.getItemCount() == 0) return;
                CharSequence t = clip.getItemAt(0).coerceToText(this);
                String text = t == null ? "" : t.toString().trim();
                if (text.isEmpty() || text.equals(lastClip) || !text.contains("http")) return;
                lastClip = text;
                web.evaluateJavascript("window.grabbyClipboard && window.grabbyClipboard(" + org.json.JSONObject.quote(text) + ")", null);
            } catch (Exception ignored) { }
        }, 350);
    }

    // ---------- picking files for the vault
    static final int PICK_FILES = 4242;
    private android.webkit.ValueCallback<Uri[]> fileCallback;
    private boolean picking = false;
    private volatile boolean bioBusy = false;        // the fingerprint dialog is open: don't lock the vault
    private VaultBio bio;
    private VaultBio bio() { if (bio == null) bio = new VaultBio(this); return bio; }
    private void bioReply(boolean ok, String secret, String error) {
        bioBusy = false;
        org.json.JSONObject o = new org.json.JSONObject();
        try { o.put("ok", ok); if (secret != null) o.put("secret", secret); if (error != null) o.put("error", error); } catch (Exception ignored) { }
        String js = "window.grabbyBio && window.grabbyBio(" + o + ")";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILES) return;
        picking = false;
        if (fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                ClipData c = data.getClipData();
                result = new Uri[c.getItemCount()];
                for (int k = 0; k < c.getItemCount(); k++) result[k] = c.getItemAt(k).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    // ---------- full screen video
    private android.view.View fullView;
    private WebChromeClient.CustomViewCallback fullCallback;

    private void leaveFullScreen() {
        if (fullView == null) return;
        ((FrameLayout) getWindow().getDecorView()).removeView(fullView);
        fullView = null;
        if (fullCallback != null) fullCallback.onCustomViewHidden();
        fullCallback = null;
        systemBars(true);
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    /** Hide the status and navigation bars while a video is full screen (swipe from the edge to peek). */
    private void systemBars(boolean show) {
        if (Build.VERSION.SDK_INT >= 30) {
            android.view.WindowInsetsController c = getWindow().getInsetsController();
            if (c == null) return;
            if (show) c.show(android.view.WindowInsets.Type.systemBars());
            else {
                c.hide(android.view.WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            android.view.View d = getWindow().getDecorView();
            d.setSystemUiVisibility(show
                    ? (Build.VERSION.SDK_INT >= 23 ? android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR : 0)
                    : android.view.View.SYSTEM_UI_FLAG_FULLSCREEN | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                      | android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                      | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // leaving the app locks the vault
        if (web != null && serverReady && !picking && !bioBusy)
            web.evaluateJavascript("window.grabbyPaused && window.grabbyPaused()", null);
    }

    // ---------- Sign in to sites (for private posts, Stories, Instagram...) ----------
    // The person signs in on the real site inside the app. Grabby never sees the password:
    // it only keeps the site's login cookies (in the app's private storage) and gives them to yt-dlp.
    private FrameLayout loginBox;
    private WebView loginWeb;
    private static final String[] KNOWN_SITES = {
            "instagram.com", "facebook.com", "tiktok.com", "x.com", "twitter.com", "reddit.com",
            "threads.net", "vimeo.com", "bilibili.com", "pinterest.com", "twitch.tv", "dailymotion.com"};

    private Set<String> siteHosts() {
        SharedPreferences p = getSharedPreferences("grabby", MODE_PRIVATE);
        Set<String> s = new HashSet<>(p.getStringSet("sites", new HashSet<>()));
        for (String k : KNOWN_SITES) s.add(k);
        return s;
    }

    private static String baseHost(String host) {
        host = host.toLowerCase();
        for (String pre : new String[]{"www.", "m.", "mobile.", "web.", "accounts.", "login."})
            if (host.startsWith(pre)) return host.substring(pre.length());
        return host;
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void showLogin(String url) {
        if (loginBox != null) return;
        Uri u = Uri.parse(url);
        if (u.getHost() != null) {
            SharedPreferences p = getSharedPreferences("grabby", MODE_PRIVATE);
            Set<String> s = new HashSet<>(p.getStringSet("sites", new HashSet<>()));
            s.add(baseHost(u.getHost()));
            p.edit().putStringSet("sites", s).apply();
        }
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        loginWeb = new WebView(this);
        cm.setAcceptThirdPartyCookies(loginWeb, true);
        WebSettings ws = loginWeb.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setUserAgentString(ws.getUserAgentString().replace("; wv", ""));   // look like a normal browser
        loginWeb.setWebViewClient(new WebViewClient());                       // stay inside this window

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(Color.WHITE);
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.BLACK);
        int pad = (int) (12 * getResources().getDisplayMetrics().density);
        bar.setPadding(pad, pad, pad, pad);
        TextView t = new TextView(this);
        t.setText("Sign in with your account, then tap Done");
        t.setTextColor(Color.WHITE);
        bar.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button done = new Button(this);
        done.setText("Done");
        done.setOnClickListener(v -> closeLogin());
        bar.addView(done);
        col.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        col.addView(loginWeb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        if (Build.VERSION.SDK_INT >= 30) col.setOnApplyWindowInsetsListener((v, insets) -> {   // clear of the status / nav bars
            android.graphics.Insets b = insets.getInsets(android.view.WindowInsets.Type.systemBars()
                    | android.view.WindowInsets.Type.displayCutout() | android.view.WindowInsets.Type.ime());
            v.setPadding(b.left, b.top, b.right, b.bottom);
            return insets;
        });
        loginBox = new FrameLayout(this);
        loginBox.addView(col, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        addContentView(loginBox, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        col.requestApplyInsets();
        loginWeb.loadUrl(url);
    }

    private void closeLogin() {
        if (loginBox == null) return;
        CookieManager.getInstance().flush();
        int n = writeCookies();
        ((ViewGroup) loginBox.getParent()).removeView(loginBox);
        loginWeb.destroy();
        loginBox = null;
        loginWeb = null;
        web.evaluateJavascript("window.grabbySignedIn && window.grabbySignedIn(" + n + ")", null);
    }

    /** Saves the login cookies as a cookies.txt file (the format yt-dlp reads). Returns how many sites have one. */
    private int writeCookies() {
        CookieManager cm = CookieManager.getInstance();
        StringBuilder out = new StringBuilder("# Netscape HTTP Cookie File\n# Made by Grabby (Settings > Sign in to sites)\n");
        long expires = System.currentTimeMillis() / 1000 + 180L * 24 * 3600;
        int sites = 0;
        for (String host : siteHosts()) {
            String c = cm.getCookie("https://www." + host);
            String c2 = cm.getCookie("https://" + host);
            if ((c == null || c.isEmpty()) && c2 != null) c = c2;
            if (c == null || c.trim().isEmpty()) continue;
            int count = 0;
            for (String part : c.split(";")) {
                int eq = part.indexOf('=');
                if (eq <= 0) continue;
                String name = part.substring(0, eq).trim(), value = part.substring(eq + 1).trim();
                if (name.isEmpty()) continue;
                out.append('.').append(host).append("\tTRUE\t/\tTRUE\t").append(expires).append('\t')
                   .append(name).append('\t').append(value).append('\n');
                count++;
            }
            if (count > 1) sites++;          // one cookie alone is usually not a login
        }
        try (OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(new File(getFilesDir(), "cookies.txt")), "UTF-8")) {
            w.write(out.toString());
        } catch (Exception ignored) { }
        return sites;
    }

    private String signedIn() {
        CookieManager cm = CookieManager.getInstance();
        org.json.JSONArray a = new org.json.JSONArray();
        for (String host : siteHosts()) {
            String c = cm.getCookie("https://www." + host);
            if (c == null || c.isEmpty()) c = cm.getCookie("https://" + host);
            if (c != null && c.split(";").length > 1) a.put(host);
        }
        return a.toString();
    }

    @Override
    public void onBackPressed() {
        if (fullView != null) { leaveFullScreen(); return; }
        if (loginBox != null) { closeLogin(); return; }
        // Grabby is one page: Back closes the player / pop-ups, then goes to the previous page in the app.
        // (Going "back" in the browser history would land on the start-up screen and look stuck.)
        if (web == null || !serverReady) { moveTaskToBack(true); return; }
        web.evaluateJavascript("(window.grabbyBack && window.grabbyBack()) ? 1 : 0", r -> {
            if (!"1".equals(r)) moveTaskToBack(true);     // nothing left to close: leave, downloads keep going
        });
    }

    /** Small helpers the web page can call (window.VidGrabAndroid). */
    public class Bridge {
        // ---- Vault: fingerprint / face (see VaultBio)
        @JavascriptInterface
        public String bioStatus() { return Build.VERSION.SDK_INT >= 28 ? bio().status() : "no"; }

        @JavascriptInterface
        public boolean bioEnrolled() { return Build.VERSION.SDK_INT >= 28 && bio().enrolled(); }

        @JavascriptInterface
        public void bioEnroll(String secret) {
            if (Build.VERSION.SDK_INT < 28 || secret == null || secret.isEmpty()) { bioReply(false, null, "This phone can't use fingerprint for the Vault."); return; }
            bioBusy = true;
            bio().enroll(secret, (ok, s, err) -> bioReply(ok, null, err));
        }

        @JavascriptInterface
        public void bioUnlock() {
            if (Build.VERSION.SDK_INT < 28) { bioReply(false, null, "no"); return; }
            bioBusy = true;
            bio().unlock((ok, s, err) -> bioReply(ok, s, err));
        }

        @JavascriptInterface
        public void bioOff() { if (Build.VERSION.SDK_INT >= 28) bio().off(); }

        @JavascriptInterface
        public String getClipboard() {
            // the clipboard must be read on the main thread while the app has focus
            final String[] out = {""};
            final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
            runOnUiThread(() -> {
                try {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null && cm.hasPrimaryClip()) {
                        ClipData clip = cm.getPrimaryClip();
                        if (clip != null && clip.getItemCount() > 0) {
                            CharSequence t = clip.getItemAt(0).coerceToText(MainActivity.this);
                            out[0] = t == null ? "" : t.toString();
                        }
                    }
                } catch (Exception ignored) { }
                done.countDown();
            });
            try { done.await(2, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            return out[0];
        }

        @JavascriptInterface
        public void openDownloads() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public String platform() { return "android"; }

        /** Opens a site's sign-in page inside the app (for private posts). */
        @JavascriptInterface
        public void signIn(String url) {
            if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) return;
            runOnUiThread(() -> showLogin(url));
        }

        /** Sites you're signed in to, as a JSON list. */
        @JavascriptInterface
        public String signedInSites() {
            final String[] out = {"[]"};
            final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
            runOnUiThread(() -> { try { out[0] = signedIn(); } catch (Exception ignored) { } done.countDown(); });
            try { done.await(2, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            return out[0];
        }

        /** Forget every site login. */
        @JavascriptInterface
        public void signOutAll() {
            runOnUiThread(() -> {
                CookieManager.getInstance().removeAllCookies(null);
                CookieManager.getInstance().flush();
                new File(getFilesDir(), "cookies.txt").delete();
                getSharedPreferences("grabby", MODE_PRIVATE).edit().remove("sites").apply();
            });
        }

        /** The page asks once it has loaded: did the person open Grabby from a notification? */
        @JavascriptInterface
        public String takeOpen() {
            if (openGoTo == null) return "";
            String out = "{\"goto\":" + org.json.JSONObject.quote(openGoTo) + ",\"play\":"
                    + (openPlay == null ? "null" : org.json.JSONObject.quote(openPlay)) + "}";
            openGoTo = null;
            openPlay = null;
            return out;
        }

        /** Music is playing (or paused): show / update the media notification and lock-screen controls. */
        @JavascriptInterface
        public void media(String title, String artist, boolean playing, double posMs, double durMs, boolean hasPrev, boolean hasNext) {
            Intent i = new Intent(MainActivity.this, MediaService.class)
                    .putExtra("title", title).putExtra("artist", artist).putExtra("playing", playing)
                    .putExtra("pos", (long) posMs).putExtra("dur", (long) durMs)
                    .putExtra("prev", hasPrev).putExtra("next", hasNext);
            try {
                if (Build.VERSION.SDK_INT >= 26 && playing) startForegroundService(i);
                else startService(i);
            } catch (Exception ignored) { }
        }

        /** Music stopped: remove the notification. */
        @JavascriptInterface
        public void mediaStop() {
            stopService(new Intent(MainActivity.this, MediaService.class));
        }

        /** Notification switches from Settings: kind = "downloads" or "updates". */
        @JavascriptInterface
        public void setNotify(String kind, boolean on) {
            if ("downloads".equals(kind) || "updates".equals(kind)) Notifier.setEnabled(kind, on);
        }

        /** Can Grabby show notifications? (Android 13+ asks the person first.) */
        @JavascriptInterface
        public boolean canNotify() {
            return Build.VERSION.SDK_INT < 33 ||
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }

        /** Ask for permission to notify (Android 13+). */
        @JavascriptInterface
        public void askNotify() {
            if (Build.VERSION.SDK_INT >= 33) runOnUiThread(() ->
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2));
        }

        /** A news notification from the page (e.g. "Grabby 4.6 is out"). */
        @JavascriptInterface
        public void notify(String key, String title, String text, String goTo) {
            Notifier.news(key == null ? "news" : key, "updates", title, text, goTo == null ? "apps" : goTo);
        }

        /** Open another app (GCash, Maya) if it's installed. Returns false if it isn't. */
        @JavascriptInterface
        public boolean openApp(String pkg) {
            if (!"com.globe.gcash.android".equals(pkg) && !"com.paymaya".equals(pkg)) return false;
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) return false;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            runOnUiThread(() -> { try { startActivity(i); } catch (Exception ignored) { } });
            return true;
        }

        /** Turn the phone sideways for a wide video in full screen (and back). */
        @JavascriptInterface
        public void setLandscape(boolean on) {
            runOnUiThread(() -> setRequestedOrientation(on
                    ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED));
        }

        /** While the vault is open: no screenshots, and a blank preview in the recent-apps list. */
        @JavascriptInterface
        public void secure(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
                else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
            });
        }

        /** Restart Grabby (to start using a newly downloaded download engine). */
        @JavascriptInterface
        public void restartApp() {
            runOnUiThread(() -> {
                Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
                if (i == null) return;
                startActivity(Intent.makeRestartActivityTask(i.getComponent()));
                android.os.Process.killProcess(android.os.Process.myPid());
            });
        }

        /** Opens a web link outside the app (used to download a new version of Grabby). */
        @JavascriptInterface
        public void openUrl(String url) {
            if (url == null || !url.startsWith("https://")) return;
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Open this link in your browser: " + url, Toast.LENGTH_LONG).show(); }
            });
        }
    }
}
