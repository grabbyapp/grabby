package com.vidgrab.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Fingerprint / face (and, on Android 11+, the phone's own screen lock) for the Grabby Vault.
 *
 * The vault server gives the phone a random secret. That secret is encrypted with an AES key that lives
 * inside Android's Keystore and can only be used right after a successful fingerprint / face check
 * (setUserAuthenticationRequired). Grabby never sees a fingerprint: Android only says "yes, it's them"
 * and unlocks the key. Adding a new fingerprint to the phone turns this off, so someone can't add theirs.
 */
@android.annotation.TargetApi(Build.VERSION_CODES.P)
final class VaultBio {
    interface Done { void result(boolean ok, String secret, String error); }

    private static final String KEY = "grabby_vault_bio";
    private static final String PREFS = "vault_bio";
    private final Activity a;

    VaultBio(Activity a) { this.a = a; }

    private SharedPreferences prefs() { return a.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    boolean enrolled() { return prefs().contains("ct"); }

    /** "bio" = fingerprint/face ready, "lock" = only the screen lock (Android 11+), "none" = nothing set up on the phone, "no" = not possible. */
    String status() {
        if (Build.VERSION.SDK_INT < 28) return "no";
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                BiometricManager bm = a.getSystemService(BiometricManager.class);
                if (bm == null) return "no";
                int strong = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG);
                if (strong == BiometricManager.BIOMETRIC_SUCCESS) return "bio";
                int lock = bm.canAuthenticate(BiometricManager.Authenticators.DEVICE_CREDENTIAL);
                if (lock == BiometricManager.BIOMETRIC_SUCCESS) return "lock";
                return strong == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ? "none" : "no";
            }
            if (Build.VERSION.SDK_INT == 29) {
                BiometricManager bm = a.getSystemService(BiometricManager.class);
                if (bm == null) return "no";
                int r = bm.canAuthenticate();
                if (r == BiometricManager.BIOMETRIC_SUCCESS) return "bio";
                return r == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ? "none" : "no";
            }
            @SuppressWarnings("deprecation")
            FingerprintManager fm = a.getSystemService(FingerprintManager.class);
            if (fm == null || !fm.isHardwareDetected()) return "no";
            return fm.hasEnrolledFingerprints() ? "bio" : "none";
        } catch (Exception e) {
            return "no";
        }
    }

    void off() {
        prefs().edit().clear().apply();
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            ks.deleteEntry(KEY);
        } catch (Exception ignored) { }
    }

    private SecretKey newKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        ks.deleteEntry(KEY);
        KeyGenParameterSpec.Builder b = new KeyGenParameterSpec.Builder(KEY,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(true)
                .setInvalidatedByBiometricEnrollment(true);
        if (Build.VERSION.SDK_INT >= 30)
            b.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG | KeyProperties.AUTH_DEVICE_CREDENTIAL);
        KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        g.init(b.build());
        return g.generateKey();
    }

    private SecretKey loadKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        return (SecretKey) ks.getKey(KEY, null);
    }

    /** Turn on: check the finger once, then keep the secret encrypted on the phone. */
    void enroll(String secret, Done done) {
        a.runOnUiThread(() -> {
            try {
                Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                c.init(Cipher.ENCRYPT_MODE, newKey());
                prompt(c, "Turn on fingerprint for the Vault", "Touch the sensor or look at the phone to confirm",
                        (ok, cph, err) -> {
                            if (!ok) { off(); done.result(false, null, err); return; }
                            try {
                                byte[] ct = cph.doFinal(secret.getBytes(StandardCharsets.UTF_8));
                                prefs().edit().putString("ct", Base64.encodeToString(ct, Base64.NO_WRAP))
                                        .putString("iv", Base64.encodeToString(cph.getIV(), Base64.NO_WRAP)).apply();
                                done.result(true, null, null);
                            } catch (Exception e) { off(); done.result(false, null, "Couldn't save it. Try again."); }
                        });
            } catch (Exception e) {
                off();
                done.result(false, null, "This phone can't use fingerprint for the Vault.");
            }
        });
    }

    /** Unlock: check the finger, then hand back the secret. */
    void unlock(Done done) {
        a.runOnUiThread(() -> {
            String ct = prefs().getString("ct", null), iv = prefs().getString("iv", null);
            if (ct == null || iv == null) { done.result(false, null, "Fingerprint isn't set up. Use your password."); return; }
            try {
                SecretKey k = loadKey();
                if (k == null) { off(); done.result(false, null, "changed"); return; }
                Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                c.init(Cipher.DECRYPT_MODE, k, new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
                prompt(c, "Open the Vault", "Use your fingerprint or face", (ok, cph, err) -> {
                    if (!ok) { done.result(false, null, err); return; }
                    try {
                        String s = new String(cph.doFinal(Base64.decode(ct, Base64.NO_WRAP)), StandardCharsets.UTF_8);
                        done.result(true, s, null);
                    } catch (Exception e) { done.result(false, null, "Couldn't open it. Use your password."); }
                });
            } catch (KeyPermanentlyInvalidatedException e) {
                off();                                   // a new fingerprint was added to the phone
                done.result(false, null, "changed");
            } catch (Exception e) {
                done.result(false, null, "Fingerprint didn't work. Use your password.");
            }
        });
    }

    private interface Prompted { void result(boolean ok, Cipher c, String error); }

    private void prompt(Cipher cipher, String title, String sub, Prompted cb) {
        BiometricPrompt.Builder b = new BiometricPrompt.Builder(a).setTitle(title).setSubtitle(sub);
        if (Build.VERSION.SDK_INT >= 30) {
            b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG
                    | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
        } else {
            b.setNegativeButton("Use password", a.getMainExecutor(), (d, w) -> cb.result(false, null, "cancel"));
        }
        if (Build.VERSION.SDK_INT >= 29) b.setConfirmationRequired(false);
        b.build().authenticate(new BiometricPrompt.CryptoObject(cipher), new CancellationSignal(), a.getMainExecutor(),
                new BiometricPrompt.AuthenticationCallback() {
                    @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                        BiometricPrompt.CryptoObject co = r.getCryptoObject();
                        cb.result(co != null && co.getCipher() != null, co == null ? null : co.getCipher(), null);
                    }
                    @Override public void onAuthenticationError(int code, CharSequence msg) {
                        boolean cancelled = code == BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED
                                || code == BiometricPrompt.BIOMETRIC_ERROR_CANCELED
                                || (Build.VERSION.SDK_INT < 30 && code == BiometricPrompt.BIOMETRIC_ERROR_NEGATIVE_BUTTON);
                        cb.result(false, null, cancelled ? "cancel" : String.valueOf(msg));
                    }
                    // onAuthenticationFailed = one wrong finger; the prompt lets them try again by itself
                });
    }
}
