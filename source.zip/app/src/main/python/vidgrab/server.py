"""Starts VidGrab inside the Android app (called from MainActivity)."""
import json
import os
import shutil
import sys
import threading


def use_newer_engine(pylib):
    """Use a newer yt-dlp that the app downloaded by itself (see engine_check in app.py).
    If it doesn't load, forget it and keep the one built into the app."""
    try:
        with open(os.path.join(pylib, "active.json"), encoding="utf-8") as f:
            active = json.load(f)
        dirs = [os.path.join(pylib, d) for d in active["dirs"]]
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "VERSION"), encoding="utf-8") as f:
            app_version = f.read().strip()
        if active.get("app") != app_version:     # Grabby itself was updated: it brings a fresh engine
            raise LookupError
        if not all(os.path.isdir(d) for d in dirs):
            raise FileNotFoundError
    except LookupError:
        try:
            os.remove(os.path.join(pylib, "active.json"))
        except OSError:
            pass
        return
    except Exception:  # noqa
        return
    for d in reversed(dirs):
        sys.path.insert(0, d)
    try:
        import yt_dlp  # noqa: F401
        import yt_dlp.version  # noqa: F401
    except Exception:  # noqa
        for d in dirs:
            if d in sys.path:
                sys.path.remove(d)
        for m in [m for m in sys.modules if m == "yt_dlp" or m.startswith("yt_dlp.") or m.startswith("yt_dlp_ejs")]:
            del sys.modules[m]
        try:
            os.remove(os.path.join(pylib, "active.json"))
        except OSError:
            pass
        for d in dirs:
            shutil.rmtree(d, ignore_errors=True)


def start(port, data_dir, cache_dir, native_dir=None):
    os.environ["VIDGRAB_ANDROID"] = "1"
    if native_dir:                                   # ffmpeg + QuickJS shipped inside the app
        os.environ["VIDGRAB_NATIVE"] = str(native_dir)
    tmp = os.path.join(str(cache_dir), "tmp")        # temp files (QuickJS scripts, ffmpeg) go in the app's cache
    os.makedirs(tmp, exist_ok=True)
    os.environ["TMPDIR"] = tmp
    import tempfile
    tempfile.tempdir = tmp
    os.environ["VIDGRAB_DATA"] = str(data_dir)
    os.environ["VIDGRAB_CACHE"] = str(cache_dir)
    use_newer_engine(os.path.join(str(data_dir), "pylib"))
    from vidgrab import app as vg          # import after the settings above
    vg.start_background()
    threading.Thread(
        target=lambda: vg.app.run(host="127.0.0.1", port=int(port), threaded=True, use_reloader=False),
        daemon=True,
    ).start()
