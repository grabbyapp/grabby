"""Starts VidGrab inside the Android app (called from MainActivity)."""
import os
import threading


def start(port, data_dir, cache_dir):
    os.environ["VIDGRAB_ANDROID"] = "1"
    os.environ["VIDGRAB_DATA"] = str(data_dir)
    os.environ["VIDGRAB_CACHE"] = str(cache_dir)
    from vidgrab import app as vg          # import after the settings above
    vg.start_background()
    threading.Thread(
        target=lambda: vg.app.run(host="127.0.0.1", port=int(port), threaded=True, use_reloader=False),
        daemon=True,
    ).start()
