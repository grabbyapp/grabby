"""Grabby Vault: videos, music and pictures locked with a password.

Files in the vault are encrypted, so they can't be opened, previewed or found by a gallery or file
manager - only Grabby can show them after the vault is unlocked.

How the lock works (standard library only, so it runs on phones too):
- Your password goes through PBKDF2-SHA256 (200,000 rounds, random salt) to make a key.
- That key unlocks a random 256-bit vault key, so changing the password never re-encrypts files.
- Every file and the list of files are encrypted with the vault key using SHAKE-256 in counter mode,
  with a fresh random nonce per file. Each 64 KB block has its own keystream, so videos can be
  played and skipped through without decrypting the whole file.
Nobody (not even the app maker) can open the vault without the password. Forget it and the files are gone.

Extra ways in (optional, set up after unlocking with the password): a PIN, and the phone's fingerprint / face.
Each one is just another lock around the same vault key, kept in unlock.json:
- PIN: PBKDF2 like the password. 10 wrong PINs in a row turn the PIN off, so the password is needed again.
- Fingerprint: a random 256-bit secret unlocks the vault key; the phone keeps that secret inside Android's
  Keystore, which only hands it over after a successful fingerprint / face check.
"""
import hashlib
import hmac
import json
import os
import secrets
import threading
import time

BLOCK = 64 * 1024
ITERATIONS = 200_000
LOCK = threading.Lock()


def _keystream(key, nonce, block_no, length=BLOCK):
    return hashlib.shake_256(b"grabby-vault-v1" + key + nonce + block_no.to_bytes(8, "little")).digest(length)


def _xor(data, ks):
    n = len(data)
    return (int.from_bytes(data, "little") ^ int.from_bytes(ks[:n], "little")).to_bytes(n, "little")


def crypt_at(key, nonce, offset, data):
    """Encrypt or decrypt `data` that sits at byte `offset` of a file (the same operation both ways)."""
    out = bytearray()
    pos = 0
    while pos < len(data):
        block_no, inner = divmod(offset + pos, BLOCK)
        take = min(BLOCK - inner, len(data) - pos)
        ks = _keystream(key, nonce, block_no)[inner:inner + take]
        out += _xor(data[pos:pos + take], ks)
        pos += take
    return bytes(out)


def _kek(password, salt, iterations):
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations, 32)


class Vault:
    HEADER = 16          # every vault file starts with its 16-byte nonce

    def __init__(self, folder):
        self.dir = folder
        self.meta_path = os.path.join(folder, "vault.json")
        self.index_path = os.path.join(folder, "index.bin")
        self.sessions = {}            # token -> [vault key, last used]
        self.tries = []               # times of wrong passwords (slows down guessing)

    # ---------- setup / unlock
    def is_setup(self):
        return os.path.isfile(self.meta_path)

    def _meta(self):
        with open(self.meta_path, encoding="utf-8") as f:
            return json.load(f)

    def _write_json(self, path, data):
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, path)

    def _wrap(self, password, key, iterations=ITERATIONS):
        salt = secrets.token_bytes(16)
        kek = _kek(password, salt, iterations)
        return {"v": 1, "salt": salt.hex(), "iter": iterations,
                "check": hmac.new(kek, b"grabby-vault-check", "sha256").hexdigest(),
                "wrapped": _xor(key, hashlib.shake_256(kek + b"wrap").digest(32)).hex()}

    def setup(self, password):
        with LOCK:
            if self.is_setup():
                raise ValueError("The vault already has a password.")
            os.makedirs(self.dir, exist_ok=True)
            for f in (".nomedia",):          # Android: never scan this folder for media
                open(os.path.join(self.dir, f), "a").close()
            key = secrets.token_bytes(32)
            self._write_json(self.meta_path, self._wrap(password, key))
            self._save_index(key, [])
        return self._new_session(key)

    @staticmethod
    def _open_wrap(m, secret):
        kek = _kek(secret, bytes.fromhex(m["salt"]), int(m["iter"]))
        if not hmac.compare_digest(hmac.new(kek, b"grabby-vault-check", "sha256").hexdigest(), m["check"]):
            return None
        return _xor(bytes.fromhex(m["wrapped"]), hashlib.shake_256(kek + b"wrap").digest(32))

    def _open_key(self, password):
        return self._open_wrap(self._meta(), password)

    # ---------- extra ways to unlock: PIN and fingerprint
    PIN_MAX_FAILS = 10

    def _extra_path(self):
        return os.path.join(self.dir, "unlock.json")

    def _extra(self):
        try:
            with open(self._extra_path(), encoding="utf-8") as f:
                d = json.load(f)
                return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def methods(self):
        d = self._extra()
        return {"pin": bool(d.get("pin")), "pin_len": int((d.get("pin") or {}).get("len") or 0), "bio": bool(d.get("bio"))}

    def set_pin(self, key, pin):
        with LOCK:
            d = self._extra()
            w = self._wrap(pin, key)
            w["len"] = len(pin)
            d["pin"], d["pin_fails"] = w, 0
            self._write_json(self._extra_path(), d)

    def set_bio(self, key):
        """Turn on fingerprint: returns the secret the phone must keep in its Keystore."""
        secret = secrets.token_hex(32)
        with LOCK:
            d = self._extra()
            d["bio"] = self._wrap(secret, key, iterations=2000)     # the secret is random, so few rounds are fine
            self._write_json(self._extra_path(), d)
        return secret

    def clear_method(self, name):
        with LOCK:
            d = self._extra()
            d.pop(name, None)
            if name == "pin":
                d.pop("pin_fails", None)
            self._write_json(self._extra_path(), d)

    def unlock_with(self, method, secret):
        """method: 'pin' or 'bio'. Returns a session token, or None for a wrong one."""
        if self.too_many_tries():
            raise PermissionError("Too many wrong tries. Wait 5 minutes and try again.")
        d = self._extra()
        w = d.get(method)
        if not w:
            raise LookupError("not set up")
        key = self._open_wrap(w, secret)
        if key is None:
            with LOCK:
                self.tries.append(time.time())
                if method == "pin":
                    d = self._extra()
                    d["pin_fails"] = int(d.get("pin_fails") or 0) + 1
                    if d["pin_fails"] >= self.PIN_MAX_FAILS:      # too many: PIN off, the password is needed
                        d.pop("pin", None)
                        d.pop("pin_fails", None)
                    self._write_json(self._extra_path(), d)
            return None
        with LOCK:
            self.tries = []
            if method == "pin" and d.get("pin_fails"):
                d = self._extra()
                d["pin_fails"] = 0
                self._write_json(self._extra_path(), d)
        return self._new_session(key)

    def too_many_tries(self):
        now = time.time()
        with LOCK:
            self.tries = [t for t in self.tries if now - t < 300]
            return len(self.tries) >= 6

    def unlock(self, password):
        if self.too_many_tries():
            raise PermissionError("Too many wrong passwords. Wait 5 minutes and try again.")
        key = self._open_key(password)
        if key is None:
            with LOCK:
                self.tries.append(time.time())
            return None
        with LOCK:
            self.tries = []
        return self._new_session(key)

    def change_password(self, old, new):
        key = self._open_key(old)
        if key is None:
            return False
        with LOCK:
            self._write_json(self.meta_path, self._wrap(new, key))
        return True

    def _new_session(self, key):
        tok = secrets.token_urlsafe(24)
        self.sessions[tok] = [key, time.time(), 600]
        return tok

    def set_idle(self, token, seconds):
        """How long an unlocked vault may sit unused before it locks itself (30 s to 1 hour)."""
        s = self.sessions.get(token or "")
        if s:
            s[2] = max(30, min(3600, int(seconds)))
        return bool(s)

    def key_for(self, token):
        """The vault key for an unlocked session, or None once it has sat unused too long (auto-lock)."""
        s = self.sessions.get(token or "")
        if not s:
            return None
        if time.time() - s[1] > s[2]:
            self.sessions.pop(token, None)
            return None
        s[1] = time.time()
        return s[0]

    def lock(self, token=None):
        if token:
            self.sessions.pop(token, None)
        else:
            self.sessions.clear()

    def reset(self):
        """Forgot the password: delete everything in the vault."""
        with LOCK:
            self.sessions.clear()
            if os.path.isdir(self.dir):
                for f in os.listdir(self.dir):
                    try:
                        os.remove(os.path.join(self.dir, f))
                    except OSError:
                        pass

    # ---------- the list of files (encrypted too, so names and titles stay private)
    def items(self, key):
        try:
            with open(self.index_path, "rb") as f:
                raw = f.read()
            data = json.loads(crypt_at(key, raw[:16], 0, raw[16:]).decode("utf-8"))
            return data if isinstance(data, list) else []
        except (OSError, ValueError):
            return []

    def _save_index(self, key, items):
        nonce = secrets.token_bytes(16)
        raw = json.dumps(items, ensure_ascii=False).encode("utf-8")
        tmp = self.index_path + ".tmp"
        with open(tmp, "wb") as f:
            f.write(nonce + crypt_at(key, nonce, 0, raw))
        os.replace(tmp, self.index_path)

    def file_path(self, item_id):
        if not item_id or not all(c in "0123456789abcdef" for c in item_id):
            return None
        return os.path.join(self.dir, item_id + ".bin")

    # ---------- putting files in and taking them out
    def add_stream(self, key, read, meta):
        """Encrypt from read(n) into the vault. meta: title, name, kind, ext, (site, duration...)."""
        item_id = secrets.token_hex(12)
        nonce = secrets.token_bytes(16)
        path = self.file_path(item_id)
        size = 0
        try:
            with open(path + ".part", "wb") as out:
                out.write(nonce)
                while True:
                    chunk = read(BLOCK)
                    if not chunk:
                        break
                    if len(chunk) < BLOCK:            # keep blocks aligned for speed
                        more = chunk
                        while len(more) < BLOCK:
                            nxt = read(BLOCK - len(more))
                            if not nxt:
                                break
                            more += nxt
                        chunk = more
                    out.write(crypt_at(key, nonce, size, chunk))
                    size += len(chunk)
            os.replace(path + ".part", path)
        except BaseException:
            try:
                os.remove(path + ".part")
            except OSError:
                pass
            raise
        item = dict(meta, id=item_id, size=size, added=time.time())
        with LOCK:
            items = self.items(key)
            items.insert(0, item)
            self._save_index(key, items)
        return item

    def add_file(self, key, src, meta):
        with open(src, "rb") as f:
            return self.add_stream(key, f.read, meta)

    def get(self, key, item_id):
        return next((i for i in self.items(key) if i.get("id") == item_id), None)

    def read_range(self, key, item_id, start, end):
        """Yield decrypted bytes start..end (inclusive) of a vault file."""
        path = self.file_path(item_id)
        with open(path, "rb") as f:
            nonce = f.read(self.HEADER)
            f.seek(self.HEADER + start)
            pos = start
            while pos <= end:
                n = min(BLOCK - (pos % BLOCK), end - pos + 1)
                data = f.read(n)
                if not data:
                    break
                yield crypt_at(key, nonce, pos, data)
                pos += len(data)

    def export(self, key, item_id, dest):
        it = self.get(key, item_id)
        with open(dest, "wb") as out:
            for chunk in self.read_range(key, item_id, 0, max(0, it["size"] - 1)):
                out.write(chunk)

    def remove(self, key, ids):
        ids = set(ids)
        with LOCK:
            items = self.items(key)
            keep = [i for i in items if i.get("id") not in ids]
            for i in items:
                if i.get("id") in ids:
                    try:
                        os.remove(self.file_path(i["id"]))
                    except OSError:
                        pass
            self._save_index(key, keep)
        return len(items) - len(keep)

    def rename(self, key, item_id, new_title):
        with LOCK:
            items = self.items(key)
            for it in items:
                if it.get("id") == item_id:
                    it["title"] = new_title
                    self._save_index(key, items)
                    return it
        return None
