"""
Grabby 2.0 - paste or share a link, get an HD MP4 or MP3.
Works with Facebook, Instagram, X/Twitter, TikTok, YouTube, Reddit, Vimeo and
~1,800 other sites (powered by yt-dlp).

Run:   python app.py            (or double-click start-windows.bat)
Open:  http://localhost:5000
Phone: http://<this-computer's-IP>:5000  (same Wi-Fi)
"""
import copy
import importlib
import json
import os
import re
import secrets
import subprocess
import zipfile
import zlib
import shutil
import socket
import tempfile
import threading
import time
import sys
import uuid
import webbrowser
from datetime import datetime, timedelta
from urllib.parse import urlencode

from flask import (Flask, Response, jsonify, redirect, render_template,
                   request, send_file, send_from_directory, session)
import hashlib
import hmac
import yt_dlp

try:
    from yt_dlp.utils import download_range_func
except ImportError:  # very old yt-dlp
    download_range_func = None

BASE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder=os.path.join(BASE, "static"),
            template_folder=os.path.join(BASE, "templates"))
app.config["TEMPLATES_AUTO_RELOAD"] = True      # page/design updates apply without a restart
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0     # always serve the newest CSS/JS

try:
    with open(os.path.join(BASE, "VERSION"), encoding="utf-8") as _f:
        APP_VERSION = _f.read().strip() or "4.1"
except OSError:
    APP_VERSION = "4.1"
ANDROID = os.getenv("VIDGRAB_ANDROID") == "1"          # running inside the Android app
DESKTOP = os.getenv("VIDGRAB_DESKTOP") == "1"          # the Windows app people download (Grabby.exe)
DATA_DIR = os.getenv("VIDGRAB_DATA") or BASE
CONFIG_PATH = os.path.join(DATA_DIR, "config.json")
COOKIES_PATH = os.path.join(DATA_DIR, "cookies.txt")   # phone app: written when you sign in to a site
UPLOAD_DIR = os.path.join(BASE, "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
DEFAULT_CONFIG = {
    "message": "Grabby is free. If it saved you time, a small tip keeps it running!",
    "gcash_number": "",
    "maya_number": "",
    "paypal_me": "",          # just the username from paypal.me/USERNAME
    "kofi": "",               # just the username from ko-fi.com/USERNAME
    "custom_label": "", "custom_url": "",
    "ask_every": 5,           # Grabby asks for a tip after every N downloads (0 = never)
    "cup_price": 20,          # price of one "coffee" in pesos on the tip widget
    "qrph": "",               # the text inside your GCash QR (QR Ph), so Grabby can make QRs with the amount filled in
}


QRPH_TRIED = {}


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    if ANDROID or DESKTOP:   # the phone / Windows app uses the tip details that were built into it
        try:
            with open(os.path.join(BASE, "tips.json"), encoding="utf-8") as f:
                cfg.update({k: v for k, v in json.load(f).items() if k in DEFAULT_CONFIG})
        except (OSError, ValueError, AttributeError):
            pass
        cfg["gcash_qr"] = "/static/tip-qr.png" if os.path.exists(os.path.join(BASE, "static", "tip-qr.png")) else ""
        return cfg
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            saved = json.load(f)
        # only known keys are used, so no personal names are ever shown
        cfg.update({k: v for k, v in saved.items() if k in DEFAULT_CONFIG})
    except (OSError, ValueError, AttributeError):
        pass
    cfg["gcash_qr"] = "/static/uploads/gcash-qr.png" if os.path.exists(os.path.join(UPLOAD_DIR, "gcash-qr.png")) else ""
    if cfg["gcash_qr"] and not cfg.get("qrph") and not QRPH_TRIED.get("done"):
        QRPH_TRIED["done"] = True                 # read the picture once, not on every page load
        cfg["qrph"] = read_qr_image(os.path.join(UPLOAD_DIR, "gcash-qr.png"))
        if cfg["qrph"]:
            try:
                set_config_value("qrph", cfg["qrph"])
            except OSError:
                pass
    return cfg


def read_qr_image(path):
    """The text inside a QR picture (needs OpenCV, which the PC app may have). Empty if it can't be read."""
    try:
        import cv2
        text, _, _ = cv2.QRCodeDetector().detectAndDecode(cv2.imread(path))
        return text if text.startswith("000201") else ""
    except Exception:  # noqa
        return ""


# ---- Tip QR with the amount filled in. GCash QRs are "QR Ph" codes, which GCash, Maya and
#      Philippine bank apps all read. Adding the amount (tag 54) makes the payer's app fill it in.
def _emv_crc(s):
    c = 0xFFFF
    for b in s.encode("utf-8"):
        c ^= b << 8
        for _ in range(8):
            c = ((c << 1) ^ 0x1021) if c & 0x8000 else c << 1
            c &= 0xFFFF
    return f"{c:04X}"


def _emv_fields(payload):
    out, i = [], 0
    while i + 4 <= len(payload):
        tag, n = payload[i:i + 2], int(payload[i + 2:i + 4])
        out.append([tag, payload[i + 4:i + 4 + n]])
        i += 4 + n
    return out


def qrph_with_amount(payload, amount):
    fields = [f for f in _emv_fields(payload) if f[0] not in ("54", "63")]
    if not fields or fields[0] != ["00", "01"]:
        raise ValueError("not a QR Ph code")
    for f in fields:
        if f[0] == "01":
            f[1] = "12"                      # 12 = a one-time QR with an amount
    fields.append(["54", f"{amount:.2f}"])
    fields.sort(key=lambda f: int(f[0]) if f[0] != "00" else -1)
    body = "".join(f"{t}{len(v):02d}{v}" for t, v in fields) + "6304"
    return body + _emv_crc(body)


def qr_png(text, scale=10, border=4):
    """A QR code as a PNG picture (standard library only), for saving to the phone's gallery."""
    import struct
    try:
        from qr import qr_matrix
    except ImportError:
        from .qr import qr_matrix
    m = qr_matrix(text)
    n = len(m) + border * 2
    size = n * scale
    rows = []
    for y in range(n):
        line = bytearray([0])
        for x in range(n):
            on = border <= x < n - border and border <= y < n - border and m[y - border][x - border]
            line += (b"\x00" if on else b"\xff") * scale
        rows.extend([bytes(line)] * scale)

    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 0, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(b"".join(rows), 9)) + chunk(b"IEND", b""))


@app.get("/api/tip/qr")
def api_tip_qr():
    """GCash / Maya QR for a tip with the amount already filled in. ?amount=60&fmt=png|svg"""
    payload = load_config().get("qrph") or ""
    try:
        amount = round(float(request.args.get("amount", "0")), 2)
    except ValueError:
        amount = 0
    if not payload or not (1 <= amount <= 100000):
        return "No tip QR", 404
    try:
        text = qrph_with_amount(payload, amount)
    except ValueError:
        return "No tip QR", 404
    if request.args.get("fmt") == "png":
        name = f"grabby-tip-{int(amount) if amount == int(amount) else amount}-pesos.png"
        return Response(qr_png(text), mimetype="image/png", headers={
            "Content-Disposition": f'attachment; filename="{name}"' if request.args.get("dl") else f'inline; filename="{name}"',
            "Cache-Control": "no-store"})
    try:
        from qr import qr_svg as _svg
    except ImportError:
        from .qr import qr_svg as _svg
    return Response(_svg(text, scale=6), mimetype="image/svg+xml", headers={"Cache-Control": "no-store"})


# ---- owner login: use every feature from your phone or anywhere, with a password
OWNER_PATH = os.path.join(DATA_DIR, "owner.json")       # kept apart from config.json, never sent to the page
SECRET_PATH = os.path.join(DATA_DIR, "secret.key")
LOGIN_TRIES = {}                                         # ip -> [times of failed tries]


def _secret():
    try:
        with open(SECRET_PATH, "rb") as f:
            k = f.read()
        if len(k) >= 32:
            return k
    except OSError:
        pass
    k = secrets.token_bytes(32)
    try:
        with open(SECRET_PATH, "wb") as f:
            f.write(k)
    except OSError:
        pass
    return k


app.secret_key = _secret()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  PERMANENT_SESSION_LIFETIME=60 * 60 * 24 * 30)     # stay logged in for 30 days


def owner_data():
    try:
        with open(OWNER_PATH, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def owner_save(d):
    with open(OWNER_PATH, "w", encoding="utf-8") as f:
        json.dump(d, f)


def pw_hash(pw, salt=None):
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), bytes.fromhex(salt), 200_000).hex()
    return f"{salt}${h}"


def pw_check(pw, stored):
    try:
        salt, h = stored.split("$", 1)
    except (AttributeError, ValueError):
        return False
    return hmac.compare_digest(pw_hash(pw, salt).split("$", 1)[1], h)


def pw_version():
    s = owner_data().get("pw") or ""
    return hashlib.sha256(s.encode()).hexdigest()[:16] if s else ""


def client_ip():
    return (request.headers.get("Cf-Connecting-Ip") or (request.headers.get("X-Forwarded-For") or "").split(",")[0].strip()
            or request.remote_addr or "?")


def is_owner():
    """The computer running Grabby, or someone who logged in with the owner password."""
    if ANDROID or DESKTOP:
        return False      # tip settings and owner tools are built into the phone / Windows app
    if is_local():
        return True
    v = pw_version()
    return bool(v) and session.get("owner") == v


def is_local():
    """True only for a browser on this very computer (not a tunnel or Wi-Fi visitor)."""
    if request.remote_addr not in ("127.0.0.1", "::1"):
        return False
    # Visitors through a tunnel or proxy (dev tunnels, ngrok, Cloudflare...) also
    # arrive from 127.0.0.1, so the address they typed must be this computer too.
    host = (request.host or "").rsplit(":", 1)[0].strip("[]").lower()
    if host not in ("localhost", "127.0.0.1", "::1"):
        return False
    forwarded = ("X-Forwarded-For", "X-Forwarded-Host", "Forwarded", "X-Real-IP", "X-Original-Host")
    return not any(request.headers.get(h) for h in forwarded)


# ---- fast "finding": each link is looked up once, then reused for the download
INFO_CACHE = {}          # url -> (time, info)
INFO_INFLIGHT = {}       # url -> Event while a lookup is running
INFO_LOCK = threading.Lock()
INFO_TTL = 600           # reuse a lookup for 10 minutes


def base_opts():
    o = {"quiet": True, "no_warnings": True, "noplaylist": True,
         "socket_timeout": 15, "extractor_retries": 2}
    o.update(tool_opts())
    cookie = os.path.join(BASE, "cookies.txt")
    if os.path.exists(cookie):
        o["cookiefile"] = cookie
    return o


def get_info(url):
    """Look up a link once. Parallel requests for the same link wait for the
    first lookup instead of starting another one."""
    with INFO_LOCK:
        hit = INFO_CACHE.get(url)
        if hit and time.time() - hit[0] < INFO_TTL:
            return copy.deepcopy(hit[1])
        ev = INFO_INFLIGHT.get(url)
        owner = ev is None
        if owner:
            ev = INFO_INFLIGHT[url] = threading.Event()
    if not owner:
        ev.wait(90)
        with INFO_LOCK:
            hit = INFO_CACHE.get(url)
        if hit:
            return copy.deepcopy(hit[1])
    try:
        with yt_dlp.YoutubeDL(dict(base_opts(), ignore_no_formats_error=True)) as ydl:
            info = ydl.extract_info(url, download=False)
        if info.get("_type") == "playlist" and info.get("entries"):
            info = next(e for e in info["entries"] if e)
        with INFO_LOCK:
            INFO_CACHE[url] = (time.time(), info)
            if len(INFO_CACHE) > 60:   # keep the cache small
                for k in sorted(INFO_CACHE, key=lambda k: INFO_CACHE[k][0])[:20]:
                    INFO_CACHE.pop(k, None)
        return copy.deepcopy(info)
    finally:
        if owner:
            with INFO_LOCK:
                INFO_INFLIGHT.pop(url, None)
            ev.set()


def warm_up():
    """Load the most used site readers in the background so the first link is fast."""
    for mod in ("facebook", "instagram", "twitter", "tiktok", "youtube", "generic"):
        try:
            importlib.import_module("yt_dlp.extractor." + mod)
        except Exception:  # noqa
            pass


DOWNLOAD_DIR = os.path.join(os.getenv("VIDGRAB_CACHE") or tempfile.gettempdir(), "vidgrab")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)
JOBS = {}
MAX_PARALLEL = 3                                   # downloads that run at the same time; the rest wait in line
RUN_SLOTS = threading.BoundedSemaphore(MAX_PARALLEL)
PLAYLIST_RE = re.compile(r"[?&]list=|/playlist|/sets/|/showcase/|/album/|/channel/|/c/|/user/|/@[^/?#]+/?(videos|shorts|streams)?/?(\?|$)"
                         r"|tiktok\.com/@[^/?#]+/?(\?|$)|instagram\.com/[^/?#]+/reels?/?$", re.I)

# ---- My Videos: finished downloads are kept here for good (only on this computer / in the phone app)
if ANDROID:
    LIBRARY_DIR = os.path.join(DATA_DIR, "library")
else:
    _videos = os.path.join(os.path.expanduser("~"), "Videos")
    _home = _videos if os.path.isdir(_videos) else os.path.expanduser("~")
    LIBRARY_DIR = os.getenv("VIDGRAB_LIBRARY") or os.path.join(_home, "Grabby")
    _old = os.path.join(_home, "VidGrab")             # the app used to be called VidGrab: move old videos over
    if not os.getenv("VIDGRAB_LIBRARY") and os.path.isdir(_old) and not os.path.exists(LIBRARY_DIR):
        try:
            os.rename(_old, LIBRARY_DIR)
        except OSError:
            LIBRARY_DIR = _old
LIBRARY_INDEX = os.path.join(LIBRARY_DIR, ".library.json")
LIB_LOCK = threading.Lock()
MEDIA_EXT = {".mp4": "video", ".webm": "video", ".mkv": "video", ".mov": "video", ".m4v": "video",
             ".mp3": "audio", ".m4a": "audio", ".opus": "audio", ".ogg": "audio", ".wav": "audio", ".aac": "audio", ".flac": "audio",
             ".jpg": "photo", ".jpeg": "photo", ".png": "photo", ".webp": "photo", ".gif": "photo"}
LIB_SETTINGS = os.path.join(LIBRARY_DIR, ".settings.json")
SHARES = {}            # token -> (file name, expires)   for "Send to phone"


def lib_settings():
    try:
        with open(LIB_SETTINGS, encoding="utf-8") as f:
            s = json.load(f)
    except (OSError, ValueError):
        s = {}
    return {"autosort": s.get("autosort") if s.get("autosort") in ("off", "site", "type") else "off"}


def auto_folder(job, name):
    mode = lib_settings()["autosort"]
    if mode == "site":
        return job.get("site") or ""
    if mode == "type":
        return {"video": "Videos", "audio": "Music", "photo": "Photos"}.get(MEDIA_EXT.get(os.path.splitext(name)[1].lower()), "")
    return ""


def lib_subs(name):
    """Subtitle files kept next to a video:  Title.en.vtt"""
    base = os.path.splitext(name)[0]
    try:
        return sorted(f for f in os.listdir(LIBRARY_DIR) if f.startswith(base + ".") and f.endswith(".vtt"))
    except OSError:
        return []


def library_allowed():
    """Only the person using this computer (or the phone app) can see, play and delete saved videos.
    Visitors through a tunnel or the Wi-Fi link never see your library."""
    return ANDROID or (DESKTOP and is_local()) or is_owner()


def lib_read_index():
    try:
        with open(LIBRARY_INDEX, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def lib_write_index(data):
    tmp = LIBRARY_INDEX + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, LIBRARY_INDEX)


def lib_unique(name):
    base, ext = os.path.splitext(name)
    out, n = name, 2
    while os.path.exists(os.path.join(LIBRARY_DIR, out)):
        out = f"{base} ({n}){ext}"; n += 1
    return out


def lib_add(job, path, name=None, extra=None, subs=()):
    """Move a finished file into My Videos and remember where it came from."""
    os.makedirs(LIBRARY_DIR, exist_ok=True)
    name = lib_unique(name or job["name"])
    dest = os.path.join(LIBRARY_DIR, name)
    shutil.move(path, dest)
    for s in subs:                               # keep subtitles next to the video
        lang = os.path.basename(s).split(".")[-2] if s.count(".") >= 2 else "sub"
        try:
            shutil.move(s, os.path.join(LIBRARY_DIR, f"{os.path.splitext(name)[0]}.{lang}.vtt"))
        except OSError:
            pass
    meta = {"title": job.get("title"), "site": job.get("site"), "url": job.get("url"),
            "thumbnail": job.get("thumbnail"), "label": job.get("label"), "added": time.time(),
            "folder": auto_folder(job, name)}
    if MEDIA_EXT.get(os.path.splitext(name)[1].lower()) in ("video", "audio") and has_ffmpeg():
        meta["duration"] = media_duration(dest)
    meta.update(extra or {})
    with LIB_LOCK:
        idx = lib_read_index()
        idx[name] = meta
        try:
            lib_write_index(idx)
        except OSError:
            pass
    return dest, name


def lib_path(name):
    """Safe path for a file name from the browser (no folders, no hidden files)."""
    name = name or ""
    if name != os.path.basename(name) or name.startswith(".") or os.path.splitext(name)[1].lower() not in MEDIA_EXT:
        return None
    p = os.path.join(LIBRARY_DIR, name)
    return p if os.path.isfile(p) else None


FILE_TTL = 3600          # finished files are kept for 1 hour (so "Save again" works)
URL_RE = re.compile(r"https?://[^\s<>\"']+")
ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


class Cancelled(Exception):
    pass


# ------------------------------------------------------------------ helpers
def find_ffmpeg():
    """Find ffmpeg even right after `winget install` (before Windows refreshes PATH)."""
    if shutil.which("ffmpeg"):
        return True
    if os.name == "nt":
        import glob
        local = os.environ.get("LOCALAPPDATA", "")
        spots = [os.path.join(local, "Microsoft", "WinGet", "Links")]
        spots += glob.glob(os.path.join(local, "Microsoft", "WinGet", "Packages", "*FFmpeg*", "*", "bin"))
        spots += [r"C:\ffmpeg\bin", r"C:\Program Files\ffmpeg\bin"]
        for d in spots:
            if os.path.exists(os.path.join(d, "ffmpeg.exe")):
                os.environ["PATH"] = d + os.pathsep + os.environ.get("PATH", "")
                return True
    return False


FFMPEG_EXE = None      # ffmpeg from the imageio-ffmpeg package (PC) or built into the phone app
QJS_EXE = None         # QuickJS JavaScript engine built into the phone app (YouTube needs a JS engine)


def native_tool(name):
    """A helper program shipped inside the phone app (installed by Android as lib<name>.so)."""
    d = os.getenv("VIDGRAB_NATIVE")
    p = os.path.join(d, f"lib{name}.so") if d else ""
    return p if p and os.path.isfile(p) and os.access(p, os.X_OK) else None


def setup_tools():
    """Make the YouTube helper (Deno / QuickJS) and ffmpeg available to yt-dlp.
    On the PC both come from pip packages; the phone app has them built in."""
    global FFMPEG_EXE, QJS_EXE
    if ANDROID:
        FFMPEG_EXE = native_tool("ffmpeg")
        QJS_EXE = native_tool("qjs")
        return
    q = os.getenv("VIDGRAB_QJS")            # Windows app: QuickJS ships inside Grabby.exe
    if q and os.path.isfile(q):
        QJS_EXE = q
    try:   # Deno: needed for full YouTube support (yt-dlp 2025.11+)
        import deno
        p = deno.find_deno_bin()
        if p and os.path.exists(p):
            os.environ["PATH"] = os.path.dirname(p) + os.pathsep + os.environ.get("PATH", "")
    except Exception:  # noqa
        pass
    if not find_ffmpeg():
        try:
            import imageio_ffmpeg
            FFMPEG_EXE = imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:  # noqa
            FFMPEG_EXE = None


def has_ffmpeg():
    return shutil.which("ffmpeg") is not None or find_ffmpeg() or bool(FFMPEG_EXE)


def ff_exe():
    return shutil.which("ffmpeg") or FFMPEG_EXE or "ffmpeg"


NO_WINDOW = 0x08000000 if os.name == "nt" else 0     # no black console windows on Windows


def media_duration(path):
    """Length in seconds, read from ffmpeg's report (no ffprobe needed)."""
    try:
        r = subprocess.run([ff_exe(), "-hide_banner", "-i", path], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=20, creationflags=NO_WINDOW)
        m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", r.stderr)
        if m:
            return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    except (OSError, subprocess.SubprocessError):
        pass
    return None


def run_ff(args, job=None, dur=None, stage="Processing", cwd=None):
    """Run ffmpeg and show its progress on the job card. Raises on failure or cancel."""
    cmd = [ff_exe(), "-hide_banner", "-y", "-nostdin", "-progress", "pipe:1", "-nostats"] + args
    pr = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8",
                          errors="replace", cwd=cwd, creationflags=NO_WINDOW)
    err = []
    threading.Thread(target=lambda: err.extend(pr.stderr.read().splitlines()[-12:]), daemon=True).start()
    for line in pr.stdout:
        if job is not None:
            if job.get("cancel"):
                pr.kill(); raise Cancelled()
            if line.startswith("out_time_us=") or line.startswith("out_time_ms="):
                try:
                    t = int(line.split("=")[1]) / 1e6
                    if dur:
                        job.update(status="processing", stage=stage, percent=round(min(99, t * 100 / dur), 1))
                except ValueError:
                    pass
    pr.wait()
    if pr.returncode != 0:
        raise RuntimeError("ffmpeg failed: " + (" ".join(err[-2:]) or "unknown error"))


SHRINK_TARGET = 24 * 1024 * 1024     # Messenger allows 25 MB


def shrink_video(src, dst, job=None):
    """Make a copy small enough for Messenger/Viber. Returns the new path (or src if already small)."""
    if os.path.getsize(src) <= SHRINK_TARGET:
        return src
    dur = media_duration(src) or 60
    for factor in (0.92, 0.75, 0.6):
        kbps = max(120, int(SHRINK_TARGET * 8 / dur / 1000 * factor) - 96)
        side = 1280 if kbps > 1100 else 960 if kbps > 650 else 720 if kbps > 380 else 540
        scale = f"scale='if(gt(iw,ih),min({side},iw),-2)':'if(gt(iw,ih),-2,min({side},ih))'"
        run_ff(["-i", src, "-vf", scale, "-c:v", "libx264", "-preset", "veryfast", "-b:v", f"{kbps}k",
                "-maxrate", f"{int(kbps * 1.3)}k", "-bufsize", f"{kbps * 2}k", "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", "96k", "-ac", "2", "-movflags", "+faststart", dst],
               job, dur, "Shrinking for Messenger")
        if os.path.getsize(dst) <= 25 * 1024 * 1024:
            return dst
    return dst


def tool_opts():
    """Options every yt-dlp call gets: ffmpeg location and JavaScript runtimes."""
    o = {
        # use whichever JavaScript engine is installed (Deno first)
        "js_runtimes": {"quickjs": {"path": QJS_EXE}} if QJS_EXE else {"deno": {}, "node": {}, "bun": {}},
        # if the helper scripts are missing, yt-dlp may fetch the official ones
        "remote_components": {"ejs:github"},
    }
    if FFMPEG_EXE and not shutil.which("ffmpeg"):
        o["ffmpeg_location"] = FFMPEG_EXE
    if ANDROID and os.path.isfile(COOKIES_PATH) and os.path.getsize(COOKIES_PATH) > 40:
        o["cookiefile"] = COOKIES_PATH      # sites you signed in to (Settings > Sign in to sites)
    return o


def clean_error(e):
    msg = ANSI_RE.sub("", str(e)).replace("ERROR: ", "").strip()
    low = msg.lower()
    if "drm" in low:
        return "This video is DRM-protected (like Netflix, Disney+ or Spotify), so no downloader app can save it."
    if "not a bot" in low:
        return "YouTube wants to check you're not a bot. Wait a few minutes or switch between Wi-Fi and mobile data, then try again."
    if "javascript runtime" in low or "n challenge" in low or "signature solving" in low:
        return "YouTube changed something. Update Grabby (Settings > Check for updates), then try again."
    if "impersonat" in low:
        return "This site blocked the download for now. Try again in a little while."
    if "login" in low or "private" in low or "cookies" in low or "rate-limit" in low:
        if ANDROID:
            return ("This post is private or the site wants you logged in. Go to Settings > Sign in to sites, "
                    "sign in with your account, then try again.")
        msg += " - this post may be private or need a login (see README: cookies)."
    elif "unsupported url" in low:
        msg = "That site or link type isn't supported."
    elif "http error 404" in low:
        msg = "Video not found - the link may be broken or the post was deleted."
    return msg[:400]


def safe_name(name):
    name = re.sub(r'[\\/:*?"<>|\n\r\t]+', " ", name or "video").strip()
    return name[:90] or "video"


def parse_time(v):
    """'90', '1:30', '0:01:30.5' -> seconds, '' -> None."""
    v = (str(v) if v is not None else "").strip()
    if not v:
        return None
    if not re.fullmatch(r"\d{1,3}(:\d{1,2}){0,2}(\.\d+)?", v):
        raise ValueError(f"Invalid time '{v}'. Use 1:30 or 90.")
    s = 0.0
    for p in v.split(":"):
        s = s * 60 + float(p)
    return s


def extract_url(text):
    m = URL_RE.search(text or "")
    return m.group(0).rstrip(".,)") if m else ""


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"


def job_public(job):
    keys = ("id", "status", "stage", "percent", "part", "parts", "downloaded",
            "total", "speed", "eta", "title", "thumbnail", "site", "kind",
            "label", "error", "name", "size", "elapsed", "saved_to_library", "count", "tool", "lib_names")
    out = {k: job.get(k) for k in keys}
    out["elapsed"] = round(time.time() - job["created"], 1)
    return out


setup_tools()


# ------------------------------------------------------------------ yt-dlp options
def build_opts(job):
    o = job["opts"]
    ff = has_ffmpeg()
    jid = job["id"]

    def progress(d):
        if job["cancel"]:
            raise Cancelled()
        if d["status"] == "downloading":
            info = d.get("info_dict") or {}
            is_audio = info.get("vcodec") == "none" or o["kind"] == "audio"
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            done = d.get("downloaded_bytes") or 0
            if total:
                part_pct = done * 100 / total
            elif d.get("fragment_count"):
                part_pct = (d.get("fragment_index") or 0) * 100 / d["fragment_count"]
            else:
                part_pct = 0
            parts = max(job["parts"], 1)
            job.update(
                status="downloading",
                stage="Downloading audio" if is_audio else "Downloading video",
                percent=round(min(99.0, ((job["part"] - 1) * 100 + part_pct) / parts), 1),
                downloaded=done, total=total,
                speed=d.get("speed"), eta=d.get("eta"),
            )
        elif d["status"] == "finished":
            if job["part"] < job["parts"]:
                job["part"] += 1
                job.update(stage="Starting next part", speed=None, eta=None)
            else:
                job.update(stage="Finishing up", speed=None, eta=None)

    def post(d):
        if job["cancel"]:
            raise Cancelled()
        if d["status"] == "started":
            name = d.get("postprocessor") or ""
            stage = {
                "Merger": "Merging video + audio",
                "ExtractAudio": "Converting to MP3",
                "VideoConvertor": "Converting to MP4",
                "VideoRemuxer": "Packing MP4",
                "FixupM3u8": "Fixing video",
            }.get(name, "Processing")
            job.update(status="processing", stage=stage, percent=99, speed=None, eta=None)

    opts = {
        "outtmpl": os.path.join(DOWNLOAD_DIR, f"{jid}.%(ext)s"),
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "noprogress": True,
        "progress_hooks": [progress],
        "postprocessor_hooks": [post],
        "retries": 5,
        "fragment_retries": 5,
        "concurrent_fragment_downloads": 8,
        "socket_timeout": 15,
    }
    cookie = os.path.join(BASE, "cookies.txt")
    if os.path.exists(cookie):
        opts["cookiefile"] = cookie
    opts.update(tool_opts())

    if o["kind"] == "audio":
        if ff and o["audio"] == "mp3":
            opts["format"] = "bestaudio/best"
            opts["postprocessors"] = [{"key": "FFmpegExtractAudio",
                                       "preferredcodec": "mp3",
                                       "preferredquality": o["abr"]}]
        else:
            opts["format"] = "bestaudio[ext=m4a]/bestaudio/best"
    else:
        h = int(o["quality"]) if str(o["quality"]).isdigit() else 4320
        if ff:
            opts["format"] = (f"bv*[height<={h}][ext=mp4]+ba[ext=m4a]/"
                              f"bv*[height<={h}]+ba/b[height<={h}]/bv*+ba/b")
            opts["merge_output_format"] = "mp4"
            opts["postprocessors"] = [{"key": "FFmpegVideoConvertor", "preferedformat": "mp4"}]
        else:
            opts["format"] = f"b[height<={h}][ext=mp4]/b[ext=mp4]/b/bv*"

    subs = o.get("subs", "off")
    if o["kind"] == "video" and subs != "off":
        langs = {"en": ["en.*", "en"], "tl": ["tl", "fil", "tl.*", "fil.*"], "ko": ["ko.*", "ko"],
                 "ja": ["ja.*", "ja"], "zh": ["zh.*", "zh"], "es": ["es.*", "es"]}.get(o.get("sublang"), ["en.*", "en"])
        opts.update(writesubtitles=True, writeautomaticsub=True, subtitleslangs=langs, subtitlesformat="vtt/srt/best")
        if ff:
            opts.setdefault("postprocessors", [])
            opts["postprocessors"].insert(0, {"key": "FFmpegSubtitlesConvertor", "format": "vtt"})
            if subs == "player" and not job.get("library"):     # visitors get the subtitles inside the MP4
                opts["postprocessors"].append({"key": "FFmpegEmbedSubtitle", "already_have_subtitle": False})

    if ff and download_range_func and (o["start"] is not None or o["end"] is not None):
        opts["download_ranges"] = download_range_func(
            None, [(o["start"] or 0, o["end"] if o["end"] is not None else float("inf"))])
        opts["force_keyframes_at_cuts"] = True
    return opts


def find_output(jid):
    files = [f for f in os.listdir(DOWNLOAD_DIR)
             if f.startswith(jid) and not f.endswith((".part", ".ytdl", ".temp", ".vtt", ".srt", ".ass", ".json"))
             and ".part-Frag" not in f]
    if not files:
        return None
    files.sort(key=lambda f: os.path.getsize(os.path.join(DOWNLOAD_DIR, f)), reverse=True)
    return os.path.join(DOWNLOAD_DIR, files[0])


def remove_job_files(jid):
    for f in os.listdir(DOWNLOAD_DIR):
        if f.startswith(jid):
            try:
                os.remove(os.path.join(DOWNLOAD_DIR, f))
            except OSError:
                pass


def best_image(entry):
    """The biggest picture of a post / slide."""
    imgs = [f for f in (entry.get("formats") or []) if f.get("url") and
            (f.get("vcodec") in (None, "none") and f.get("acodec") in (None, "none")) and
            (f.get("ext") in ("jpg", "jpeg", "png", "webp") or "image" in str(f.get("format_note") or ""))]
    thumbs = [t for t in (entry.get("thumbnails") or []) if t.get("url")]
    def area(t):
        return (t.get("width") or 0) * (t.get("height") or 0) or (t.get("preference") or 0) * 1000
    cands = sorted(imgs, key=area) or sorted(thumbs, key=lambda t: (area(t), thumbs.index(t)))
    if cands:
        return cands[-1]["url"]
    return entry.get("thumbnail")


def run_photo_job(job):
    """Photo mode: saves every picture of a post (all carousel slides), or a video's thumbnail."""
    job.update(status="fetching", stage="Finding the photos")
    o = dict(base_opts(), noplaylist=False, ignore_no_formats_error=True)
    with yt_dlp.YoutubeDL(o) as ydl:
        info = ydl.extract_info(job["url"], download=False)
        entries = [e for e in (info.get("entries") or [info]) if e]
        urls = []
        for e in entries:
            u = best_image(e)
            if u and u not in urls:
                urls.append(u)
        if not urls:
            raise RuntimeError("No photos found in this post.")
        job.update(title=job.get("title") or info.get("title") or "photo", thumbnail=job.get("thumbnail") or urls[0],
                   site=job.get("site") or info.get("extractor_key"), status="downloading", stage="Saving photos")
        paths = []
        for i, u in enumerate(urls):
            if job["cancel"]:
                raise Cancelled()
            data = ydl.urlopen(u).read()
            ext = ".png" if data[:8] == b"\x89PNG\r\n\x1a\n" else ".webp" if data[8:12] == b"WEBP" else ".gif" if data[:3] == b"GIF" else ".jpg"
            p = os.path.join(DOWNLOAD_DIR, f"{job['id']}_{i + 1:02d}{ext}")
            with open(p, "wb") as f:
                f.write(data)
            paths.append(p)
            job.update(percent=round((i + 1) * 100 / len(urls), 1), downloaded=sum(os.path.getsize(x) for x in paths))
    base = safe_name(job["opts"]["filename"] or job["title"])
    job["count"] = len(paths)
    if job.get("library"):
        names = []
        for i, p in enumerate(paths):
            n = base + (f" ({i + 1})" if len(paths) > 1 else "") + os.path.splitext(p)[1]
            dest, n = lib_add(job, p, n)
            names.append(n)
        job.update(file=os.path.join(LIBRARY_DIR, names[0]), name=names[0], lib_names=names, saved_to_library=True,
                   size=sum(os.path.getsize(os.path.join(LIBRARY_DIR, n)) for n in names))
    elif len(paths) == 1:
        job.update(file=paths[0], name=base + os.path.splitext(paths[0])[1], size=os.path.getsize(paths[0]))
    else:                                        # many photos: one zip to save
        zp = os.path.join(DOWNLOAD_DIR, job["id"] + ".zip")
        with zipfile.ZipFile(zp, "w") as z:
            for i, p in enumerate(paths):
                z.write(p, f"{base} ({i + 1}){os.path.splitext(p)[1]}")
        job.update(file=zp, name=base + ".zip", size=os.path.getsize(zp))
    job.update(status="done", stage="Done!", percent=100, speed=None, eta=None)


def run_job(job):
    job.update(status="queued", stage="Waiting in line")
    with RUN_SLOTS:
        if job["cancel"]:
            job.update(status="cancelled", stage="Cancelled"); return
        _run_job(job)


def _run_job(job):
    if job["kind"] == "photo":
        try:
            run_photo_job(job)
        except Exception as e:  # noqa
            if job["cancel"] or isinstance(e, Cancelled):
                job.update(status="cancelled", stage="Cancelled", speed=None, eta=None)
            else:
                job.update(status="error", stage="Failed", error=clean_error(e), speed=None, eta=None)
            remove_job_files(job["id"])
        return
    try:
        with yt_dlp.YoutubeDL(build_opts(job)) as ydl:
            job.update(status="fetching", stage="Finding the video")
            info = get_info(job["url"])          # instant if the preview already found it
            job.update(
                title=info.get("title") or "video",
                thumbnail=info.get("thumbnail"),
                site=info.get("extractor_key"),
                parts=len(info.get("requested_formats") or []) or 1,
                part=1,
            )
            if job["cancel"]:
                raise Cancelled()
            try:
                ydl.process_ie_result(info, download=True)
            except Cancelled:
                raise
            except Exception:  # noqa – saved lookup expired: look it up fresh
                if job["cancel"]:
                    raise
                with INFO_LOCK:
                    INFO_CACHE.pop(job["url"], None)
                remove_job_files(job["id"])
                job.update(part=1)
                ydl.extract_info(job["url"], download=True)
        path = find_output(job["id"])
        if not path:
            raise RuntimeError("Download finished but no file was produced.")
        o = job["opts"]
        subs = [os.path.join(DOWNLOAD_DIR, f) for f in os.listdir(DOWNLOAD_DIR)
                if f.startswith(job["id"]) and f.endswith(".vtt")]
        if job["kind"] == "video" and has_ffmpeg():
            if o.get("subs") == "burn" and subs:      # draw the subtitles onto the picture
                out = os.path.join(DOWNLOAD_DIR, job["id"] + "_sub.mp4")
                sub = os.path.basename(subs[0])       # relative name: avoids Windows path escaping in the filter
                run_ff(["-i", os.path.basename(path), "-vf", f"subtitles={sub}", "-c:v", "libx264", "-preset", "veryfast",
                        "-crf", "21", "-c:a", "copy", "-movflags", "+faststart", os.path.basename(out)],
                       job, media_duration(path), "Adding subtitles", cwd=DOWNLOAD_DIR)
                os.remove(path); path = out
            if o.get("shrink"):
                small = shrink_video(path, os.path.join(DOWNLOAD_DIR, job["id"] + "_small.mp4"), job)
                if small != path:
                    os.remove(path); path = small
        base = safe_name(o["filename"] or job["title"])
        job["name"] = base + os.path.splitext(path)[1]
        if job.get("library"):
            try:
                path, job["name"] = lib_add(job, path, subs=subs if o.get("subs") == "player" else ())
                job["saved_to_library"] = True
                job["lib_names"] = [job["name"]]
            except OSError:
                pass        # couldn't move it: it can still be saved the usual way
        job.update(status="done", stage="Done!", percent=100, file=path,
                   size=os.path.getsize(path), speed=None, eta=None)
    except Exception as e:  # noqa
        if job["cancel"] or isinstance(e, Cancelled) or "Cancelled" in repr(e):
            job.update(status="cancelled", stage="Cancelled", speed=None, eta=None)
        else:
            job.update(status="error", stage="Failed", error=clean_error(e), speed=None, eta=None)
        remove_job_files(job["id"])


def cleanup_loop():
    while True:
        now = time.time()
        for f in os.listdir(DOWNLOAD_DIR):
            p = os.path.join(DOWNLOAD_DIR, f)
            try:
                if now - os.path.getmtime(p) > FILE_TTL:
                    os.remove(p)
            except OSError:
                pass
        for jid in [j for j, v in list(JOBS.items()) if now - v["created"] > FILE_TTL]:
            JOBS.pop(jid, None)
        time.sleep(300)


# ------------------------------------------------------------------ pages
@app.get("/")
def index():
    # Anonymous counts (app opens, tip taps) go to GoatCounter; never from the owner's own copy.
    stats_on = not is_owner()
    return render_template("index.html", version=APP_VERSION, desktop=DESKTOP,
                           counter=COUNTER_URL if stats_on and not phone_admin() else "",
                           owner_admin=is_owner() or ANDROID, android_admin=ANDROID)


@app.get("/share")
def share():
    """Android 'Share to Grabby' lands here (PWA share target)."""
    url = ""
    for key in ("url", "text", "title"):
        url = extract_url(request.args.get(key, ""))
        if url:
            break
    # auto=1 starts the download right away with the user's last-used format
    return redirect("/?" + urlencode({"url": url, "shared": "1", "auto": "1"}) if url else "/")


@app.get("/manifest.webmanifest")
def manifest():
    return send_from_directory(app.static_folder, "manifest.webmanifest",
                               mimetype="application/manifest+json")


@app.get("/sw.js")
def service_worker():
    resp = send_from_directory(app.static_folder, "sw.js", mimetype="application/javascript")
    resp.headers["Service-Worker-Allowed"] = "/"
    resp.headers["Cache-Control"] = "no-cache"
    return resp


# ------------------------------------------------------------------ api
@app.get("/api/health")
def api_health():
    return jsonify(ok=True, app="Grabby", version=APP_VERSION, ffmpeg=has_ffmpeg(), android=ANDROID, desktop=DESKTOP,
                   youtube=bool(QJS_EXE or shutil.which("deno") or shutil.which("node") or shutil.which("bun")),
                   lan=f"http://{lan_ip()}:{request.host.split(':')[-1]}",
                   ytdlp=yt_dlp.version.__version__ if hasattr(yt_dlp, "version") else "?")


@app.get("/api/config")
def api_config():
    cfg = load_config()
    cfg["is_owner"] = is_owner()
    cfg["configured"] = any(cfg.get(k) for k in ("gcash_number", "gcash_qr", "maya_number", "paypal_me", "kofi", "custom_url"))
    return jsonify(cfg)


@app.post("/api/config")
def api_config_save():
    if not is_owner():
        return jsonify(error="Only the computer running Grabby can change this."), 403
    d = request.json or {}
    cfg = {k: v for k, v in load_config().items() if k in DEFAULT_CONFIG}
    for k in DEFAULT_CONFIG:
        if k in d:
            v = d[k]
            if k in ("ask_every", "cup_price"):
                try:
                    v = max(0, min(100, int(v))) if k == "ask_every" else max(1, min(10000, int(v)))
                except (TypeError, ValueError):
                    v = DEFAULT_CONFIG[k]
            else:
                v = str(v).strip()[:300]
                if k in ("paypal_me", "kofi"):
                    v = re.sub(r"^https?://(www\.)?(paypal\.me|ko-fi\.com)/", "", v).strip("/")
                if k == "custom_url" and v and not v.startswith(("http://", "https://")):
                    v = "https://" + v
            cfg[k] = v
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    return jsonify(ok=True)


@app.post("/api/qr")
def api_qr():
    if not is_owner():
        return jsonify(error="Only the computer running Grabby can change this."), 403
    path = os.path.join(UPLOAD_DIR, "gcash-qr.png")
    if request.args.get("remove"):
        if os.path.exists(path):
            os.remove(path)
        set_config_value("qrph", "")
        return jsonify(ok=True)
    f = request.files.get("file")
    if not f:
        return jsonify(error="Choose an image."), 400
    data = f.read(5 * 1024 * 1024 + 1)
    if len(data) > 5 * 1024 * 1024:
        return jsonify(error="Image is too big (max 5 MB)."), 400
    if not (data[:8] == b"\x89PNG\r\n\x1a\n" or data[:3] == b"\xff\xd8\xff" or data[:4] == b"RIFF"):
        return jsonify(error="Please upload a PNG, JPG or WEBP image."), 400
    with open(path, "wb") as out:
        out.write(data)
    set_config_value("qrph", read_qr_image(path))     # lets Grabby make QRs with the tip amount filled in
    QRPH_TRIED.clear()
    return jsonify(ok=True, url="/static/uploads/gcash-qr.png?" + str(int(time.time())))


def set_config_value(key, value):
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg = json.load(f)
    except (OSError, ValueError):
        cfg = {}
    cfg[key] = value
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)


@app.post("/api/restart")
def api_restart():
    """Restart Grabby so code updates take effect (only from this computer)."""
    if ANDROID or not is_owner():
        return jsonify(error="Only the computer running Grabby can restart it."), 403

    def later():
        time.sleep(0.5)
        import subprocess
        args = [x for x in sys.argv if x != "--open"]
        env = dict(os.environ, VIDGRAB_RESTART="1")
        if TUNNEL["status"] == "on":
            env["VIDGRAB_ONLINE"] = "1"          # come back online after the restart
        tunnel_stop()
        subprocess.Popen([sys.executable] + args, env=env, cwd=BASE, close_fds=True)
        os._exit(0)   # the new copy takes over the same window and port
    threading.Thread(target=later, daemon=True).start()
    return jsonify(ok=True)


@app.get("/api/owner")
def api_owner():
    return jsonify(owner=is_owner(), local=is_local() if not ANDROID else False, android=ANDROID or DESKTOP,
                   has_password=bool(owner_data().get("pw")), online=tunnel_view() if (not ANDROID and is_owner()) else None)


@app.post("/api/owner/login")
def api_owner_login():
    if ANDROID:
        return jsonify(error="Not needed in the phone app."), 400
    ip, now = client_ip(), time.time()
    tries = [t for t in LOGIN_TRIES.get(ip, []) if now - t < 600]
    if len(tries) >= 5:
        return jsonify(error="Too many wrong tries. Wait 10 minutes and try again."), 429
    stored = owner_data().get("pw")
    pw = str((request.json or {}).get("password", ""))
    if not stored:
        return jsonify(error="No owner password yet. Set one on the computer running Grabby."), 400
    if not pw_check(pw, stored):
        tries.append(now); LOGIN_TRIES[ip] = tries
        time.sleep(0.8)
        return jsonify(error=f"Wrong password. {5 - len(tries)} tries left."), 403
    LOGIN_TRIES.pop(ip, None)
    session.permanent = True
    session["owner"] = pw_version()
    return jsonify(ok=True)


@app.post("/api/owner/logout")
def api_owner_logout():
    session.pop("owner", None)
    return jsonify(ok=True)


@app.post("/api/owner/password")
def api_owner_password():
    """Set or change the owner password. Changing it logs out every other device."""
    if ANDROID or not is_owner():
        return jsonify(error="Only the owner can change this."), 403
    pw = str((request.json or {}).get("password", ""))
    if len(pw) < 6:
        return jsonify(error="Use at least 6 characters."), 400
    d = owner_data(); d["pw"] = pw_hash(pw); owner_save(d)
    if not is_local():
        session["owner"] = pw_version()      # keep this device logged in
    return jsonify(ok=True)


# ---- "Go online": a free Cloudflare quick tunnel to this computer
TUNNEL = {"proc": None, "url": None, "status": "off", "error": None, "note": ""}
APP_PORT = int(os.getenv("PORT", "5000"))


def tunnel_view():
    url = TUNNEL["url"] if TUNNEL["status"] == "on" else None
    return {"status": TUNNEL["status"], "url": url, "error": TUNNEL["error"], "note": TUNNEL["note"],
            "auto": bool(owner_data().get("auto_online")), "qr": qr_make(url) if url else None}


def qr_make(text):
    try:
        from qr import qr_svg
    except ImportError:
        from .qr import qr_svg
    return qr_svg(text)


def cloudflared_path():
    found = shutil.which("cloudflared")
    if found:
        return found
    import platform
    mach = platform.machine().lower()
    arch = "arm64" if mach in ("arm64", "aarch64") else "amd64" if mach in ("amd64", "x86_64") else "386"
    if os.name == "nt":
        name = f"cloudflared-windows-{arch if arch != 'arm64' else 'amd64'}.exe"
    elif sys.platform.startswith("linux"):
        name = f"cloudflared-linux-{arch}"
    else:
        raise RuntimeError("On a Mac, install it first:  brew install cloudflared")
    tools = os.path.join(DATA_DIR, "tools")
    os.makedirs(tools, exist_ok=True)
    dest = os.path.join(tools, "cloudflared.exe" if os.name == "nt" else "cloudflared")
    if os.path.exists(dest) and os.path.getsize(dest) > 5_000_000:
        return dest
    TUNNEL.update(status="starting", note="Downloading the free Cloudflare tunnel helper (one time, about 60 MB)…")
    import urllib.request
    tmp = dest + ".part"
    with urllib.request.urlopen(f"https://github.com/cloudflare/cloudflared/releases/latest/download/{name}", timeout=60) as r, open(tmp, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0); got = 0
        while True:
            chunk = r.read(1 << 16)
            if not chunk:
                break
            f.write(chunk); got += len(chunk)
            if total:
                TUNNEL["note"] = f"Downloading the tunnel helper… {got * 100 // total}%"
    os.replace(tmp, dest)
    if os.name != "nt":
        os.chmod(dest, 0o755)
    return dest


def tunnel_start():
    if TUNNEL["status"] in ("starting", "on"):
        return
    TUNNEL.update(status="starting", url=None, error=None, note="Starting…")

    def run():
        try:
            exe = cloudflared_path()
            TUNNEL["note"] = "Connecting to Cloudflare…"
            pr = subprocess.Popen([exe, "tunnel", "--no-autoupdate", "--url", f"http://localhost:{APP_PORT}"],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, encoding="utf-8",
                                  errors="replace", creationflags=NO_WINDOW)
            TUNNEL["proc"] = pr
            last = []
            for line in pr.stderr:
                last = (last + [line.strip()])[-6:]
                m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
                if m and not TUNNEL["url"]:
                    TUNNEL.update(url=m.group(0), status="on", note="")
                    print(f"  Online at       : {m.group(0)}")
            pr.wait()
            if TUNNEL["status"] != "off":
                TUNNEL.update(status="off", url=None, error="The tunnel stopped. " + (" ".join(last[-2:])[:200] if last else ""))
        except Exception as e:  # noqa
            TUNNEL.update(status="off", url=None, error=str(e)[:200], note="")
    threading.Thread(target=run, daemon=True).start()


def tunnel_stop():
    pr = TUNNEL.get("proc")
    TUNNEL.update(status="off", url=None, note="", error=None, proc=None)
    if pr and pr.poll() is None:
        try:
            pr.terminate(); pr.wait(5)
        except Exception:  # noqa
            try:
                pr.kill()
            except Exception:  # noqa
                pass


@app.route("/api/online", methods=["GET", "POST"])
def api_online():
    if ANDROID or not is_owner():
        return jsonify(error="Only the owner can do this."), 403
    if request.method == "POST":
        d = request.json or {}
        act = d.get("action")
        if act == "start":
            if not owner_data().get("pw"):
                return jsonify(error="Set an owner password first, so only you can use My Videos from outside."), 400
            tunnel_start()
        elif act == "stop":
            if not is_local():
                return jsonify(error="Turn it off from the computer, or you'd lose your connection."), 400
            tunnel_stop()
        elif act == "auto":
            o = owner_data(); o["auto_online"] = bool(d.get("value")); owner_save(o)
    return jsonify(tunnel_view())


# ------------------------------------------------------------------ the Grabby phone app: download + updates
APP_DIR = os.path.join(DATA_DIR, "app")              # an APK uploaded by the owner (used if GitHub isn't set up)
UPDATE_CACHE = {"t": 0, "data": None}


def update_repo():
    """'org/repo' on GitHub where the app is published (from update.json)."""
    try:
        with open(os.path.join(BASE, "update.json"), encoding="utf-8") as f:
            r = str(json.load(f).get("repo") or "").strip().strip("/")
        return r if re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", r) else ""
    except (OSError, ValueError, AttributeError):
        return ""


def vtuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:3]) or (0,)


def local_apk():
    p = os.path.join(APP_DIR, "Grabby.apk")
    return p if os.path.isfile(p) else None


@app.get("/get-app")
def get_app():
    """Download link for the Android app. Always the newest version."""
    repo = update_repo()
    if repo:
        return redirect(f"https://github.com/{repo}/releases/latest/download/Grabby.apk")
    p = local_apk()
    if p:
        return send_file(p, as_attachment=True, download_name="Grabby.apk", mimetype="application/vnd.android.package-archive")
    return Response("<h2 style='font-family:sans-serif;text-align:center;margin-top:40px'>The Grabby app isn't published yet. Check back soon!</h2>",
                    404, mimetype="text/html")


@app.get("/api/appinfo")
def api_appinfo():
    repo, p = update_repo(), local_apk()
    url = request.host_url.rstrip("/") + "/get-app"
    if not is_local() and (request.headers.get("X-Forwarded-Proto") == "https" or "https" in request.headers.get("Cf-Visitor", "")):
        url = url.replace("http://", "https://", 1)
    return jsonify(available=bool(repo or p), repo=repo, version=APP_VERSION, url=url, qr=qr_make(url),
                   local={"size": os.path.getsize(p), "time": os.path.getmtime(p)} if p else None,
                   owner=is_owner() and not ANDROID)


@app.get("/api/update")
def api_update():
    """Is there a newer Grabby on GitHub?  (checked at most every 3 hours)"""
    repo = update_repo()
    if not repo:
        return jsonify(current=APP_VERSION, newer=False, configured=False)
    now = time.time()
    # The phone / Windows apps must be on the newest version, so they look again every 15 minutes.
    if not UPDATE_CACHE["data"] or now - UPDATE_CACHE["t"] > 15 * 60 or request.args.get("force"):
        try:
            import urllib.request
            req = urllib.request.Request(f"https://api.github.com/repos/{repo}/releases/latest",
                                         headers={"Accept": "application/vnd.github+json", "User-Agent": "Grabby-app"})
            with urllib.request.urlopen(req, timeout=10) as r:
                rel = json.load(r)
            want = ".exe" if DESKTOP else ".apk"          # the Windows app updates to the new .exe
            apk = next((a["browser_download_url"] for a in rel.get("assets", []) if a.get("name", "").endswith(want)), None)
            UPDATE_CACHE.update(t=now, data={"latest": (rel.get("tag_name") or "").lstrip("vV"), "apk": apk,
                                             "notes": (rel.get("body") or "")[:1500], "page": rel.get("html_url")})
        except Exception as e:  # noqa
            return jsonify(current=APP_VERSION, newer=False, configured=True, error=str(e)[:120])
    d = UPDATE_CACHE["data"]
    newer = vtuple(d["latest"]) > vtuple(APP_VERSION)
    # Every new version is required (the app locks until it's installed), unless the release notes say [optional].
    optional = "[optional]" in (d["notes"] or "").lower()
    return jsonify(current=APP_VERSION, configured=True, latest=d["latest"], newer=newer,
                   required=bool(newer and (ANDROID or DESKTOP) and not optional),
                   url=d["apk"] or f"https://github.com/{repo}/releases/latest/download/{'Grabby-Windows.exe' if DESKTOP else 'Grabby.apk'}",
                   notes=re.sub(r"(?i)\[optional\]\s*", "", d["notes"] or ""), page=d["page"], desktop=DESKTOP)


@app.post("/api/quit")
def api_quit():
    """Windows app: a newer Grabby.exe asks the old one to close (only from this computer)."""
    if not DESKTOP or not is_local():
        return jsonify(error="Not allowed"), 403
    threading.Timer(0.4, lambda: os._exit(0)).start()
    return jsonify(ok=True)


@app.post("/api/app/upload")
def api_app_upload():
    """Owner: put the APK on this computer so people can download it from your online link."""
    if ANDROID or not is_owner():
        return jsonify(error="Only the owner can do this."), 403
    f = request.files.get("file")
    if not f:
        return jsonify(error="Choose the APK file."), 400
    os.makedirs(APP_DIR, exist_ok=True)
    tmp = os.path.join(APP_DIR, "upload.part")
    f.save(tmp)
    with open(tmp, "rb") as fh:
        ok = fh.read(2) == b"PK"
    if not ok or os.path.getsize(tmp) > 300 * 1024 * 1024:
        os.remove(tmp)
        return jsonify(error="That isn't an APK file."), 400
    os.replace(tmp, os.path.join(APP_DIR, "Grabby.apk"))
    return jsonify(ok=True)


@app.post("/api/info")
def api_info():
    url = extract_url((request.json or {}).get("url", ""))
    if not url:
        return jsonify(error="Please paste a valid link."), 400
    try:
        info = get_info(url)
        fmts = info.get("formats") or []
        audio_size = max([f.get("filesize") or f.get("filesize_approx") or 0
                          for f in fmts if f.get("vcodec") == "none"] or [0])
        sizes = {}
        for f in fmts:
            h = f.get("height")
            if not h or f.get("vcodec") == "none":
                continue
            sz = f.get("filesize") or f.get("filesize_approx") or 0
            if f.get("acodec") == "none" and sz:
                sz += audio_size
            sizes[h] = max(sizes.get(h, 0), sz)
        heights = sorted(sizes, reverse=True)
        has_video = any(f.get("vcodec") not in (None, "none") for f in fmts) or bool(heights)
        return jsonify(
            photo_only=not fmts,
            has_video=has_video,
            url=url,
            title=info.get("title"),
            thumbnail=info.get("thumbnail"),
            duration=info.get("duration"),
            uploader=info.get("uploader") or info.get("channel"),
            site=info.get("extractor_key"),
            heights=[{"h": h, "size": sizes[h]} for h in heights],
            audio_size=audio_size,
            ffmpeg=has_ffmpeg(),
        )
    except Exception as e:  # noqa
        return jsonify(error=clean_error(e)), 400


@app.post("/api/download")
def api_download():
    d = request.json or {}
    url = extract_url(d.get("url", ""))
    if not url:
        return jsonify(error="Please paste a valid link."), 400
    kind = d.get("kind") if d.get("kind") in ("audio", "photo") else "video"
    try:
        start, end = parse_time(d.get("start")), parse_time(d.get("end"))
    except ValueError as e:
        return jsonify(error=str(e)), 400
    if start is not None and end is not None and end <= start:
        return jsonify(error="Trim end must be after the start."), 400
    opts = {
        "kind": kind,
        "quality": str(d.get("quality", "1080")),
        "audio": "mp3" if d.get("audio", "mp3") == "mp3" else "m4a",
        "abr": str(d.get("abr", "192")) if str(d.get("abr", "192")) in {"128", "192", "256", "320"} else "192",
        "start": start, "end": end,
        "filename": (d.get("filename") or "").strip(),
        "shrink": bool(d.get("shrink")) and has_ffmpeg(),
        "subs": d.get("subs") if d.get("subs") in ("player", "burn") else "off",
        "sublang": d.get("sublang") if d.get("sublang") in ("en", "tl", "ko", "ja", "zh", "es") else "en",
    }
    if kind == "photo":
        label = "Photos"
    elif kind == "audio":
        label = f"MP3 · {opts['abr']} kbps" if opts["audio"] == "mp3" and has_ffmpeg() else "Audio · M4A"
    else:
        q = opts["quality"]
        label = "MP4 · Best" if not q.isdigit() else f"MP4 · {q}p"
    if start is not None or end is not None:
        label += " · trimmed"
    if opts["subs"] != "off" and kind == "video":
        label += " · subtitles"
    if opts["shrink"] and kind == "video":
        label += " · Messenger size"
    job = new_job(url, opts, kind, label, d, library_allowed())
    return jsonify(job_public(job))


def new_job(url, opts, kind, label, d, library):
    jid = uuid.uuid4().hex
    JOBS[jid] = {
        "id": jid, "url": url, "opts": opts, "kind": kind, "label": label,
        "status": "queued", "stage": "Starting", "percent": 0, "part": 1, "parts": 1,
        "downloaded": 0, "total": 0, "speed": None, "eta": None,
        "title": d.get("title"), "thumbnail": d.get("thumbnail"), "site": d.get("site"),
        "file": None, "name": None, "size": 0, "error": None,
        "cancel": False, "created": time.time(), "library": library,
    }
    threading.Thread(target=run_job, args=(JOBS[jid],), daemon=True).start()
    return JOBS[jid]


@app.get("/api/status/<jid>")
def api_status(jid):
    job = JOBS.get(jid)
    if not job:
        return jsonify(error="Download expired."), 404
    return jsonify(job_public(job))


@app.post("/api/cancel/<jid>")
def api_cancel(jid):
    job = JOBS.get(jid)
    if not job:
        return jsonify(error="Not found"), 404
    if job["status"] not in ("done", "error", "cancelled"):
        job["cancel"] = True
        job["stage"] = "Cancelling…"
    return jsonify(ok=True)


@app.get("/api/file/<jid>")
def api_file(jid):
    job = JOBS.get(jid)
    if not job or job["status"] != "done" or not os.path.exists(job["file"] or ""):
        return "This file has expired. Download it again.", 404
    inline = request.args.get("inline") == "1"      # play it in the page instead of saving
    return send_file(job["file"], as_attachment=not inline, download_name=job["name"], conditional=True)


# ------------------------------------------------------------------ My Videos
@app.get("/api/library")
def api_library():
    if not library_allowed():
        return jsonify(enabled=False)
    os.makedirs(LIBRARY_DIR, exist_ok=True)
    with LIB_LOCK:
        idx = lib_read_index()
    items, changed, probes = [], False, 0
    for f in os.listdir(LIBRARY_DIR):
        kind = MEDIA_EXT.get(os.path.splitext(f)[1].lower())
        p = os.path.join(LIBRARY_DIR, f)
        if not kind or f.startswith(".") or not os.path.isfile(p):
            continue
        meta = idx.get(f, {})
        if kind != "photo" and meta.get("duration") is None and has_ffmpeg() and probes < 25:
            meta["duration"] = media_duration(p) or 0; probes += 1   # measured once, then remembered
            idx[f] = meta; changed = True
        st = os.stat(p)
        items.append({"name": f, "kind": kind, "size": st.st_size,
                      "added": meta.get("added") or st.st_mtime,
                      "title": meta.get("title") or os.path.splitext(f)[0],
                      "site": meta.get("site"), "url": meta.get("url"), "folder": meta.get("folder") or "",
                      "duration": meta.get("duration") or None, "subs": lib_subs(f) if kind == "video" else [],
                      "thumbnail": meta.get("thumbnail"), "label": meta.get("label")})
    if changed:
        with LIB_LOCK:
            try:
                fresh = lib_read_index()
                for k, v in idx.items():
                    if k in fresh and v.get("duration") is not None:
                        fresh[k]["duration"] = v["duration"]
                    elif k not in fresh:
                        fresh[k] = v
                lib_write_index(fresh)
            except OSError:
                pass
    items.sort(key=lambda i: i["added"], reverse=True)
    return jsonify(enabled=True, items=items, folder=None if ANDROID else LIBRARY_DIR,
                   can_open=(not ANDROID and is_local() and hasattr(os, "startfile")), settings=lib_settings(),
                   ffmpeg=has_ffmpeg(), lan=(not ANDROID) and is_owner())


@app.get("/api/library/file/<path:name>")
def api_library_file(name):
    p = None
    if library_allowed():
        if name.endswith(".vtt") and name == os.path.basename(name) and not name.startswith("."):
            q = os.path.join(LIBRARY_DIR, name)
            p = q if os.path.isfile(q) else None
        else:
            p = lib_path(name)
    if not p:
        return "Not found", 404
    return send_file(p, as_attachment=request.args.get("dl") == "1", download_name=name, conditional=True)


@app.post("/api/library/delete")
def api_library_delete():
    if not library_allowed():
        return jsonify(error="Only the owner can delete videos."), 403
    names = (request.json or {}).get("names") or []
    removed = []
    with LIB_LOCK:
        idx = lib_read_index()
        for n in names if isinstance(names, list) else []:
            p = lib_path(str(n))
            if p:
                try:
                    for s in lib_subs(n):
                        os.remove(os.path.join(LIBRARY_DIR, s))
                    os.remove(p); removed.append(n); idx.pop(n, None)
                except OSError:
                    pass
        try:
            lib_write_index(idx)
        except OSError:
            pass
    return jsonify(ok=True, removed=removed)


# ---------------------------------------------------------------- VAULT
# Videos, music and pictures locked with a password (see vault.py). Encrypted files live in the
# app's own data folder, so no gallery, file manager or other app can see them.
try:
    from vault import Vault, BLOCK as VAULT_BLOCK
except ImportError:
    from .vault import Vault, BLOCK as VAULT_BLOCK
VAULT = Vault(os.path.join(DATA_DIR, "vault"))
VAULT_MIME = {".mp4": "video/mp4", ".webm": "video/webm", ".mkv": "video/x-matroska", ".mov": "video/quicktime",
              ".m4v": "video/mp4", ".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".opus": "audio/ogg", ".ogg": "audio/ogg",
              ".wav": "audio/wav", ".aac": "audio/aac", ".flac": "audio/flac", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
              ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif"}


def vault_key():
    tok = request.headers.get("X-Vault") or request.args.get("vt") or ""
    return VAULT.key_for(tok)


def vault_public(it):
    return {k: it.get(k) for k in ("id", "title", "kind", "ext", "size", "added", "site", "duration")}


@app.get("/api/vault")
def api_vault():
    if not library_allowed():
        return jsonify(error="Only the owner can use the vault."), 403
    key = vault_key()
    return jsonify(setup=VAULT.is_setup(), unlocked=bool(key),
                   items=[vault_public(i) for i in VAULT.items(key)] if key else [])


@app.post("/api/vault/setup")
def api_vault_setup():
    if not library_allowed():
        return jsonify(error="Only the owner can use the vault."), 403
    pw = str((request.json or {}).get("password") or "")
    if len(pw) < 4:
        return jsonify(error="Use at least 4 characters."), 400
    try:
        return jsonify(ok=True, token=VAULT.setup(pw))
    except ValueError as e:
        return jsonify(error=str(e)), 400


@app.post("/api/vault/unlock")
def api_vault_unlock():
    if not library_allowed():
        return jsonify(error="Only the owner can use the vault."), 403
    try:
        tok = VAULT.unlock(str((request.json or {}).get("password") or ""))
    except PermissionError as e:
        return jsonify(error=str(e)), 429
    if not tok:
        return jsonify(error="Wrong password."), 401
    return jsonify(ok=True, token=tok)


@app.post("/api/vault/autolock")
def api_vault_autolock():
    """Auto-lock time for this unlocked vault (the app also locks it itself; this is the backstop)."""
    tok = request.headers.get("X-Vault") or ""
    if not library_allowed() or not VAULT.key_for(tok):
        return jsonify(error="Unlock the vault first."), 403
    try:
        secs = int((request.json or {}).get("seconds") or 300)
    except (TypeError, ValueError):
        secs = 300
    VAULT.set_idle(tok, secs + 30)
    return jsonify(ok=True)


@app.post("/api/vault/lock")
def api_vault_lock():
    VAULT.lock(request.headers.get("X-Vault") or (request.json or {}).get("token"))
    return jsonify(ok=True)


@app.post("/api/vault/password")
def api_vault_password():
    if not library_allowed() or not vault_key():
        return jsonify(error="Unlock the vault first."), 403
    d = request.json or {}
    new = str(d.get("new") or "")
    if len(new) < 4:
        return jsonify(error="Use at least 4 characters."), 400
    if not VAULT.change_password(str(d.get("old") or ""), new):
        return jsonify(error="The current password is wrong."), 401
    return jsonify(ok=True)


@app.post("/api/vault/reset")
def api_vault_reset():
    if not library_allowed():
        return jsonify(error="Only the owner can use the vault."), 403
    if (request.json or {}).get("confirm") != "DELETE":
        return jsonify(error="Type DELETE to confirm."), 400
    VAULT.reset()
    return jsonify(ok=True)


@app.post("/api/vault/add")
def api_vault_add():
    """Move files from My Videos into the vault (they disappear from My Videos)."""
    key = vault_key()
    if not library_allowed() or not key:
        return jsonify(error="Unlock the vault first."), 403
    names = (request.json or {}).get("names") or []
    moved = []
    for n in names if isinstance(names, list) else []:
        p = lib_path(str(n))
        if not p:
            continue
        meta = lib_read_index().get(n, {})
        ext = os.path.splitext(n)[1].lower()
        try:
            VAULT.add_file(key, p, {"title": meta.get("title") or os.path.splitext(n)[0], "name": n,
                                    "kind": MEDIA_EXT.get(ext), "ext": ext, "site": meta.get("site"),
                                    "duration": meta.get("duration")})
        except OSError as e:
            return jsonify(error=f"Couldn't lock {n}: {e}", moved=moved), 500
        with LIB_LOCK:
            idx = lib_read_index()
            try:
                for s in lib_subs(n):
                    os.remove(os.path.join(LIBRARY_DIR, s))
                os.remove(p)
            except OSError:
                pass
            idx.pop(n, None)
            try:
                lib_write_index(idx)
            except OSError:
                pass
        moved.append(n)
    return jsonify(ok=True, moved=moved)


@app.post("/api/vault/upload")
def api_vault_upload():
    """Add files from this phone / computer straight into the vault."""
    key = vault_key()
    if not library_allowed() or not key:
        return jsonify(error="Unlock the vault first."), 403
    added = []
    for f in request.files.getlist("files"):
        name = os.path.basename(f.filename or "file")
        ext = os.path.splitext(name)[1].lower()
        kind = MEDIA_EXT.get(ext)
        if not kind:
            mt = (f.mimetype or "").split("/")[0]
            kind = {"video": "video", "audio": "audio", "image": "photo"}.get(mt)
            ext = ext or {"video": ".mp4", "audio": ".m4a", "photo": ".jpg"}.get(kind, "")
        if not kind:
            continue
        it = VAULT.add_stream(key, f.stream.read, {"title": os.path.splitext(name)[0] or "File", "name": name,
                                                   "kind": kind, "ext": ext})
        added.append(vault_public(it))
    if not added:
        return jsonify(error="Pick videos, music or pictures."), 400
    return jsonify(ok=True, added=added)


@app.get("/api/vault/file/<item_id>")
def api_vault_file(item_id):
    key = vault_key()
    if not library_allowed() or not key:
        return "Locked", 403
    it = VAULT.get(key, item_id)
    path = VAULT.file_path(item_id)
    if not it or not path or not os.path.isfile(path):
        return "Not found", 404
    size = it["size"]
    start, end, status = 0, size - 1, 200
    m = re.match(r"bytes=(\d*)-(\d*)", request.headers.get("Range", ""))
    if m and size:
        if m.group(1):
            start = int(m.group(1))
            end = int(m.group(2)) if m.group(2) else size - 1
        elif m.group(2):
            start = max(0, size - int(m.group(2)))
        end = min(end, size - 1)
        if start > end:
            return Response(status=416, headers={"Content-Range": f"bytes */{size}"})
        status = 206
    headers = {"Accept-Ranges": "bytes", "Content-Length": str(end - start + 1 if size else 0),
               "Cache-Control": "no-store"}
    if status == 206:
        headers["Content-Range"] = f"bytes {start}-{end}/{size}"
    body = VAULT.read_range(key, item_id, start, end) if size else iter(())
    return Response(body, status=status, headers=headers,
                    mimetype=VAULT_MIME.get(it.get("ext"), "application/octet-stream"), direct_passthrough=True)


@app.post("/api/vault/out")
def api_vault_out():
    """Take files out of the vault, back into My Videos."""
    key = vault_key()
    if not library_allowed() or not key:
        return jsonify(error="Unlock the vault first."), 403
    ids = (request.json or {}).get("ids") or []
    out = []
    for item_id in ids if isinstance(ids, list) else []:
        it = VAULT.get(key, str(item_id))
        if not it:
            continue
        name = safe_name(it.get("title")) + (it.get("ext") or "")
        os.makedirs(DOWNLOAD_DIR, exist_ok=True)
        tmp = os.path.join(DOWNLOAD_DIR, f"vault-{it['id']}{it.get('ext') or ''}")
        VAULT.export(key, it["id"], tmp)
        _, final = lib_add({"title": it.get("title"), "site": it.get("site"), "name": name}, tmp, name=name)
        VAULT.remove(key, [it["id"]])
        out.append(final)
    return jsonify(ok=True, names=out)


@app.post("/api/vault/delete")
def api_vault_delete():
    key = vault_key()
    if not library_allowed() or not key:
        return jsonify(error="Unlock the vault first."), 403
    ids = (request.json or {}).get("ids") or []
    return jsonify(ok=True, removed=VAULT.remove(key, [str(i) for i in ids] if isinstance(ids, list) else []))


@app.post("/api/library/open")
def api_library_open():
    if ANDROID or not is_local() or not hasattr(os, "startfile"):
        return jsonify(error="Only on the computer itself."), 403
    os.makedirs(LIBRARY_DIR, exist_ok=True)
    name = (request.json or {}).get("name")
    p = lib_path(name) if name else None
    try:
        if p:   # open Explorer with the file selected
            import subprocess
            subprocess.Popen(["explorer", "/select,", p])
        else:
            os.startfile(LIBRARY_DIR)  # noqa
    except OSError as e:
        return jsonify(error=str(e)), 500
    return jsonify(ok=True)


@app.post("/api/library/folder")
def api_library_folder():
    """Put videos in a folder ('' = no folder)."""
    if not library_allowed():
        return jsonify(error="Not allowed."), 403
    d = request.json or {}
    folder = re.sub(r"\s+", " ", re.sub(r'[\\/:*?"<>|\n\r\t]+', " ", str(d.get("folder") or ""))).strip()[:40]
    with LIB_LOCK:
        idx = lib_read_index()
        for n in d.get("names") or []:
            if lib_path(str(n)):
                idx.setdefault(n, {"added": os.path.getmtime(os.path.join(LIBRARY_DIR, n))})["folder"] = folder
        lib_write_index(idx)
    return jsonify(ok=True)


@app.post("/api/library/settings")
def api_library_settings():
    if not library_allowed():
        return jsonify(error="Not allowed."), 403
    s = lib_settings()
    v = (request.json or {}).get("autosort")
    if v in ("off", "site", "type"):
        s["autosort"] = v
    os.makedirs(LIBRARY_DIR, exist_ok=True)
    with open(LIB_SETTINGS, "w", encoding="utf-8") as f:
        json.dump(s, f)
    return jsonify(ok=True, settings=s)


def tool_job(label, title, fn, src_name):
    """A job that works on a file already in My Videos (shrink, ringtone, GIF, clip)."""
    job = {"id": uuid.uuid4().hex, "url": "", "opts": {}, "kind": "tool", "tool": True, "label": label,
           "status": "processing", "stage": "Starting", "percent": 0, "part": 1, "parts": 1,
           "downloaded": 0, "total": 0, "speed": None, "eta": None, "title": title,
           "thumbnail": None, "site": "My Videos", "file": None, "name": None, "size": 0, "error": None,
           "cancel": False, "created": time.time(), "library": True}
    JOBS[job["id"]] = job

    def work():
        with RUN_SLOTS:
            tmp = None
            try:
                tmp, out_name = fn(job)
                with LIB_LOCK:
                    meta = dict(lib_read_index().get(src_name, {}))
                job.update(site=meta.get("site"), url=meta.get("url") or "", thumbnail=meta.get("thumbnail"))
                dest, name = lib_add(job, tmp, out_name, extra={"title": out_name.rsplit(".", 1)[0], "label": label,
                                                                 "folder": meta.get("folder", "")})
                job.update(status="done", stage="Done!", percent=100, file=dest, name=name, size=os.path.getsize(dest),
                           saved_to_library=True, lib_names=[name])
            except Exception as e:  # noqa
                if job["cancel"] or isinstance(e, Cancelled):
                    job.update(status="cancelled", stage="Cancelled")
                else:
                    job.update(status="error", stage="Failed", error=str(e)[:200])
                if tmp and os.path.exists(tmp):
                    os.remove(tmp)
    threading.Thread(target=work, daemon=True).start()
    return job


@app.post("/api/library/shrink")
def api_library_shrink():
    if not library_allowed() or not has_ffmpeg():
        return jsonify(error="Not available."), 403
    name = (request.json or {}).get("name", "")
    src = lib_path(name)
    if not src or MEDIA_EXT.get(os.path.splitext(name)[1].lower()) != "video":
        return jsonify(error="Pick a video."), 400
    if os.path.getsize(src) <= SHRINK_TARGET:
        return jsonify(error="This video is already small enough for Messenger."), 400
    base = os.path.splitext(name)[0]

    def fn(job):
        out = os.path.join(DOWNLOAD_DIR, job["id"] + ".mp4")
        shrink_video(src, out, job)
        return out, f"{base} (small).mp4"
    return jsonify(job_public(tool_job("Messenger size", f"{base} (small)", fn, name)))


@app.post("/api/library/make")
def api_library_make():
    """Ringtone (MP3, up to 40 s), GIF (up to 15 s) or clip (MP4) from a part of a file."""
    if not library_allowed() or not has_ffmpeg():
        return jsonify(error="Not available."), 403
    d = request.json or {}
    name, what = d.get("name", ""), d.get("what")
    src = lib_path(name)
    kind = MEDIA_EXT.get(os.path.splitext(name)[1].lower())
    if not src or kind not in ("video", "audio") or what not in ("ringtone", "gif", "clip"):
        return jsonify(error="Pick a video or song."), 400
    if what == "gif" and kind != "video":
        return jsonify(error="GIFs need a video."), 400
    try:
        start = float(d.get("start") or 0); end = float(d.get("end") or 0)
    except (TypeError, ValueError):
        return jsonify(error="Start and end must be numbers."), 400
    limit = {"ringtone": 40, "gif": 15, "clip": 600}[what]
    if end <= start:
        end = start + min(limit, 30 if what == "ringtone" else 8 if what == "gif" else 30)
    end = min(end, start + limit)
    length = end - start
    base = os.path.splitext(name)[0]

    def fn(job):
        if what == "ringtone":
            out = os.path.join(DOWNLOAD_DIR, job["id"] + ".mp3")
            fade = max(0.0, length - 1.5)
            run_ff(["-ss", str(start), "-t", str(length), "-i", src, "-vn", "-af",
                    f"afade=t=in:d=0.6,afade=t=out:st={fade}:d=1.5", "-c:a", "libmp3lame", "-b:a", "192k", out],
                   job, length, "Making ringtone")
            return out, f"{base} (ringtone).mp3"
        if what == "gif":
            out = os.path.join(DOWNLOAD_DIR, job["id"] + ".gif")
            run_ff(["-ss", str(start), "-t", str(length), "-i", src, "-vf",
                    "fps=12,scale=480:-2:flags=lanczos,split[a][b];[a]palettegen=max_colors=128[p];[b][p]paletteuse=dither=bayer",
                    "-loop", "0", out], job, length, "Making GIF")
            return out, f"{base} (GIF).gif"
        ext = ".mp3" if kind == "audio" else ".mp4"
        out = os.path.join(DOWNLOAD_DIR, job["id"] + ext)
        args = ["-ss", str(start), "-t", str(length), "-i", src]
        args += (["-c:a", "libmp3lame", "-b:a", "192k"] if kind == "audio" else
                 ["-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart"])
        run_ff(args + [out], job, length, "Cutting clip")
        return out, f"{base} (clip){ext}"
    label = {"ringtone": "Ringtone", "gif": "GIF", "clip": "Clip"}[what]
    return jsonify(job_public(tool_job(label, f"{base} ({label})", fn, name)))


@app.post("/api/library/card")
def api_library_card():
    """Keep a Hugot card picture in My Videos (the phone app can't save pictures from the page)."""
    if not library_allowed():
        return jsonify(error="Not allowed."), 403
    data = str((request.json or {}).get("data", ""))
    if not data.startswith("data:image/png;base64,") or len(data) > 6_000_000:
        return jsonify(error="Bad picture."), 400
    import base64
    raw = base64.b64decode(data.split(",", 1)[1])
    os.makedirs(LIBRARY_DIR, exist_ok=True)
    tmp = os.path.join(DOWNLOAD_DIR, uuid.uuid4().hex + ".png")
    with open(tmp, "wb") as f:
        f.write(raw)
    _, name = lib_add({"title": "Hugot card", "site": "Grabby", "label": "Hugot card"}, tmp,
                      f"Hugot card {datetime.now():%Y-%m-%d}.png", extra={"folder": "Hugot cards"})
    return jsonify(ok=True, name=name)


# ------------------------------------------------------------------ playlists & many links
@app.post("/api/playlist")
def api_playlist():
    url = extract_url((request.json or {}).get("url", ""))
    if not url:
        return jsonify(error="Please paste a valid link."), 400
    try:
        o = dict(base_opts(), noplaylist=False, extract_flat="in_playlist", playlistend=300)
        if "list=" in url and "youtube" in url and "watch" in url:   # a video inside a playlist: open the playlist
            m = re.search(r"[?&]list=([\w-]+)", url)
            url = f"https://www.youtube.com/playlist?list={m.group(1)}" if m else url
        with yt_dlp.YoutubeDL(o) as ydl:
            info = ydl.extract_info(url, download=False)
        if info.get("_type") not in ("playlist", "multi_video") or not info.get("entries"):
            return jsonify(playlist=False)
        items = []
        for e in info["entries"]:
            if not e:
                continue
            u = e.get("webpage_url") or e.get("url")
            if not u:
                continue
            if not u.startswith("http") and e.get("ie_key") == "Youtube":
                u = "https://www.youtube.com/watch?v=" + u
            th = e.get("thumbnail") or ((e.get("thumbnails") or [{}])[-1].get("url"))
            items.append({"url": u, "title": e.get("title") or u, "duration": e.get("duration"), "thumbnail": th})
        return jsonify(playlist=True, title=info.get("title") or "Playlist", site=info.get("extractor_key"),
                       uploader=info.get("uploader") or info.get("channel"), items=items, url=url)
    except Exception as e:  # noqa
        return jsonify(error=clean_error(e)), 400


# ------------------------------------------------------------------ download later
LATER_PATH = os.path.join(DATA_DIR, "later.json")
LATER_LOCK = threading.Lock()


def later_load():
    try:
        with open(LATER_PATH, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {}
    d.setdefault("items", []); d.setdefault("time", "01:00"); d.setdefault("wifi_only", True); d.setdefault("last_run", "")
    return d


def later_save(d):
    with open(LATER_PATH, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False)


def on_wifi():
    """Phone app: only start scheduled downloads on Wi-Fi.  On a PC this is always True."""
    if not ANDROID:
        return True
    try:
        from java import jclass
        ctx = jclass("com.chaquo.python.Python").getPlatform().getApplication()
        cm = ctx.getSystemService("connectivity")
        caps = cm.getNetworkCapabilities(cm.getActiveNetwork())
        return bool(caps and caps.hasTransport(1))      # 1 = TRANSPORT_WIFI
    except Exception:  # noqa
        return True


def later_run(d, reason="scheduled"):
    """Start every waiting download now. Files go to My Videos."""
    started = []
    for it in d["items"]:
        body = it["req"]
        kind = body.get("kind") if body.get("kind") in ("audio", "photo") else "video"
        opts = {"kind": kind, "quality": str(body.get("quality", "1080")),
                "audio": "mp3" if body.get("audio", "mp3") == "mp3" else "m4a",
                "abr": str(body.get("abr", "192")) if str(body.get("abr", "192")) in {"128", "192", "256", "320"} else "192",
                "start": None, "end": None, "filename": "", "shrink": bool(body.get("shrink")) and has_ffmpeg(),
                "subs": body.get("subs") if body.get("subs") in ("player", "burn") else "off",
                "sublang": body.get("sublang") or "en"}
        label = "Photos" if kind == "photo" else ("Audio" if kind == "audio" else "MP4 · " + (opts["quality"] + "p" if opts["quality"].isdigit() else "Best"))
        job = new_job(it["url"], opts, kind, label + " · scheduled", body, True)
        started.append(job["id"])
    d["items"] = []
    return started


def later_loop():
    while True:
        time.sleep(30)
        try:
            with LATER_LOCK:
                d = later_load()
                if not d["items"]:
                    continue
                now = datetime.now()
                hh, mm = (int(x) for x in d["time"].split(":"))
                due = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
                today = now.strftime("%Y-%m-%d")
                # run once a day, any time in the 6 hours after the chosen time (in case the PC was asleep)
                if due <= now < due + timedelta(hours=6) and d["last_run"] != today:
                    if d["wifi_only"] and not on_wifi():
                        continue
                    later_run(d)
                    d["last_run"] = today
                    later_save(d)
        except Exception:  # noqa
            pass


@app.route("/api/later", methods=["GET", "POST"])
def api_later():
    if not library_allowed():
        return jsonify(enabled=False)
    with LATER_LOCK:
        d = later_load()
        if request.method == "POST":
            b = request.json or {}
            act = b.get("action")
            if act == "add":
                for x in (b.get("items") or [])[:300]:
                    u = extract_url(str(x.get("url", "")))
                    if u and not any(i["url"] == u for i in d["items"]):
                        src = x.get("req") or {}
                        req = {k: src[k] for k in ("kind", "quality", "audio", "abr", "shrink", "subs", "sublang", "title", "thumbnail", "site") if src.get(k) is not None}
                        d["items"].append({"id": uuid.uuid4().hex[:10], "url": u, "title": x.get("title") or u,
                                           "thumbnail": x.get("thumbnail"), "req": req, "added": time.time()})
            elif act == "remove":
                d["items"] = [i for i in d["items"] if i["id"] != b.get("id")]
            elif act == "clear":
                d["items"] = []
            elif act == "settings":
                if re.fullmatch(r"\d{1,2}:\d{2}", str(b.get("time", ""))):
                    h, m = (int(x) for x in b["time"].split(":"))
                    if h < 24 and m < 60:
                        d["time"] = f"{h:02d}:{m:02d}"; d["last_run"] = ""
                if "wifi_only" in b:
                    d["wifi_only"] = bool(b["wifi_only"])
            elif act == "start":
                jobs = later_run(d, "now")
                later_save(d)
                return jsonify(ok=True, started=[job_public(JOBS[j]) for j in jobs], **later_view(d))
            later_save(d)
        return jsonify(ok=True, **later_view(d))


def later_view(d):
    return {"enabled": True, "items": d["items"], "time": d["time"], "wifi_only": d["wifi_only"], "android": ANDROID}


# ------------------------------------------------------------------ send to phone (QR)
@app.post("/api/library/share")
def api_library_share():
    if ANDROID or not is_owner():
        return jsonify(error="Only on the computer running Grabby."), 403
    name = (request.json or {}).get("name", "")
    if not lib_path(name):
        return jsonify(error="File not found."), 404
    now = time.time()
    for t in [t for t, v in SHARES.items() if v[1] < now]:
        SHARES.pop(t, None)
    tok = secrets.token_urlsafe(9)
    SHARES[tok] = (name, now + 30 * 60)
    if is_local():          # on this computer: a Wi-Fi link the phone can open
        port = request.host.rsplit(":", 1)[1] if ":" in request.host else "5000"
        link = f"http://{lan_ip()}:{port}/s/{tok}"
    else:                   # logged in from outside: use the same online address
        link = request.host_url.rstrip("/") + f"/s/{tok}"
        if request.headers.get("X-Forwarded-Proto") == "https" or request.headers.get("Cf-Visitor", "").find("https") >= 0:
            link = link.replace("http://", "https://", 1)
    try:
        from qr import qr_svg
    except ImportError:            # inside the phone app (package import)
        from .qr import qr_svg
    return jsonify(url=link, svg=qr_svg(link), minutes=30)


def share_file(tok):
    v = SHARES.get(tok)
    if not v or v[1] < time.time():
        return None, None
    return v[0], lib_path(v[0])


@app.get("/s/<tok>")
def share_page(tok):
    name, p = share_file(tok)
    if not p:
        return Response("<h2 style='font-family:sans-serif;text-align:center;margin-top:40px'>This link has expired. Make a new QR code on your computer.</h2>",
                        404, mimetype="text/html")
    kind = MEDIA_EXT.get(os.path.splitext(name)[1].lower())
    return render_template("share.html", name=name, kind=kind, size=os.path.getsize(p), tok=tok)


@app.get("/s/<tok>/file")
def share_dl(tok):
    name, p = share_file(tok)
    if not p:
        return "Expired", 404
    return send_file(p, as_attachment=request.args.get("dl") == "1", download_name=name, conditional=True)


# ---- Phone app: the download engine (yt-dlp) updates itself, so site changes keep working
#      without waiting for a new Grabby. New versions are checked against PyPI's SHA-256 and
#      take effect the next time Grabby starts (server.py loads them, and falls back if they fail).
PYLIB_DIR = os.path.join(DATA_DIR, "pylib")
ENGINE = {"checking": False, "ready": None, "error": None, "checked": 0}


def vtuple_s(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v or "0"))[:4])


def _https_json(url):
    import ssl
    import urllib.request
    try:
        import certifi
        ctx = ssl.create_default_context(cafile=certifi.where())
    except Exception:  # noqa
        ctx = ssl.create_default_context()
    req = urllib.request.Request(url, headers={"User-Agent": f"Grabby/{APP_VERSION}"})
    with urllib.request.urlopen(req, timeout=30, context=ctx) as r:
        return r.read() if not url.endswith("/json") else json.loads(r.read().decode())


def _pypi_wheel(name, version=None):
    info = _https_json(f"https://pypi.org/pypi/{name}/{version + '/' if version else ''}json")
    for f in info.get("urls", []):
        if f.get("packagetype") == "bdist_wheel" and f["filename"].endswith("py3-none-any.whl"):
            return info, f
    raise RuntimeError(f"no wheel for {name}")


def _install_wheel(name, version, f):
    data = _https_json(f["url"])
    if hashlib.sha256(data).hexdigest() != f["digests"]["sha256"]:
        raise RuntimeError("download check failed")
    dest = os.path.join(PYLIB_DIR, f"{name}-{version}")
    tmp = dest + ".part"
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp, exist_ok=True)
    import io
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for m in z.namelist():
            if m.startswith("/") or ".." in m.split("/"):
                raise RuntimeError("bad file in download")
        z.extractall(tmp)
    shutil.rmtree(dest, ignore_errors=True)
    os.replace(tmp, dest)
    return dest


def engine_check():
    """Look for a newer yt-dlp (+ the matching YouTube scripts) and install it for the next start."""
    if not ANDROID or ENGINE["checking"]:
        return
    ENGINE.update(checking=True, error=None)
    try:
        os.makedirs(PYLIB_DIR, exist_ok=True)
        cur = yt_dlp.version.__version__
        info, f = _pypi_wheel("yt-dlp")
        new = info["info"]["version"]
        if vtuple_s(new) <= vtuple_s(ENGINE["ready"] or cur):
            return
        dirs = [_install_wheel("yt-dlp", new, f)]
        ejs = None   # yt-dlp says exactly which version of its YouTube scripts it needs
        for req in info["info"].get("requires_dist") or []:
            m = re.match(r"yt-dlp-ejs\s*\(?==\s*([\w.]+)", req)
            if m:
                ejs = m.group(1)
        if ejs:
            einfo, ef = _pypi_wheel("yt-dlp-ejs", ejs)
            dirs.append(_install_wheel("yt-dlp-ejs", ejs, ef))
        with open(os.path.join(PYLIB_DIR, "active.json.part"), "w", encoding="utf-8") as fh:
            json.dump({"version": new, "app": APP_VERSION, "dirs": [os.path.basename(d) for d in dirs]}, fh)
        os.replace(os.path.join(PYLIB_DIR, "active.json.part"), os.path.join(PYLIB_DIR, "active.json"))
        ENGINE["ready"] = new
        for d in os.listdir(PYLIB_DIR):        # tidy up older downloads (never the one in use)
            full = os.path.join(PYLIB_DIR, d)
            if os.path.isdir(full) and full not in dirs and not any(full in (p or "") for p in sys.path):
                shutil.rmtree(full, ignore_errors=True)
    except Exception as e:  # noqa
        ENGINE["error"] = str(e)[:200]
    finally:
        ENGINE.update(checking=False, checked=time.time())


def engine_loop():
    time.sleep(25)
    while True:
        engine_check()
        time.sleep(12 * 3600)


@app.get("/api/engine")
def api_engine():
    return jsonify(version=yt_dlp.version.__version__, ready=ENGINE["ready"], checking=ENGINE["checking"],
                   error=ENGINE["error"], android=ANDROID)


@app.post("/api/engine")
def api_engine_check():
    if ANDROID and not ENGINE["checking"]:
        threading.Thread(target=engine_check, daemon=True).start()
        ENGINE["checking"] = True
    return api_engine()


@app.get("/api/selftest")
def api_selftest():
    """Checks the built-in helpers really run on this phone (used by the problem report)."""
    out = {"ffmpeg": None, "qjs": None, "cookies": os.path.isfile(COOKIES_PATH)}
    try:
        if FFMPEG_EXE:
            r = subprocess.run([FFMPEG_EXE, "-hide_banner", "-version"], capture_output=True, text=True, timeout=20)
            out["ffmpeg"] = (r.stdout or r.stderr).splitlines()[0][:80] if r.returncode == 0 else f"error {r.returncode}: {r.stderr[-120:]}"
    except Exception as e:  # noqa
        out["ffmpeg"] = "error: " + str(e)[:120]
    try:
        if QJS_EXE:
            js = os.path.join(tempfile.gettempdir(), "grabby-selftest.js")
            with open(js, "w") as fh:
                fh.write("console.log(String([1,2,3].map(x => x * 2)))")
            r = subprocess.run([QJS_EXE, js], capture_output=True, text=True, timeout=20)
            out["qjs"] = "ok" if r.stdout.strip() == "2,4,6" else f"error {r.returncode}: {(r.stdout + r.stderr)[-120:]}"
    except Exception as e:  # noqa
        out["qjs"] = "error: " + str(e)[:120]
    return jsonify(out)


# ---- Phone app: download notifications (progress bar + Cancel, finished, failed) and keeping
#      downloads alive in the background. The Android side is Notifier.java.
def _size_txt(n):
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1024


def _eta_txt(s):
    s = int(s or 0)
    return f"{s // 60}:{s % 60:02d} left" if s >= 60 else f"{s}s left"


def notify_loop():
    try:
        from java import jclass
        N = jclass("com.vidgrab.app.Notifier")
    except Exception:  # noqa
        return
    started = time.time()
    seen, last_active = {}, -1
    while True:
        time.sleep(1)
        try:
            active = 0
            for j in list(JOBS.values()):
                jid, st = j["id"], j.get("status")
                title = j.get("title") or j.get("label") or "Your download"
                if st in ("queued", "fetching", "downloading", "processing"):
                    active += 1
                    pct = int(j.get("percent") or 0) if st in ("downloading", "processing") else -1
                    bits = [j.get("stage") or "Starting"]
                    if st == "downloading" and j.get("speed"):
                        bits.append(f"{_size_txt(j['speed'])}/s")
                    if st == "downloading" and j.get("eta"):
                        bits.append(_eta_txt(j["eta"]))
                    if (j.get("parts") or 1) > 1:
                        bits.append(f"part {j.get('part')}/{j.get('parts')}")
                    key = (st, pct, " · ".join(bits))
                    if seen.get(jid) != key:
                        N.progress(jid, title, pct, key[2])
                        seen[jid] = key
                elif seen.get(jid) != "final" and j.get("created", 0) >= started - 5:
                    if st == "done":
                        names = j.get("lib_names") or []
                        lib = names[0] if names and j.get("saved_to_library") else None
                        count = j.get("count")
                        text = (f"{count} files" if count and count > 1 else (j.get("name") or "")) + \
                               (f" · {_size_txt(j.get('size'))}" if j.get("size") else "") + \
                               (" · in My Videos" if lib else "")
                        N.done(jid, title, text, lib)
                    elif st == "error":
                        N.failed(jid, title, j.get("error") or "Something went wrong.")
                    else:
                        N.clear(jid)
                    seen[jid] = "final"
            if active != last_active:
                N.active(active)
                last_active = active
        except Exception:  # noqa  - a notification problem must never stop downloads
            pass


def start_background():
    if ANDROID:
        threading.Thread(target=engine_loop, daemon=True).start()
        threading.Thread(target=notify_loop, daemon=True).start()
    threading.Thread(target=cleanup_loop, daemon=True).start()
    threading.Thread(target=later_loop, daemon=True).start()
    threading.Thread(target=warm_up, daemon=True).start()


# ------------------------------------------------------------------ owner: Admin page (downloads, visitors, tips)
#  Downloads come from GitHub's public release counts. Visits, app opens and tip taps are counted
#  by GoatCounter (no cookies, no names, no IP addresses kept). GCash / Maya never report back who
#  paid, so real tips are logged by the owner from their GCash / Maya history.
COUNTER_URL = (os.getenv("GRABBY_COUNTER") or "https://grabbyapp.goatcounter.com").rstrip("/")
ADMIN_PATH = os.path.join(DATA_DIR, "admin.json")
ADMIN_LOCK = threading.Lock()
ADMIN_CACHE = {}


def load_admin():
    try:
        with open(ADMIN_PATH, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_admin(d):
    tmp = ADMIN_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, ADMIN_PATH)


def phone_admin():
    """The owner's own phone: unlocked once with the GoatCounter API key (nobody else has it)."""
    return ANDROID and bool(load_admin().get("phone_unlocked") and load_admin().get("gc_token"))


def admin_ok():
    if DESKTOP:
        return False
    if ANDROID:
        return phone_admin()      # the phone app's server only answers this phone (127.0.0.1)
    return is_owner()


@app.post("/api/admin/unlock")
def api_admin_unlock():
    """Phone app: turn this phone into the owner's phone by proving you have the GoatCounter key."""
    if not ANDROID:
        return jsonify(error="Not needed here."), 400
    b = request.get_json(silent=True) or {}
    tok = str(b.get("token") or "").strip()
    site = (str(b.get("site") or "").strip().rstrip("/")) or COUNTER_URL
    if not re.fullmatch(r"[A-Za-z0-9_-]{10,200}", tok) or not re.fullmatch(r"https://[a-z0-9-]+(\.[a-z0-9-]+)+", site):
        return jsonify(error="That doesn't look like a GoatCounter API key."), 400
    import urllib.error
    try:
        _get_json(f"{site}/api/v0/stats/hits?limit=1", tok)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            return jsonify(error="GoatCounter didn't accept that key."), 403
        if e.code != 404:
            return jsonify(error=f"GoatCounter answered {e.code}. Try again."), 502
    except Exception:  # noqa
        return jsonify(error="Couldn't reach GoatCounter. Are you online?"), 502
    with ADMIN_LOCK:
        d = load_admin()
        d.update(gc_token=tok, gc_site=site, phone_unlocked=True)
        save_admin(d)
    ADMIN_CACHE.clear()
    return jsonify(ok=True)


@app.post("/api/admin/lock")
def api_admin_lock():
    """Phone app: hide Admin again on this phone (forgets the key; logged tips stay)."""
    if not admin_ok() or not ANDROID:
        return jsonify(error="Only the owner can do this."), 403
    with ADMIN_LOCK:
        d = load_admin()
        d.pop("gc_token", None)
        d["phone_unlocked"] = False
        save_admin(d)
    ADMIN_CACHE.clear()
    return jsonify(ok=True)


def _get_json(url, token=None, timeout=20):
    import ssl
    import urllib.request
    try:
        import certifi
        ctx = ssl.create_default_context(cafile=certifi.where())
    except Exception:  # noqa
        ctx = ssl.create_default_context()
    h = {"User-Agent": f"Grabby-admin/{APP_VERSION}", "Accept": "application/json"}
    if token:
        h["Authorization"] = "Bearer " + token
        h["Content-Type"] = "application/json"
    with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=timeout, context=ctx) as r:
        return json.loads(r.read().decode())


def gh_downloads(repo):
    """Every release with its APK / EXE download counts (public, no key needed)."""
    rels, out = _get_json(f"https://api.github.com/repos/{repo}/releases?per_page=100"), []
    for r in rels:
        if r.get("draft"):
            continue
        a = {"apk": 0, "exe": 0, "other": 0}
        for x in r.get("assets", []):
            n = (x.get("name") or "").lower()
            a["apk" if n.endswith(".apk") else "exe" if n.endswith(".exe") else "other"] += int(x.get("download_count") or 0)
        out.append({"tag": r.get("tag_name") or "", "date": (r.get("published_at") or "")[:10], **a})
    return out


def _cc(code):
    code = (code or "").upper()
    return code if re.fullmatch(r"[A-Z]{2}", code) else "??"


def gc_stats(site, token, days):
    end = datetime.utcnow() + timedelta(hours=1)
    start = (end - timedelta(days=days)).replace(hour=0, minute=0, second=0, microsecond=0)
    q = urlencode({"start": start.strftime("%Y-%m-%dT%H:%M:%SZ"), "end": end.strftime("%Y-%m-%dT%H:%M:%SZ")})
    problems = []

    def get(path, empty):
        """One stats request. A brand-new site with no data yet can answer 404: treat that as empty."""
        import urllib.error
        try:
            return _get_json(f"{site}/api/v0/{path}", token)
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                raise
            try:
                body = e.read().decode()[:150]
            except Exception:  # noqa
                body = ""
            problems.append(f"{path.split('?')[0]}: HTTP {e.code} {body}".strip())
            return empty

    total = get(f"stats/total?{q}", {})
    hits, offset_excl = [], []
    for _ in range(5):                                   # up to 500 paths
        extra = "".join(f"&exclude_paths={i}" for i in offset_excl)
        h = get(f"stats/hits?{q}&limit=100{extra}", {})
        hits += h.get("hits") or []
        offset_excl += [x.get("path_id") for x in h.get("hits") or [] if x.get("path_id")]
        if not h.get("more"):
            break
    locs = get(f"stats/locations?{q}&limit=50", {}).get("stats") or []

    daily = {}
    for st in total.get("stats") or []:
        daily[st.get("day")] = daily.get(st.get("day"), 0) + int(st.get("daily") or 0)
    site_daily, pages, ev = {}, [], {"apk": 0, "exe": 0, "opens": {}, "installs": {}, "tips": [], "grabs": {}}
    for h in hits:
        path, n = (h.get("path") or "").strip("/"), int(h.get("count") or 0)
        if not h.get("event"):
            pages.append({"path": "/" + path, "title": h.get("title") or "", "count": n})
            for st in h.get("stats") or []:
                site_daily[st.get("day")] = site_daily.get(st.get("day"), 0) + int(st.get("daily") or 0)
            continue
        parts = path.split("/")
        if path in ("download-apk", "get-apk"):
            ev["apk"] += n
        elif path in ("download-exe", "get-exe"):
            ev["exe"] += n
        elif parts[0] == "app" and len(parts) >= 3 and parts[1] in ("open", "install"):
            key = "opens" if parts[1] == "open" else "installs"
            ev[key][parts[2]] = ev[key].get(parts[2], 0) + n
        elif parts[0] == "tip" and len(parts) >= 3:
            amt = int(parts[2]) if parts[2].isdigit() else 0
            ev["tips"].append({"app": parts[1], "amount": amt, "country": _cc(parts[3] if len(parts) > 3 else ""), "count": n})
        elif parts[0] == "grab" and len(parts) >= 2:
            ev["grabs"][parts[1]] = ev["grabs"].get(parts[1], 0) + n
    pages.sort(key=lambda x: -x["count"])
    return {"visitors": int(total.get("total") or 0) - int(total.get("total_events") or 0),
            "daily": [{"day": d, "n": site_daily.get(d, 0)} for d in sorted(daily)],
            "pages": pages[:15], "events": ev,
            "countries": [{"id": _cc(l.get("id")), "name": l.get("name") or "Unknown", "count": int(l.get("count") or 0)} for l in locs],
            "problems": problems}


@app.get("/api/admin")
def api_admin():
    if not admin_ok():
        return jsonify(error="Only the owner can open this."), 403
    d = load_admin()
    tok = d.get("gc_token") or ""
    return jsonify(site=d.get("gc_site") or COUNTER_URL, has_token=bool(tok), token_hint=("…" + tok[-4:]) if tok else "",
                   repo=update_repo(), phone=ANDROID, tips=sorted(d.get("tips") or [], key=lambda t: t.get("date") or "", reverse=True))


@app.post("/api/admin/settings")
def api_admin_settings():
    if not admin_ok():
        return jsonify(error="Only the owner can do this."), 403
    b = request.get_json(silent=True) or {}
    with ADMIN_LOCK:
        d = load_admin()
        site = str(b.get("site") or "").strip().rstrip("/")
        if site:
            if not re.fullmatch(r"https://[a-z0-9-]+(\.[a-z0-9-]+)+", site):
                return jsonify(error="The address should look like https://grabbyapp.goatcounter.com"), 400
            d["gc_site"] = site
        if b.get("token") is not None:
            tok = str(b.get("token")).strip()
            if tok and not re.fullmatch(r"[A-Za-z0-9_-]{10,200}", tok):
                return jsonify(error="That doesn't look like a GoatCounter API key."), 400
            d["gc_token"] = tok
        save_admin(d)
    ADMIN_CACHE.clear()
    return jsonify(ok=True)


@app.get("/api/admin/stats")
def api_admin_stats():
    if not admin_ok():
        return jsonify(error="Only the owner can open this."), 403
    days = max(1, min(365, int(request.args.get("days") or 30)))
    key, now = days, time.time()
    hit = ADMIN_CACHE.get(key)
    if hit and now - hit[0] < 300 and not request.args.get("force"):
        return jsonify(hit[1])
    d, out = load_admin(), {"days": days, "time": int(now)}
    repo = update_repo()
    if repo:
        try:
            out["github"] = gh_downloads(repo)
        except Exception as e:  # noqa
            out["github_error"] = "Couldn't reach GitHub: " + str(e)[:120]
    else:
        out["github_error"] = "No GitHub repo set in update.json."
    if d.get("gc_token"):
        try:
            c = gc_stats(d.get("gc_site") or COUNTER_URL, d["gc_token"], days)
            out["counter"] = c
            if len(c["problems"]) >= 3:
                out["counter_error"] = "GoatCounter answered: " + " · ".join(c["problems"])
        except Exception as e:  # noqa
            msg = str(e)
            out["counter_error"] = ("GoatCounter refused the API key. Make a new one with 'Read statistics' ticked."
                                    if "401" in msg or "403" in msg else "Couldn't reach GoatCounter: " + msg[:120])
    ADMIN_CACHE[key] = (now, out)
    return jsonify(out)


@app.post("/api/admin/tips")
def api_admin_tips():
    """Add, edit or delete a real tip from the owner's GCash / Maya history."""
    if not admin_ok():
        return jsonify(error="Only the owner can do this."), 403
    b = request.get_json(silent=True) or {}
    with ADMIN_LOCK:
        d = load_admin()
        tips = d.get("tips") or []
        if b.get("delete"):
            tips = [t for t in tips if t.get("id") != b["delete"]]
        else:
            try:
                amount = round(float(b.get("amount") or 0), 2)
            except (TypeError, ValueError):
                amount = 0
            if amount <= 0 or amount > 1_000_000:
                return jsonify(error="Type the amount you received."), 400
            date = str(b.get("date") or "")[:10]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date):
                date = datetime.now().strftime("%Y-%m-%d")
            t = {"id": b.get("id") or uuid.uuid4().hex[:10], "amount": amount, "date": date,
                 "name": str(b.get("name") or "").strip()[:60], "app": str(b.get("app") or "gcash")[:12],
                 "country": _cc(b.get("country") or "PH") if b.get("country") != "??" else "??",
                 "note": str(b.get("note") or "").strip()[:200]}
            tips = [x for x in tips if x.get("id") != t["id"]] + [t]
        d["tips"] = tips
        save_admin(d)
    return jsonify(ok=True, tips=sorted(tips, key=lambda t: t.get("date") or "", reverse=True))


@app.get("/api/admin/tips.csv")
def api_admin_tips_csv():
    if not admin_ok():
        return jsonify(error="Only the owner can open this."), 403
    import csv
    import io
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Date", "Name", "Amount (PHP)", "App", "Country", "Note"])
    for t in sorted(load_admin().get("tips") or [], key=lambda t: t.get("date") or ""):
        w.writerow([t.get("date"), t.get("name"), t.get("amount"), t.get("app"), t.get("country"), t.get("note")])
    return Response("﻿" + buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=grabby-tips.csv"})


if __name__ == "__main__":
    start_background()
    port = int(os.getenv("PORT", "5000"))
    if os.getenv("VIDGRAB_RESTART"):          # after a restart: wait until the old copy frees the port
        for _ in range(60):
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                s.bind(("0.0.0.0", port)); s.close(); break
            except OSError:
                s.close(); time.sleep(0.25)
    APP_PORT = port
    import atexit
    atexit.register(tunnel_stop)
    if (owner_data().get("auto_online") or os.getenv("VIDGRAB_ONLINE")) and owner_data().get("pw"):
        threading.Timer(2.0, tunnel_start).start()
    if not has_ffmpeg():
        print("TIP: install ffmpeg for HD merging, MP3 and trimming:  winget install ffmpeg")
    print(f"\n  Grabby {APP_VERSION} running!")
    print(f"  On this computer : http://localhost:{port}")
    print(f"  On your phone    : http://{lan_ip()}:{port}   (same Wi-Fi)\n")
    if "--open" in sys.argv:
        threading.Timer(1.5, lambda: webbrowser.open(f"http://localhost:{port}")).start()
    app.run(host="0.0.0.0", port=port, threaded=True)
