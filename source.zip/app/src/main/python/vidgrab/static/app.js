/* Grabby 3.1 – black & white bordered design, expressive mascot, animated icons */
(() => {
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const store = {
    get(k, d) { try { const v = localStorage.getItem('vg_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('vg_' + k, JSON.stringify(v)); } catch (e) {} },
  };
  const ANDROID = !!window.VidGrabAndroid;   // true inside the Grabby phone app
  const PHONE = ANDROID || /Android|iPhone|iPad/i.test(navigator.userAgent);
  const DESKTOP = window.GRABBY_DESKTOP === true;   // the Windows app (Grabby.exe)
  if (ANDROID) {                 // phone app: fixed size, so the screen never zooms or slides sideways
    document.documentElement.classList.add('app');
    const vp = document.querySelector('meta[name=viewport]');
    if (vp) vp.content = 'width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover';
  }
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* =====================================================================
     ICONS – our own line icons. Each has named parts (.p-*) that the CSS
     animates (on hover, on loop, or once with .play).
     ===================================================================== */
  const ICONS = {
    download: '<g class="p-arrow"><path d="M12 3v11M7.5 9.5 12 14l4.5-4.5"/></g><path d="M5 20h14"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path class="p-hand" d="M12 12V6.5"/><path class="p-hand2" d="M12 12l3.5 2"/>',
    coffee: '<path d="M4 10h12v4a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z"/><path d="M16 12h1.5a2 2 0 0 1 0 4H16"/><path d="M3 21h14"/><g class="p-steam"><path d="M8 3.5c-.9.9.9 1.7 0 2.7"/><path d="M12 3.5c-.9.9.9 1.7 0 2.7"/></g>',
    phone: '<g class="p-body"><rect x="6.5" y="2.5" width="11" height="19" rx="2.5"/><path d="M11 18h2"/></g><g class="p-waves"><path d="M3.5 9c-1 2-1 4 0 6"/><path d="M20.5 9c1 2 1 4 0 6"/></g>',
    link: '<path class="p-l1" d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path class="p-l2" d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    film: '<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M7 4v16M17 4v16"/><g class="p-holes"><path d="M3 8.5h4M3 12h4M3 15.5h4M17 8.5h4M17 12h4M17 15.5h4"/></g><path class="p-play" d="M10.5 9.8v4.4l3.6-2.2z"/>',
    music: '<g class="p-notes"><path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></g>',
    gear: '<g class="p-gear"><circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/></g>',
    scissors: '<g class="p-b1"><circle cx="6" cy="6" r="3"/><path d="M8.2 8.2 20 20"/></g><g class="p-b2"><circle cx="6" cy="18" r="3"/><path d="M8.2 15.8 20 4"/></g>',
    check: '<path class="p-check" d="M5 12.5l4.5 4.5L19 7.5"/>',
    x: '<g class="p-x"><path d="M6 6l12 12M18 6 6 18"/></g>',
    save: '<path d="M5 3h11l3 3v15H5z"/><path d="M8 3v5h8"/><path d="M8 21v-7h8v7"/>',
    repeat: '<g class="p-spin"><path d="M17 2l4 4-4 4"/><path d="M3 12v-2a4 4 0 0 1 4-4h14"/><path d="M7 22l-4-4 4-4"/><path d="M21 12v2a4 4 0 0 1-4 4H3"/></g>',
    trash: '<g class="p-lid"><path d="M4 7h16"/><path d="M9 7V4h6v3"/></g><path d="M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
    copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path class="p-back" d="M5 15V5a2 2 0 0 1 2-2h8"/>',
    search: '<g class="p-glass"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></g>',
    inbox: '<path d="M3 13l3-8h12l3 8v6H3z"/><path d="M3 13h5l1 2h6l1-2h5"/><path class="p-drop" d="M12 5.5v5M9.8 8.3 12 10.5l2.2-2.2"/>',
    folder: '<path d="M3 6h6l2 2h10v11H3z"/><path class="p-paper" d="M7 12h10M7 15h6"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path class="p-shackle" d="M8 11V7a4 4 0 0 1 8 0v4"/><path d="M12 15v2"/>',
    upload: '<g class="p-up"><path d="M12 20V9M7.5 13.5 12 9l4.5 4.5"/></g><path d="M5 4h14"/>',
    heart: '<path class="p-heart" d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10z"/>',
    puzzle: '<path class="p-piece" d="M4 7h4a2 2 0 1 1 4 0h4v4a2 2 0 1 1 0 4v4h-4a2 2 0 1 0-4 0H4v-4a2 2 0 1 0 0-4z"/>',
    info: '<circle cx="12" cy="12" r="9"/><g class="p-i"><path d="M12 11v6"/><path d="M12 7.5v.5"/></g>',
    alert: '<g class="p-tri"><path d="M12 3l10 18H2z"/><path d="M12 10v4M12 17.5v.5"/></g>',
    bolt: '<path class="p-bolt" d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
    timer: '<circle cx="12" cy="13" r="8"/><path class="p-hand" d="M12 13V8.5"/><path d="M9 2h6"/>',
    clipboard: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V2.5h6V4"/><path class="p-lines" d="M9 10h6M9 14h4"/>',
    wallet: '<rect x="3" y="7" width="18" height="13" rx="2.5"/><path d="M3 11h18M16 15.5h2"/><circle class="p-coin" cx="17" cy="3.5" r="2"/>',
    external: '<path d="M18 14v6H4V6h6"/><g class="p-arrow"><path d="M14 4h6v6M20 4l-9 9"/></g>',
    chevron: '<path class="p-chev" d="M6 9l6 6 6-6"/>',
    sparkle: '<path class="p-spark" d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/>',
    globe: '<circle cx="12" cy="12" r="9"/><g class="p-globe"><path d="M3 12h18M12 3c2.6 2.6 3.8 5.6 3.8 9s-1.2 6.4-3.8 9c-2.6-2.6-3.8-5.6-3.8-9S9.4 5.6 12 3z"/></g>',
    image: '<rect x="3" y="4" width="18" height="16" rx="2.5"/><circle class="p-sun" cx="9" cy="9.5" r="2"/><path class="p-hill" d="M3 17l5-5 4 4 3-3 6 6"/>',
    cc: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path class="p-cc" d="M10.5 10.2a2.3 2.3 0 1 0 0 3.6M17 10.2a2.3 2.3 0 1 0 0 3.6"/>',
    list: '<path d="M9 6h11M9 12h11M9 18h11"/><g class="p-dots"><circle cx="4.5" cy="6" r="1.2"/><circle cx="4.5" cy="12" r="1.2"/><circle cx="4.5" cy="18" r="1.2"/></g>',
    gift: '<g class="p-lid"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8C9 3 5 5 7.5 8M12 8c3-5 7-3 4.5 0"/></g><path d="M5 12v8h14v-8M12 8v12"/>',
    share: '<circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path class="p-link" d="M8.2 10.8l7.6-4.4M8.2 13.2l7.6 4.4"/>',
    star: '<path class="p-star" d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
    bell: '<path class="p-bell" d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
    send: '<path class="p-plane" d="M21 3L3 10.5l7 2.5 2.5 7z"/><path d="M10 13l11-10"/>',
  };
  const ic = (name, cls = 'sm') => `<svg class="ic ic-${name} ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ''}</svg>`;
  function hydrateIcons(root = document) {
    $$('i[data-ic]', root).forEach(el => {
      const tmp = document.createElement('div');
      tmp.innerHTML = ic(el.dataset.ic, el.className);
      el.replaceWith(tmp.firstChild);
    });
  }
  hydrateIcons();
  // play an icon's animation once (e.g. when a tab is clicked)
  function playIcon(btn) {
    const s = btn && btn.querySelector('.ic'); if (!s) return;
    s.classList.remove('play'); void s.getBoundingClientRect(); s.classList.add('play');
    setTimeout(() => s.classList.remove('play'), 1300);
  }

  /* ------------------------------------------------ state */
  const state = {
    info: null,
    kind: store.get('kind', 'video'),
    quality: store.get('quality', '1080'),
    audio: store.get('audio', 'mp3'),
    abr: store.get('abr', '192'),
    ffmpeg: true,
    jobs: new Map(),
    history: store.get('history', []),
    tips: null,
    cups: store.get('cups', 1),
    errStreak: 0,
    shrink: store.get('shrink', false),
  };

  /* ------------------------------------------------ helpers */
  const fmtBytes = b => !b ? '' : b >= 1073741824 ? (b / 1073741824).toFixed(2) + ' GB' : b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';
  const fmtTime = s => { if (s == null || !isFinite(s)) return ''; s = Math.round(s); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = String(s % 60).padStart(2, '0'); return h ? `${h}:${String(m).padStart(2, '0')}:${x}` : `${m}:${x}`; };
  const isUrl = s => /^https?:\/\/\S+\.\S+/i.test((s || '').trim());
  const api = async (path, body) => {
    const r = await fetch(path, body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {});
    let d = {}; try { d = await r.json(); } catch (e) {}
    if (!r.ok || d.error) throw new Error(d.error || `Server error (${r.status})`);
    return d;
  };
  let toastT;
  const toast = msg => { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2600); };

  /* ------------------------------------------------ anonymous counts (GoatCounter)
     Only a short label is sent, like "app/open/android" or "tip/gcash/100/PH". Never names, links,
     videos or anything you type. Off on the owner's own computer, and anyone can switch it off in Settings. */
  const COUNTER = window.GRABBY_COUNTER || '';
  const TZ_CC = { 'Asia/Manila': 'PH', 'Asia/Singapore': 'SG', 'Asia/Tokyo': 'JP', 'Asia/Seoul': 'KR', 'Asia/Dubai': 'AE', 'Asia/Riyadh': 'SA',
    'Asia/Qatar': 'QA', 'Asia/Kuwait': 'KW', 'Asia/Hong_Kong': 'HK', 'Asia/Taipei': 'TW', 'Asia/Kuala_Lumpur': 'MY', 'Asia/Jakarta': 'ID',
    'Asia/Bangkok': 'TH', 'Asia/Ho_Chi_Minh': 'VN', 'Asia/Kolkata': 'IN', 'Australia/Sydney': 'AU', 'Europe/London': 'GB', 'America/Toronto': 'CA' };
  function myCountry() {
    try { const tz = Intl.DateTimeFormat().resolvedOptions().timeZone; if (TZ_CC[tz]) return TZ_CC[tz]; } catch (e) { }
    const m = (navigator.language || '').match(/-([A-Za-z]{2})$/); return m ? m[1].toUpperCase() : 'XX';
  }
  function count(path) {
    if (!COUNTER || !store.get('optStats', true)) return;
    try {
      const q = new URLSearchParams({ p: path, t: path, e: 'true', r: '', s: String(screen.width || 0), rnd: Math.random().toString(36).slice(2) });
      const im = new Image(); im.referrerPolicy = 'no-referrer'; im.src = COUNTER + '/count?' + q;
    } catch (e) { }
  }
  window.grabbyCount = count;
  (function countOpen() {
    const plat = ANDROID ? 'android' : DESKTOP ? 'windows' : PHONE ? 'web-phone' : 'web-pc';
    if (!store.get('installCounted', false)) { count('app/install/' + plat); store.set('installCounted', true); }
    const today = new Date().toISOString().slice(0, 10);
    if (store.get('openDay', '') !== today) { count('app/open/' + plat); store.set('openDay', today); }   // once a day = daily users
  })();

  /* =====================================================================
     GRABBY – mascot with 17 expressions
     idle · watching · thinking · surprised · confused · working · happy
     excited · love · sad · angry · sleepy · dizzy · cool · music · wink · shrug
     ===================================================================== */
  const mascot = $('#mascot'), bubble = $('#bubble');
  const LINES = {
    idle: ["Paste a link and I'll grab it for you.", "Facebook, Instagram, X, TikTok. I can fetch them all.", "Psst... tap me.", "Ready when you are."],
    watching: ["I'm watching... go on.", "Ooh, what are you typing?"],
    thinking: ["Let me look at that link...", "Finding the best quality...", "Checking what I can grab..."],
    surprised: ["Oh! A link!", "Whoa, a new one!"],
    confused: ["Hmm, that doesn't look like a link.", "Is that a link? It should start with https://"],
    found: ["Found it. Pick a quality and press Download.", "Nice one. Ready to grab it.", "Got the details. Choose your format."],
    working: ["On it. Grabbing your file...", "Downloading at full speed.", "Almost there, hang tight.", "Bits and bytes coming your way."],
    excited: ["Done! Your file is ready!", "Grabbed it! That was fast!", "Another one saved! High five!"],
    sad: ["Oops, that didn't work.", "I couldn't grab that one.", "That link gave me trouble."],
    angry: ["Ugh! This link really doesn't want to be grabbed.", "Grr. Try another link?"],
    sleepy: ["Zzz... wake me up with a link.", "Zzz... dreaming of HD videos..."],
    wake: ["Oh! I'm awake!", "Huh? I wasn't sleeping!"],
    dizzy: ["Whoa... the room is spinning.", "Okay okay, too many taps!"],
    cool: ["Max quality. Fancy.", "Ooh, crisp. I like your style."],
    music: ["Music mode! I love MP3s.", "Turning it into a bop."],
    wink: ["Hehe, that tickles!", "Boop!", "Hi again!", "Beep boop."],
    shrug: ["Okay, stopped it. No problem.", "Cancelled. Maybe next time."],
    love: ["Every coffee keeps me running.", "Aww, you're the best.", "Thank you for thinking of us."],
    laughing: ["Hahaha! Stop it!", "Hehe, that tickles so much!"],
    scared: ["Eek! Careful with that one!", "W-wait, are you sure?"],
    proud: ["Nailed it.", "Look at that. Perfect."],
    curious: ["Ooh, what's this?", "Interesting..."],
    yawn: ["*yaaawn*... getting sleepy..."],
    dance: ["Your file is ready! Dance time!", "Download complete! Woo!"],
    blush: ["Aww, stop it, you're making me blush.", "You're too kind!"],
    away: ["Be right back!", "Wheee!", "Off I go!"],
    follow: ["I'll come with you!", "Wait for me!", "Right behind you!", "I'm still here!", "Scroll on, I'm watching!"],
    back: ["Home sweet home!", "Back in my spot!", "Made it back!"],
    hug: ["Awww, a hug! Best user ever.", "*squeezes back* Hehe!"],
    pout: ["Hmph! Okay, that's enough tapping.", "I'm not talking to you for 3 seconds. Hmph."],
    kiss: ["Mwah!", "Sending you love!"],
    salute: ["Yes, boss!", "Grabby reporting for duty!"],
    sneeze: ["Ah... ah... ACHOO! Sorry!", "Achoo! Dusty in here."],
    spin: ["Wheee, spin!", "Did you see that spin?"],
    flip: ["Backflip! Ta-daa!", "Nailed the landing!"],
    raspberry: ["Pbbbbt!", "Bleh! Hehe."],
    highfive: ["High five!", "Up top!"],
    ticklish: ["Hahaha, not the belly!", "That tickles! Hahaha!"],
    ouch: ["Ow, my eye!", "Hey, careful with my eyes!"],
    boing: ["Boing! Not the antenna!", "Hey, my antenna!"],
    hop: ["Hey, that's my foot!", "Ouch, my toes!"],
  };
  const pick = a => a[Math.floor(Math.random() * a.length)];
  let moodTimer, lastAct = Date.now();
  const activeCount = () => [...state.jobs.values()].filter(j => !['done', 'error', 'cancelled'].includes(j.data.status)).length;
  const baseMood = () => activeCount() ? 'working' : 'idle';
  function say(text) {
    bubble.textContent = text;
    bubble.classList.remove('pop'); void bubble.offsetWidth; bubble.classList.add('pop');
  }
  // setMood(mood, line, ms): line=false keeps the bubble; ms = go back to the base mood after ms
  function setMood(mood, line, ms) {
    clearTimeout(moodTimer);
    if (mascot.dataset.mood !== mood) { mascot.dataset.mood = ''; void mascot.offsetWidth; }
    mascot.dataset.mood = mood;
    if (line !== false) say(line || pick(LINES[mood] || LINES.idle));
    if (typeof dockMirror === 'function') dockMirror(mood, bubble.textContent);
    if (ms) moodTimer = setTimeout(() => setMood(baseMood(), false), ms);
  }
  const flash = (mood, ms = 2600, line) => { if (mascot.dataset.mood === 'working' && !['excited', 'sad', 'angry', 'shrug'].includes(mood)) { say(line || pick(LINES[mood] || LINES.idle)); return; } setMood(mood, line, ms); };

  // poke: wink, or dizzy after 5 quick taps
  /* ---- tap reactions ----
     where you tap:  antenna → boing · eyes → ouch · belly → ticklish · hands → high five · feet → hop
     anywhere else:  a random reaction
     quick taps:     2 → laugh · 3 → loop-the-loop · 4 → spin · 5-7 → dizzy · 8+ → pout
     press & hold:   hug */
  const TAP_POOL = ['wink', 'kiss', 'salute', 'sneeze', 'spin', 'flip', 'raspberry', 'blush', 'cool', 'proud', 'laughing', 'highfive'];
  let taps = [], tapT, holdT, held = false, lastPick = '';
  mascot.addEventListener('pointerdown', () => {
    held = false; mascot.classList.add('pressing');
    holdT = setTimeout(() => { held = true; mascot.classList.remove('pressing'); setMood('hug', undefined, 2600); }, 650);
  });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach(ev => mascot.addEventListener(ev, () => { clearTimeout(holdT); mascot.classList.remove('pressing'); }));
  mascot.addEventListener('click', e => {
    if (held) { held = false; return; }
    const now = Date.now(); taps = taps.filter(t => now - t < 1400); taps.push(now);
    clearTimeout(tapT);
    const n = taps.length;
    if (n >= 8) { taps = []; setMood('pout', undefined, 3000); return; }
    if (n >= 5) { setMood('dizzy', undefined, 3000); return; }
    if (n === 4) { setMood('spin', undefined, 1400); return; }
    if (n === 3) { tapT = setTimeout(() => { if (taps.length === 3) joyride(); taps = []; }, 450); setMood('laughing', 'Again? Hold on...', 1500); return; }
    if (n === 2) { setMood('laughing', undefined, 1800); return; }
    const t = e.target;
    let mood;
    if (t.closest('.antenna, .propeller')) mood = 'boing';
    else if (t.closest('.eyes, .e-normal')) mood = 'ouch';
    else if (t.closest('.screen, .belly')) mood = 'ticklish';
    else if (t.closest('.arm-l, .arm-r')) mood = 'highfive';
    else if (t.closest('.foot')) mood = 'hop';
    else { do { mood = pick(TAP_POOL); } while (mood === lastPick); lastPick = mood; }
    setMood(mood, undefined, mood === 'flip' || mood === 'sneeze' ? 1900 : 2000);
    if (mood === 'sneeze') setTimeout(() => { if (typeof puffs === 'function' && mascot.dataset.mood === 'sneeze') puffs(homePoint(), 9); }, 700);
  });
  // eyes follow the pointer
  window.addEventListener('pointermove', e => {
    const r = mascot.getBoundingClientRect();
    const dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height * .45);
    const d = Math.hypot(dx, dy) || 1, k = Math.min(5, d / 40);
    mascot.style.setProperty('--px', (dx / d * k).toFixed(1) + 'px');
    mascot.style.setProperty('--py', (dy / d * k).toFixed(1) + 'px');
  });
  // fall asleep after 25s of no activity, wake up surprised
  const wake = () => {
    lastAct = Date.now();
    if (mascot.dataset.mood === 'sleepy') setMood('surprised', pick(LINES.wake), 1500);
  };
  ['pointerdown', 'keydown', 'wheel', 'touchstart'].forEach(ev => window.addEventListener(ev, wake, { passive: true }));
  window.addEventListener('pointermove', () => { if (Date.now() - lastAct > 800) wake(); }, { passive: true });
  setInterval(() => {
    const quiet = Date.now() - lastAct;
    if (mascot.dataset.mood === 'idle' && quiet > 20000 && quiet < 26000) setMood('yawn', undefined, 2300);
    else if (['idle', 'yawn'].includes(mascot.dataset.mood) && quiet > 26000) setMood('sleepy');
    else if (mascot.dataset.mood === 'idle' && !state.info && Math.random() < .25) say(pick(LINES.idle));
  }, 6000);
  // tip buttons make Grabby fall in love
  document.addEventListener('mouseover', e => {
    const b = e.target.closest('[data-goto=support], .btn.red');
    if (b && !b.contains(e.relatedTarget) && !['love', 'blush'].includes(mascot.dataset.mood)) flash(Math.random() < .5 ? 'love' : 'blush', 2200);
    const d = e.target.closest('[title=Delete], #clearHist, #qrRemove');
    if (d && !d.contains(e.relatedTarget)) flash('scared', 1800);
    const c = e.target.closest('.platforms span, .thumb-wrap');
    if (c && !c.contains(e.relatedTarget) && mascot.dataset.mood === 'idle') flash('curious', 1800);
  });

  /* ------------------------------------------------ tabs */
  // ---- Back button (phone app): page history inside Grabby, so Back never leaves to a blank / loading screen
  const tabTrail = [];
  let curTab = 'download', goingBack = false;
  function showTab(name) {
    if (name !== curTab && !goingBack) { tabTrail.push(curTab); if (tabTrail.length > 30) tabTrail.shift(); }
    curTab = name;
    $$('.nav-btn').forEach(b => b.classList.toggle('on', b.dataset.tab === name));
    $$('.tab-panel').forEach(p => p.classList.toggle('on', p.id === 'tab-' + name));
    if (name === 'history') renderHistory();
    if (name === 'library') { renderLibrary(); loadLibrary(); }
    if (name === 'vault') loadVault();
    if (window.grabbyTabChanged) window.grabbyTabChanged(name);
    if (window.grabbyIncognito) window.grabbyIncognito(name === 'vault');
    try { if (ANDROID && window.VidGrabAndroid.secure) window.VidGrabAndroid.secure(name === 'vault'); } catch (e) { }
    if (name === 'apps') { loadOwner(); loadAppInfo(); }
    if (name === 'settings') loadSettingsInfo();
    if (name === 'admin' && window.grabbyAdmin) window.grabbyAdmin();
    if (name === 'grabby') { $('#boxDot').dataset.sticker = ''; renderHub(); updGift(); }
    if (name !== 'grabby' && $('#tab-grabby').classList.contains('on')) {}
    if (name !== 'library' && typeof showSelect === 'function' && lib.selecting) showSelect(false);
    if (name === 'support') { renderSupport(); setMood('love', undefined, 5000); }
    else if (mascot.dataset.mood === 'love') setMood(baseMood(), false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => typeof checkDock === 'function' && checkDock(), 80);
  }
  $$('.nav-btn').forEach(b => b.onclick = () => { playIcon(b); showTab(b.dataset.tab); });
  document.addEventListener('click', e => {
    const a = e.target.closest('[data-goto]');
    if (a) { e.preventDefault(); playIcon(a); $('#tipModal').hidden = true; showTab(a.dataset.goto); }
  });

  /* ------------------------------------------------ URL input + preview */
  const urlIn = $('#url');
  let previewT, previewSeq = 0;
  urlIn.addEventListener('focus', () => { abortFly = true; });
  urlIn.addEventListener('focus', () => { if (['idle', 'sleepy'].includes(mascot.dataset.mood)) setMood('watching'); });
  urlIn.addEventListener('blur', () => { if (mascot.dataset.mood === 'watching') setMood(baseMood(), false); });
  urlIn.addEventListener('input', () => {
    const v = urlIn.value.trim();
    $('#clearUrl').hidden = !urlIn.value;
    clearTimeout(previewT);
    if (!v) { resetPreview(); if (!activeCount()) setMood('watching', false); return; }
    if (isUrl(v)) { if (!activeCount()) setMood('surprised'); previewT = setTimeout(loadPreview, 120); }
    else if (v.length > 6 && !/^h(t(t(ps?)?)?)?:?\/?\/?/i.test(v)) { if (!activeCount()) setMood('confused'); }
    else if (!activeCount()) setMood('watching', false);
  });
  urlIn.addEventListener('keydown', e => { if (e.key === 'Enter') startDownload(); });
  // pasted links are checked right away
  urlIn.addEventListener('paste', () => setTimeout(() => { clearTimeout(previewT); if (isUrl(urlIn.value)) loadPreview(); }, 0));
  $('#clearUrl').onclick = () => { urlIn.value = ''; $('#clearUrl').hidden = true; resetPreview(); urlIn.focus(); setMood('idle'); };
  $('#pasteBtn').onclick = async () => {
    try {
      const t = ANDROID ? window.VidGrabAndroid.getClipboard() : await navigator.clipboard.readText();
      if (!t) return toast('Clipboard is empty');
      urlIn.value = t.trim(); urlIn.dispatchEvent(new Event('input'));
      clearTimeout(previewT); loadPreview();
    } catch (e) { urlIn.focus(); toast('Long-press the box and tap Paste'); }
  };
  document.addEventListener('dragover', e => e.preventDefault());
  document.addEventListener('drop', e => {
    const t = e.dataTransfer.getData('text/uri-list') || e.dataTransfer.getData('text/plain');
    if (t) { e.preventDefault(); urlIn.value = t.trim().split('\n')[0]; urlIn.dispatchEvent(new Event('input')); }
  });

  function resetPreview() {
    state.info = null;
    $('#preview').hidden = true; $('#skeleton').hidden = true; $('#previewCard').hidden = true;
    renderQualities();
  }
  async function loadPreview() {
    const url = urlIn.value.trim();
    if (!isUrl(url)) { resetPreview(); return; }
    if (state.info && state.info.url === url) return;
    if (isPlaylistUrl(url)) {
      loadPlaylist(url);
      if (!/[?&]v=|youtu\.be\//.test(url)) { resetPreview(); return; }   // a pure playlist / channel: no single preview
    }
    const seq = ++previewSeq;
    $('#preview').hidden = true; $('#skeleton').hidden = false; $('#previewCard').hidden = false;
    if (!activeCount()) setTimeout(() => { if (seq === previewSeq && !state.info) setMood('thinking'); }, 250);
    try {
      const d = await api('/api/info', { url });
      if (seq !== previewSeq) return;
      state.info = d; state.errStreak = 0;
      state.ffmpeg = d.ffmpeg; applyFfmpeg();
      $('#pThumb').src = d.thumbnail || '';
      $('#pTitle').textContent = d.title || 'Video';
      $('#pSite').textContent = d.site || 'Link';
      $('#pUploader').textContent = d.uploader || '';
      $('#pDur').textContent = fmtTime(d.duration);
      $('#pDur').hidden = !d.duration;
      $('#skeleton').hidden = true; $('#preview').hidden = false;
      renderQualities();
      if (d.photo_only && state.kind !== 'photo') { setKind('photo'); flash('proud', 2600, 'This post is photos only, so I switched to Photo mode.'); }
      else flash('happy', 2200, pick(LINES.found));
      setTimeout(() => visit(state.kind === 'audio' ? $('#kindSeg') : $('#qualityChips'), state.kind === 'audio' ? 'Pick MP3 or M4A here!' : 'Pick your quality here!'), 1400);
    } catch (e) {
      if (seq !== previewSeq) return;
      $('#skeleton').hidden = true; $('#previewCard').hidden = true;
      logErr(url, e.message);
      shake(); oops(e.message);
    }
  }
  const shake = () => { const b = $('.url-box'); b.classList.remove('shake'); void b.offsetWidth; b.classList.add('shake'); };
  function oops(msg) {
    state.errStreak++;
    const m = msg && msg.length < 220 ? msg : '';
    setMood(state.errStreak >= 2 ? 'angry' : 'sad', state.errStreak >= 2 ? pick(LINES.angry) + (m ? ' ' + m : '') : (m || pick(LINES.sad)), 6000);
  }

  /* ------------------------------------------------ download menu */
  const QUALS = [['best', 'Best', 'up to 4K'], ['2160', '4K', ''], ['1440', '1440p', ''], ['1080', '1080p', 'Full HD'], ['720', '720p', 'HD'], ['480', '480p', 'small'], ['360', '360p', 'tiny']];
  function renderQualities() {
    const box = $('#qualityChips'); box.innerHTML = '';
    const hs = state.info && state.info.heights && state.info.heights.length ? state.info.heights : null;
    const maxH = hs ? hs[0].h : null;
    const list = hs
      ? QUALS.filter(([v]) => v === 'best' || hs.some(x => x.h >= +v * .9 && x.h <= +v * 1.1))
      : QUALS.filter(([v]) => ['best', '1080', '720', '480'].includes(v));
    if (!list.some(([v]) => v === state.quality)) state.quality = list.length > 1 ? list[1][0] : 'best';
    list.forEach(([v, name, sub], i) => {
      const c = document.createElement('button');
      c.className = 'chip' + (v === state.quality ? ' on' : '');
      let size = '';
      if (hs) {
        const target = v === 'best' ? hs[0] : hs.filter(x => x.h <= +v * 1.1)[0];
        if (target && target.size) size = '≈ ' + fmtBytes(target.size);
      }
      const tag = (v === '2160' || (v === 'best' && maxH >= 2000)) ? '4K' : (v === '1080' ? 'HD' : '');
      c.innerHTML = `${tag ? `<span class="tag">${tag}</span>` : ''}<b></b><small></small>`;
      c.querySelector('b').textContent = name;
      c.querySelector('small').textContent = size || sub || ' ';
      c.style.animation = `rise .4s ${i * 0.05}s var(--spring) both`;
      c.onclick = () => {
        state.quality = v; store.set('quality', v);
        $$('#qualityChips .chip').forEach(x => x.classList.toggle('on', x === c)); updateGoText();
        if (['best', '2160', '1440'].includes(v)) flash('cool', 2800); else flash('happy', 1500, `${name} it is.`);
      };
      box.appendChild(c);
    });
    updateGoText();
  }
  function setKind(k, react) {
    state.kind = k; store.set('kind', k);
    $('#kindSeg').classList.toggle('audio', k === 'audio');
    $('#kindSeg').classList.toggle('photo', k === 'photo');
    $$('#kindSeg button').forEach(b => b.classList.toggle('on', b.dataset.kind === k));
    $('#panel-video').classList.toggle('on', k === 'video');
    $('#panel-audio').classList.toggle('on', k === 'audio');
    $('#panel-photo').classList.toggle('on', k === 'photo');
    $('#menu').classList.toggle('k-audio', k === 'audio');
    $('#menu').classList.toggle('k-photo', k === 'photo');
    updateGoText();
    if (react) {
      if (k === 'audio') flash('music', 3200);
      else if (k === 'photo') flash('proud', 2000, 'Photo mode! I save every slide, too.');
      else flash('happy', 1500, 'Video mode. Lights, camera, action!');
    }
  }
  $$('#kindSeg button').forEach(b => b.onclick = () => { playIcon(b); setKind(b.dataset.kind, true); });
  function bindChips(sel, key, attr) {
    $$(sel + ' .chip').forEach(c => {
      c.classList.toggle('on', c.dataset[attr] === state[key]);
      c.onclick = () => {
        if (c.disabled) return; state[key] = c.dataset[attr]; store.set(key, state[key]);
        $$(sel + ' .chip').forEach(x => x.classList.toggle('on', x === c)); updateGoText();
        if (key === 'abr' && state[key] === '320') flash('cool', 2400, '320 kbps. Studio quality.');
      };
    });
  }
  bindChips('#audioFmtChips', 'audio', 'audio');
  bindChips('#abrChips', 'abr', 'abr');
  function updateGoText() {
    let t;
    if (state.kind === 'audio') t = (state.audio === 'mp3' && state.ffmpeg) ? `Download MP3 · ${state.abr} kbps` : 'Download Audio (M4A)';
    else if (state.kind === 'photo') t = 'Save photos';
    else t = 'Download MP4 · ' + (state.quality === 'best' ? 'Best' : state.quality + 'p') + ($('#optShrink') && $('#optShrink').checked && state.ffmpeg ? ' · small' : '');
    $('#goTxt').textContent = t;
    $('#abrChips').style.opacity = (state.audio === 'mp3' && state.ffmpeg) ? 1 : .4;
  }
  function applyFfmpeg() {
    $('#ffWarn').hidden = state.ffmpeg;
    const mp3 = $('#audioFmtChips [data-audio=mp3]');
    mp3.disabled = !state.ffmpeg;
    if (!state.ffmpeg && state.audio === 'mp3') { state.audio = 'm4a'; bindChips('#audioFmtChips', 'audio', 'audio'); }
    $('#shrinkTgl').hidden = !state.ffmpeg;
    if (!state.ffmpeg) $('#optSubs').querySelector('[value=burn]').disabled = true;
    ['#trimStart', '#trimEnd'].forEach(s => { $(s).disabled = !state.ffmpeg; $(s).placeholder = state.ffmpeg ? (s === '#trimStart' ? '0:00' : 'end') : 'needs ffmpeg'; });
    updateGoText();
  }
  ['Shrink', 'Clip'].forEach(n => { const el = $('#opt' + n); el.checked = store.get('opt' + n, el.checked); el.addEventListener('change', () => { store.set('opt' + n, el.checked); updateGoText(); if (n === 'Shrink' && el.checked) flash('proud', 2200, 'Small enough for Messenger. Promise!'); }); });
  ['Subs', 'SubLang'].forEach(n => { const el = $('#opt' + n); el.value = store.get('opt' + n, el.value); el.onchange = () => { store.set('opt' + n, el.value); if (n === 'Subs' && el.value !== 'off') flash('happy', 2000, 'Subtitles on. Perfect for K-dramas!'); }; });
  ['Autosave', 'Notify', 'Sound', 'Confetti'].forEach(n => {
    const el = $('#opt' + n); el.checked = store.get('opt' + n, el.checked);
    el.onchange = async () => {
      store.set('opt' + n, el.checked);
      if (n === 'Notify' && ANDROID) { syncPhoneNotify(true); return; }
      if (n === 'Notify' && el.checked && 'Notification' in window && Notification.permission !== 'granted') {
        const p = await Notification.requestPermission();
        if (p !== 'granted') { el.checked = false; store.set('optNotify', false); toast('Notifications are blocked in this browser'); }
      }
    };
  });
  // ---- phone notifications (Android app): progress bars with Cancel, finished / failed, updates
  function syncPhoneNotify(ask) {
    const B = window.VidGrabAndroid;
    if (!ANDROID || !B || !B.setNotify) return;
    const dl = $('#optNotify').checked, up = $('#optNotifyUpd').checked;
    B.setNotify('downloads', dl); B.setNotify('updates', up);
    if (ask && (dl || up) && B.canNotify && !B.canNotify()) {
      B.askNotify();
      toast('Allow notifications so Grabby can show download progress');
    }
  }
  if (ANDROID && window.VidGrabAndroid.setNotify) {
    $('#notifyUpdRow').hidden = false;
    $('#notifySub').textContent = 'Progress bars with a Cancel button, and a note when each download finishes or fails. Downloads keep going when you leave the app.';
    $('#optNotify').checked = store.get('optNotify', true);
    $('#optNotifyUpd').checked = store.get('optNotifyUpd', true);
    $('#optNotifyUpd').onchange = () => { store.set('optNotifyUpd', $('#optNotifyUpd').checked); syncPhoneNotify(true); };
    syncPhoneNotify(false);
  }
  // opened by tapping a notification: go to that page (and play the video)
  window.grabbyOpen = (tab, play) => {
    try {
      if (!$('#player').hidden) closePlayer();
      if (tab) showTab(tab);
      if (play) playByName(play);
    } catch (e) { }
  };
  setTimeout(() => {
    try {
      const o = ANDROID && window.VidGrabAndroid.takeOpen && window.VidGrabAndroid.takeOpen();
      if (o) { const d = JSON.parse(o); window.grabbyOpen(d.goto, d.play); }
    } catch (e) { }
  }, 400);
  $('#adv').addEventListener('toggle', e => { if (e.target.open) playIcon($('#adv summary')); });

  // ripple on all buttons
  document.addEventListener('pointerdown', e => {
    const b = e.target.closest('.btn'); if (!b) return;
    const r = b.getBoundingClientRect(), s = document.createElement('span'), size = Math.max(r.width, r.height);
    s.className = 'ripple'; s.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX - r.left - size / 2}px;top:${e.clientY - r.top - size / 2}px`;
    b.appendChild(s); setTimeout(() => s.remove(), 650);
  });
  $('#goBtn').onclick = () => startDownload();

  /* ------------------------------------------------ problem log (Settings → Problem report) */
  function logErr(url, msg) {
    const log = store.get('errlog', []);
    log.unshift({ t: new Date().toISOString().slice(0, 19).replace('T', ' '), url: String(url || '').slice(0, 160), msg: String(msg || '').slice(0, 400) });
    store.set('errlog', log.slice(0, 12));
  }

  /* ------------------------------------------------ start download */
  const optBody = () => ({ shrink: $('#optShrink').checked && state.kind === 'video', subs: state.kind === 'video' ? $('#optSubs').value : 'off', sublang: $('#optSubLang').value });
  async function startDownload(overrides) {
    const url = (overrides && overrides.url) || urlIn.value.trim();
    if (!isUrl(url)) { shake(); urlIn.focus(); setMood('confused', 'Paste a link first, then press Download.', 3000); return; }
    const info = state.info && state.info.url === url ? state.info : null;
    const body = Object.assign({
      url,
      kind: state.kind, quality: state.quality, audio: state.audio, abr: state.abr,
      start: $('#trimStart').value.trim(), end: $('#trimEnd').value.trim(),
      filename: $('#fileName').value.trim(),
      title: info && info.title, thumbnail: info && info.thumbnail, site: info && info.site,
    }, optBody(), overrides || {});
    $('#goBtn').disabled = true;
    abortFly = true;
    try {
      const job = await api('/api/download', body);
      addJob(job, body);
      setMood('working');
      $('#fileName').value = '';
      showTab('download');
      if (innerWidth <= 980) setTimeout(() => $('.queue-card').scrollIntoView({ behavior: 'smooth', block: 'start' }), 120);
    } catch (e) {
      shake(); oops(e.message);
    } finally { $('#goBtn').disabled = false; }
  }

  /* ------------------------------------------------ job cards */
  const STEP_OF = { queued: 0, fetching: 0, downloading: 1, processing: 2, done: 3 };
  function addJob(data, req) {
    const el = document.createElement('div');
    el.className = 'job indet';
    el.innerHTML = `
      <div class="top"><img class="thumb" alt=""><div class="tt"><div class="title"></div>
        <div class="meta"><span class="badge"></span><span class="site"></span></div></div></div>
      <div class="steps"><span></span><span></span><span></span><span></span></div>
      <div class="pbar"><i></i><b>0%</b></div>
      <div class="stats"><span class="stage"></span><span class="sz"></span><span class="spd"></span><span class="eta"></span></div>
      <div class="err" hidden></div>
      <div class="actions"></div>
      <div class="tipnudge" hidden><span>${ic('coffee', 'sm loop')}Enjoying Grabby? Buy him a coffee.</span><button class="btn red pill sm hov" data-goto="support">${ic('heart', 'sm')}Tip</button></div>
      <svg class="check" viewBox="0 0 30 30"><circle cx="15" cy="15" r="15"/><path d="M8 15.5l4.5 4.5L22 10.5"/></svg>`;
    $('#queue').prepend(el);
    const j = { data, req, el, shown: 0 };
    state.jobs.set(data.id, j);
    renderJob(j);
    updateQueueHead();
    ensurePolling();
  }
  function renderJob(j) {
    const d = j.data, el = j.el;
    el.className = 'job ' + d.status + ((d.status === 'fetching' || d.status === 'queued' || (d.status === 'downloading' && !d.percent) || d.status === 'processing') ? ' indet' : '');
    const th = $('.thumb', el); if (d.thumbnail && th.getAttribute('src') !== d.thumbnail) th.src = d.thumbnail;
    $('.title', el).textContent = d.title || j.req.url;
    $('.badge', el).textContent = d.label || '';
    $('.site', el).textContent = d.site || '';
    const step = STEP_OF[d.status] ?? 0;
    $$('.steps span', el).forEach((s, i) => { s.className = i < step || d.status === 'done' ? 'on' : (i === step && !['error', 'cancelled'].includes(d.status) ? 'now' : ''); });
    const pct = d.status === 'done' ? 100 : (d.percent || 0);
    $('.pbar i', el).style.width = pct + '%';
    let stage = d.stage || '';
    if (d.status === 'downloading' && d.parts > 1) stage += ` (${d.part}/${d.parts})`;
    $('.stats .stage', el).textContent = stage;
    $('.stats .sz', el).textContent = d.status === 'done' ? fmtBytes(d.size) : (d.total ? `${fmtBytes(d.downloaded)} / ${fmtBytes(d.total)}` : (d.downloaded ? fmtBytes(d.downloaded) : ''));
    $('.stats .spd', el).innerHTML = d.speed ? ic('bolt', 'xs loop') + esc(fmtBytes(d.speed)) + '/s' : '';
    $('.stats .eta', el).innerHTML = d.eta != null && d.status === 'downloading' ? ic('timer', 'xs loop') + esc(fmtTime(d.eta)) + ' left' : (d.status === 'done' ? ic('timer', 'xs') + 'took ' + esc(fmtTime(d.elapsed)) : '');
    const err = $('.err', el); err.hidden = d.status !== 'error'; err.innerHTML = d.error ? ic('alert', 'xs loop') + `<span>${esc(d.error)}</span>` : '';
    const target = pct;
    cancelAnimationFrame(j.raf);
    const tick = () => {
      j.shown += (target - j.shown) * .18; if (Math.abs(target - j.shown) < .1) j.shown = target;
      $('.pbar b', el).textContent = (d.status === 'fetching' || d.status === 'queued') ? 'Starting…' : (d.status === 'processing' ? 'Processing…' : j.shown.toFixed(j.shown < 100 ? 1 : 0) + '%');
      if (j.shown !== target) j.raf = requestAnimationFrame(tick);
    };
    tick();
    const act = $('.actions', el), key = d.status;
    if (act.dataset.for === key) return;
    act.dataset.for = key; act.innerHTML = '';
    const mk = (icon, txt, cls, fn) => { const b = document.createElement('button'); b.className = 'btn pill sm hov ' + cls; b.innerHTML = ic(icon) + esc(txt); b.onclick = fn; act.appendChild(b); return b; };
    if (['queued', 'fetching', 'downloading', 'processing'].includes(key)) {
      mk('x', 'Cancel', 'ghost', async () => { try { await api('/api/cancel/' + d.id, {}); setMood('shrug', undefined, 2600); } catch (e) { toast(e.message); } });
    } else if (key === 'done') {
      $('.tipnudge', el).hidden = !(state.tips && state.tips.configured && !state.tips.is_owner);
      if (d.saved_to_library) {
        mk(d.kind === 'photo' ? 'image' : 'film', d.kind === 'photo' ? (d.count > 1 ? `View ${d.count} photos` : 'View') : 'Play', 'blue', () => playByName(d.name));
        mk('save', ANDROID ? 'Save to phone' : 'Save copy', 'ghost', () => saveFile(j));
      } else mk('save', 'Save file', 'blue', () => saveFile(j));
      if (!d.tool) mk('repeat', 'Again', 'ghost', () => startDownload(j.req));
      mk('trash', 'Remove', 'ghost', () => removeJob(j));
    } else {
      if (!d.tool) mk('repeat', 'Retry', 'blue', () => { removeJob(j); startDownload(j.req); });
      mk('trash', 'Remove', 'ghost', () => removeJob(j));
    }
  }
  function removeJob(j) {
    j.el.classList.add('leaving');
    setTimeout(() => { j.el.remove(); state.jobs.delete(j.data.id); updateQueueHead(); }, 340);
  }
  function saveFile(j) {
    const a = document.createElement('a');
    a.href = '/api/file/' + j.data.id; a.download = j.data.name || '';
    document.body.appendChild(a); a.click(); a.remove();
    if (ANDROID) toast('Saving to Downloads/Grabby');
  }
  function updateQueueHead() {
    $('#queueEmpty').hidden = state.jobs.size > 0;
    $('#clearDone').hidden = ![...state.jobs.values()].some(j => ['done', 'error', 'cancelled'].includes(j.data.status));
    const n = activeCount();
    $('#qCount').textContent = n || '';
    const ms = $('#mtopStatus'); ms.hidden = !n; ms.textContent = n ? `${n} downloading` : '';
    document.title = n ? `(${n}) Downloading… – Grabby` : 'Grabby – HD Video & MP3 Downloader';
  }
  $('#clearDone').onclick = () => [...state.jobs.values()].filter(j => ['done', 'error', 'cancelled'].includes(j.data.status)).forEach(removeJob);

  /* ------------------------------------------------ polling */
  let pollT = null;
  function ensurePolling() { if (!pollT) pollT = setInterval(poll, 700); }
  async function poll() {
    const active = [...state.jobs.values()].filter(j => !['done', 'error', 'cancelled'].includes(j.data.status));
    if (!active.length) { clearInterval(pollT); pollT = null; return; }
    await Promise.all(active.map(async j => {
      let d;
      try { d = await api('/api/status/' + j.data.id); } catch (e) { d = Object.assign({}, j.data, { status: 'error', stage: 'Failed', error: e.message }); }
      const prev = j.data.status;
      j.data = d;
      renderJob(j);
      if (prev !== d.status) onStatusChange(j);
    }));
    updateQueueHead();
    if (activeCount() && ['idle', 'watching', 'sleepy'].includes(mascot.dataset.mood)) setMood('working');
    if (activeCount() && mascot.dataset.mood === 'working' && Math.random() < .04) say(pick(LINES.working));
  }
  function onStatusChange(j) {
    const d = j.data;
    if (d.status === 'done') {
      state.errStreak = 0;
      if (d.saved_to_library) {
        if (ANDROID && !d.tool && $('#optAutosave').checked) { saveFile(j); toast('Saved! It\'s in My Videos and your phone\'s Downloads/Grabby'); }
        else toast(d.tool ? `Made “${d.name}”` : 'Saved to My Videos');
        loadLibrary();
      }
      else if ($('#optAutosave').checked) saveFile(j);
      if (!d.tool) count('grab/' + String(d.site || 'other').toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 30));
      if ($('#optSound').checked) chime(true);
      if ($('#optConfetti').checked) confetti(j.el);
      if (!ANDROID && $('#optNotify').checked && 'Notification' in window && Notification.permission === 'granted' && document.hidden) {
        try { new Notification('Grabby: download complete', { body: d.name || d.title, icon: '/static/icons/icon-192.png' }); } catch (e) {}
      }
      setMood(Math.random() < .7 ? 'excited' : 'proud', undefined, 3600);
      if (typeof recordDone === 'function') recordDone(j);
      if (d.tool) return;
      addHistory(j);
      setTimeout(() => { if (!activeCount()) visit(j.el, pick(LINES.dance), 'dance', 3200); }, 1600);
      maybeAskTip();
    } else if (d.status === 'error') {
      logErr(j.req && j.req.url, d.error);
      if ($('#optSound').checked) chime(false);
      oops((d.error || 'Download failed').slice(0, 200));
    } else if (d.status === 'cancelled') {
      setMood('shrug', undefined, 2600);
    }
  }

  /* ------------------------------------------------ sound */
  let actx;
  function chime(ok) {
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      (ok ? [659.25, 880, 1318.5] : [330, 247]).forEach((f, i) => {
        const o = actx.createOscillator(), g = actx.createGain(), t = actx.currentTime + i * .12;
        o.type = ok ? 'triangle' : 'sine'; o.frequency.value = f;
        g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(.18, t + .02); g.gain.exponentialRampToValueAtTime(.001, t + .35);
        o.connect(g).connect(actx.destination); o.start(t); o.stop(t + .4);
      });
    } catch (e) {}
  }

  /* ------------------------------------------------ confetti (cups, hearts and dots) */
  const cv = $('#confetti'), cx = cv.getContext('2d');
  let parts = [], confRaf = null;
  function confetti(fromEl) {
    cv.width = innerWidth * devicePixelRatio; cv.height = innerHeight * devicePixelRatio;
    const r = (fromEl || mascot).getBoundingClientRect();
    const ox = r.left + r.width / 2, oy = r.top + r.height / 2;
    const colors = ['#111111', '#444444', '#888888', '#bbbbbb'];
    for (let i = 0; i < 130; i++) {
      const a = Math.random() * Math.PI * 2, s = 4 + Math.random() * 9;
      parts.push({ x: ox, y: oy, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 6, r: 3 + Math.random() * 4, c: colors[i % colors.length], rot: Math.random() * 6, vr: (Math.random() - .5) * .4, life: 1, kind: i % 3 });
    }
    if (!confRaf) confRaf = requestAnimationFrame(drawConfetti);
  }
  function drawConfetti() {
    const dpr = devicePixelRatio;
    cx.clearRect(0, 0, cv.width, cv.height);
    parts.forEach(p => {
      p.vy += .25; p.vx *= .99; p.x += p.vx; p.y += p.vy; p.rot += p.vr; p.life -= .009;
      cx.save(); cx.globalAlpha = Math.max(0, p.life); cx.translate(p.x * dpr, p.y * dpr); cx.rotate(p.rot); cx.fillStyle = p.c;
      const R = p.r * dpr;
      if (p.kind === 0) cx.fillRect(-R, -R / 2, R * 2, R);
      else if (p.kind === 1) { cx.beginPath(); cx.arc(0, 0, R * .7, 0, 7); cx.fill(); }
      else { cx.beginPath(); cx.moveTo(0, R * .6); cx.bezierCurveTo(-R * 1.4, -R * .3, -R * .5, -R * 1.3, 0, -R * .4); cx.bezierCurveTo(R * .5, -R * 1.3, R * 1.4, -R * .3, 0, R * .6); cx.fill(); }
      cx.restore();
    });
    parts = parts.filter(p => p.life > 0 && p.y < innerHeight + 40);
    confRaf = parts.length ? requestAnimationFrame(drawConfetti) : (cx.clearRect(0, 0, cv.width, cv.height), null);
  }

  /* ------------------------------------------------ history + recent */
  function addHistory(j) {
    const d = j.data;
    state.history.unshift({ url: j.req.url, title: d.title, thumb: d.thumbnail, label: d.label, site: d.site, size: d.size, at: Date.now(), req: Object.assign({}, j.req, { filename: '' }) });
    state.history = state.history.slice(0, 60);
    store.set('history', state.history);
    updateHistCount(); renderRecent();
  }
  function updateHistCount() { $('#histCount').textContent = state.history.length || ''; }
  function renderRecent() {
    if (!$('#recentCard')) return;
    const list = state.history.slice(0, 4);
    $('#recentCard').hidden = !list.length;
    $('#recentList').innerHTML = '';
    list.forEach(h => {
      const row = document.createElement('div'); row.className = 'recent-item';
      row.innerHTML = '<img alt=""><span></span>';
      if (h.thumb) row.querySelector('img').src = h.thumb;
      row.querySelector('span').textContent = h.title || h.url;
      $('#recentList').appendChild(row);
    });
  }
  $('#histSearch').oninput = () => renderHistory();
  function renderHistory() {
    const box = $('#history'); box.innerHTML = '';
    $('#histEmpty').hidden = state.history.length > 0;
    const q = ($('#histSearch').value || '').toLowerCase();
    state.history.forEach((h, i) => {
      if (q && !((h.title || '') + ' ' + h.url + ' ' + (h.site || '')).toLowerCase().includes(q)) return;
      const row = document.createElement('div');
      row.className = 'hist'; row.style.animationDelay = Math.min(i * 40, 400) + 'ms';
      row.innerHTML = `<img alt=""><div class="h-body"><div class="h-title"></div><div class="h-meta"></div></div>
        <div class="h-act"><button class="hov" title="Download again">${ic('download')}</button><button class="hov" title="Copy link">${ic('link')}</button><button class="hov" title="Delete">${ic('trash')}</button></div>`;
      if (h.thumb) row.querySelector('img').src = h.thumb;
      row.querySelector('.h-title').textContent = h.title || h.url;
      row.querySelector('.h-meta').textContent = [h.label, h.site, fmtBytes(h.size), new Date(h.at).toLocaleString()].filter(Boolean).join(' · ');
      const [again, copy, del] = row.querySelectorAll('.h-act button');
      again.onclick = () => startDownload(h.req || { url: h.url });
      copy.onclick = async () => { try { await navigator.clipboard.writeText(h.url); toast('Link copied'); } catch (e) { toast(h.url); } };
      del.onclick = () => { state.history.splice(i, 1); store.set('history', state.history); updateHistCount(); renderHistory(); renderRecent(); };
      box.appendChild(row);
    });
  }
  $('#clearHist').onclick = () => { if (!state.history.length) return; if (confirm('Clear all history?')) { state.history = []; store.set('history', []); updateHistCount(); renderHistory(); renderRecent(); } };


  /* ------------------------------------------------ MY VIDEOS: library, player, delete
     Finished downloads are kept in a folder on this computer (or inside the phone app).
     Only the person on this computer can see, play or delete them. */
  const lib = { items: [], enabled: null, filter: 'all', folder: '', sort: store.get('libSort', 'new'), selecting: false, sel: new Set(), loaded: false, cur: -1, list: [], ffmpeg: false, lan: false };
  const resume = store.get('resume', {});      // name -> [seconds, duration]
  const libUrl = (name, dl) => '/api/library/file/' + encodeURIComponent(name) + (dl ? '?dl=1' : '');
  const ago = t => {
    const s = Date.now() / 1000 - t;
    if (s < 60) return 'just now'; if (s < 3600) return Math.floor(s / 60) + ' min ago';
    if (s < 86400) return Math.floor(s / 3600) + ' h ago'; if (s < 86400 * 7) return Math.floor(s / 86400) + ' d ago';
    return new Date(t * 1000).toLocaleDateString();
  };
  async function loadLibrary() {
    try {
      const r = await fetch('/api/library', { cache: 'no-store' }).then(r => r.json());
      lib.enabled = !!r.enabled; lib.items = r.items || []; lib.loaded = true;
      $$('.vault-entry').forEach(b => b.hidden = !lib.enabled);
      lib.where = r.folder; lib.canOpen = !!r.can_open; lib.ffmpeg = !!r.ffmpeg; lib.lan = !!r.lan;
      if (r.settings) $('#libAutoSort').value = r.settings.autosort;
      if (lib.folder && !lib.items.some(i => i.folder === lib.folder)) lib.folder = '';
    } catch (e) { lib.enabled = false; }
    $('#libCount').textContent = lib.items.length || '';
    if ($('#tab-library').classList.contains('on')) renderLibrary();
  }
  function libVisible() {
    const q = ($('#libSearch').value || '').toLowerCase();
    const out = lib.items.filter(i => (lib.filter === 'all' || i.kind === lib.filter) && (!lib.folder || i.folder === lib.folder) &&
      (!q || ((i.title || '') + ' ' + i.name + ' ' + (i.site || '') + ' ' + (i.folder || '')).toLowerCase().includes(q)));
    const by = { new: (a, b) => b.added - a.added, old: (a, b) => a.added - b.added, name: (a, b) => (a.title || '').localeCompare(b.title || ''),
      big: (a, b) => b.size - a.size, long: (a, b) => (b.duration || 0) - (a.duration || 0) }[lib.sort];
    return out.sort(by);
  }
  const libFolders = () => [...new Set(lib.items.map(i => i.folder).filter(Boolean))].sort();
  function renderFolders() {
    const box = $('#libFolders'); box.innerHTML = '';
    const fs = libFolders();
    if (!fs.length && !lib.items.length) return;
    const mk = (label, val, cls = '') => { const b = document.createElement('button'); b.className = cls + (lib.folder === val ? ' on' : ''); b.innerHTML = (val ? ic('folder', 'xs') : '') + esc(label); b.onclick = () => { lib.folder = val; renderLibrary(); }; box.appendChild(b); return b; };
    if (fs.length) { mk('All folders', ''); fs.forEach(f => mk(f + ` (${lib.items.filter(i => i.folder === f).length})`, f)); }
    const nb = document.createElement('button'); nb.className = 'new'; nb.innerHTML = ic('folder', 'xs') + 'New folder';
    nb.onclick = () => { if (!lib.selecting) { showSelect(true); toast('Pick videos, then tap Move'); } else askFolder([...lib.sel]); };
    box.appendChild(nb);
  }
  function renderContinue() {
    const list = lib.items.filter(i => { const r = resume[i.name]; return r && i.kind !== 'photo' && r[0] > 5 && r[0] < (r[1] || i.duration || 1e9) - 8; })
      .sort((a, b) => (resume[b.name][2] || 0) - (resume[a.name][2] || 0)).slice(0, 8);
    $('#libContinue').hidden = !list.length || lib.selecting;
    const row = $('#libContinueRow'); row.innerHTML = '';
    list.forEach(it => {
      const r = resume[it.name], pct = Math.min(100, r[0] * 100 / (r[1] || it.duration || r[0] * 2));
      const b = document.createElement('button'); b.className = 'lc-item hov';
      b.innerHTML = `<div class="lc-th">${it.kind === 'audio' ? ic('music', 'lg') : (it.thumbnail ? '<img alt="">' : '<video muted preload="metadata"></video>')}<div class="prog"><i style="width:${pct.toFixed(1)}%"></i></div></div><div class="lc-t"></div>`;
      const im = $('img', b), v = $('video', b);
      if (im) { im.src = it.thumbnail; im.onerror = () => im.remove(); }
      if (v) v.src = libUrl(it.name) + '#t=' + Math.floor(r[0]);
      $('.lc-t', b).textContent = `${it.title} · ${fmtTime(r[0])} in`;
      b.onclick = () => openPlayer(it.name);
      row.appendChild(b);
    });
  }
  function renderLibrary() {
    const grid = $('#libGrid'); grid.innerHTML = '';
    const on = lib.enabled;
    $('#libBar').hidden = !on || !lib.items.length;
    $('#libOpen').hidden = !lib.canOpen;
    if (!on) {
      $('#libEmpty').hidden = false; $('#libSum').textContent = '';
      $('#libEmptyMsg').innerHTML = 'Your videos are saved straight to this device&rsquo;s <b>Downloads</b> folder. My Videos is only available on the computer running Grabby.';
      $('#libWhere').textContent = ''; showSelect(false); return;
    }
    const total = lib.items.reduce((a, i) => a + i.size, 0);
    $('#libSum').textContent = lib.items.length ? `${lib.items.length} file${lib.items.length > 1 ? 's' : ''} · ${fmtBytes(total)}` : '';
    $('#libWhere').innerHTML = lib.where ? `Saved in <code id="libFolder" title="Open folder">${esc(lib.where)}</code>` : '';
    const fo = $('#libFolder'); if (fo && lib.canOpen) fo.onclick = () => openFolder();
    renderFolders(); renderContinue();
    $('#autoSortWrap').hidden = !lib.items.length;
    const list = libVisible();
    $('#libEmpty').hidden = list.length > 0;
    $('#libEmptyMsg').textContent = lib.items.length ? 'No videos match your search.' : 'No videos yet. Everything you download will be kept here, ready to play.';
    list.forEach((it, i) => {
      const card = document.createElement('div');
      card.className = 'lib-card' + (lib.sel.has(it.name) ? ' sel' : '');
      card.style.animationDelay = Math.min(i * 35, 420) + 'ms';
      card.dataset.name = it.name;
      const media = it.kind === 'audio'
        ? `<span class="lib-audio">${ic('music', 'xl')}</span>`
        : it.kind === 'photo' ? `<img class="photo" alt="" loading="lazy">`
        : (it.thumbnail ? `<img alt="" loading="lazy">` : `<video muted preload="metadata"></video>`);
      const kindIc = { audio: 'music', photo: 'image' }[it.kind] || 'film', kindTxt = { audio: 'Audio', photo: 'Photo' }[it.kind] || 'Video';
      const rp = resume[it.name], pct = rp && it.kind !== 'photo' ? Math.min(100, rp[0] * 100 / (rp[1] || it.duration || rp[0] * 2)) : 0;
      card.innerHTML = `<button class="lib-thumb" title="${it.kind === 'photo' ? 'View' : 'Play'}">${media}<span class="lib-kind">${ic(kindIc, 'xs')}${kindTxt}${it.subs && it.subs.length ? ' · CC' : ''}</span>${it.kind === 'photo' ? '' : '<span class="lib-play"></span>'}<span class="lib-dur" hidden></span><span class="lib-check"></span>${pct > 2 ? `<div class="prog"><i style="width:${pct.toFixed(1)}%"></i></div>` : ''}</button><span class="lib-more" title="More">⋯</span>
        <div class="lib-body"><div class="lib-title"></div><div class="lib-meta"></div>
        <div class="lib-act"><button class="hov p" title="Play">${ic('film', 'xs')}<span>Play</span></button><button class="hov s" title="${ANDROID ? 'Save to Downloads' : 'Save a copy'}">${ic('save', 'xs')}<span>Save</span></button><button class="hov del" title="Delete">${ic('trash', 'xs')}<span>Delete</span></button></div></div>`;
      $('.lib-title', card).textContent = it.title;
      $('.lib-meta', card).textContent = [it.site, fmtBytes(it.size), ago(it.added)].filter(Boolean).join(' · ');
      if (it.folder) $('.lib-meta', card).insertAdjacentHTML('afterbegin', `<span class="lib-tag">${ic('folder', 'xs')}${esc(it.folder)}</span>`);
      $('.lib-more', card).onclick = e => { e.stopPropagation(); cardMenu(it, e.currentTarget); };
      const img = $('img', card), vid = $('video', card), dur = $('.lib-dur', card);
      if (it.duration) { dur.textContent = fmtTime(it.duration); dur.hidden = false; }
      if (img && it.kind === 'photo') { img.src = libUrl(it.name); }
      else if (img) { img.src = it.thumbnail; img.onerror = () => { const v = document.createElement('video'); v.muted = true; v.preload = 'metadata'; v.src = libUrl(it.name) + '#t=1'; img.replaceWith(v); hookDur(v, dur); }; }
      if (vid) { vid.src = libUrl(it.name) + '#t=1'; hookDur(vid, dur); }
      if (!it.duration && it.kind !== 'photo' && (img || it.kind === 'audio')) { const probe = document.createElement(it.kind === 'audio' ? 'audio' : 'video'); probe.preload = 'metadata'; probe.src = libUrl(it.name); hookDur(probe, dur); }
      const open = () => lib.selecting ? toggleSel(it.name, card) : openPlayer(it.name);
      $('.lib-thumb', card).onclick = open;
      $('.lib-act .p', card).onclick = () => openPlayer(it.name);
      if (it.kind === 'photo') $('.lib-act .p span', card).textContent = 'View';
      $('.lib-act .s', card).onclick = () => saveLib(it);
      $('.lib-act .del', card).onclick = () => askDelete([it.name]);
      grid.appendChild(card);
    });
    grid.classList.toggle('selecting', lib.selecting);
    hydrateIcons(grid);
  }
  function hookDur(m, dur) { m.addEventListener('loadedmetadata', () => { if (isFinite(m.duration) && m.duration > 0) { dur.textContent = fmtTime(m.duration); dur.hidden = false; } }, { once: true }); }
  function saveLib(it) {
    const a = document.createElement('a'); a.href = libUrl(it.name, true); a.download = it.name;
    document.body.appendChild(a); a.click(); a.remove();
    toast(ANDROID ? 'Saving a copy to Downloads/Grabby' : 'Saving a copy…');
  }
  async function openFolder(name) {
    try { await api('/api/library/open', name ? { name } : {}); } catch (e) { toast(e.message); }
  }
  $('#libOpen').onclick = () => openFolder();
  $('#libSearch').addEventListener('input', renderLibrary);
  $('#libSort').value = lib.sort;
  $('#libSort').onchange = () => { lib.sort = $('#libSort').value; store.set('libSort', lib.sort); renderLibrary(); };
  $('#libAutoSort').onchange = async () => { try { await api('/api/library/settings', { autosort: $('#libAutoSort').value }); toast({ off: 'New downloads stay unsorted', site: 'New downloads go into a folder per site', type: 'New downloads go into Videos / Music / Photos' }[$('#libAutoSort').value]); } catch (e) { toast(e.message); } };
  $('#libSelMove').onclick = () => lib.sel.size ? askFolder([...lib.sel]) : toast('Pick some first');
  $('#libSelVault').onclick = () => lib.sel.size ? toVault([...lib.sel]) : toast('Pick some first');

  // the "⋯" menu on each card
  function cardMenu(it, anchor) {
    const m = $('#cardMenu'); m.innerHTML = '';
    const add = (icon, txt, fn, ok = true) => { const b = document.createElement('button'); b.innerHTML = ic(icon) + esc(txt); b.disabled = !ok; b.onclick = () => { m.hidden = true; fn(); }; m.appendChild(b); };
    add(it.kind === 'photo' ? 'image' : 'film', it.kind === 'photo' ? 'View' : 'Play', () => openPlayer(it.name));
    add('folder', 'Move to folder…', () => askFolder([it.name]));
    if (it.kind === 'video' && lib.ffmpeg) add('send', it.size > 24 * 1048576 ? 'Messenger size copy' : 'Already Messenger size', () => shrinkLib(it.name), it.size > 24 * 1048576);
    if (it.kind !== 'photo' && lib.ffmpeg) add('bell', 'Ringtone / GIF / clip…', () => { openPlayer(it.name); openCut(); });
    if (lib.lan) add('phone', 'Send to phone (QR)', () => sendToPhone(it.name));
    if (lib.canOpen) add('external', 'Show in folder', () => openFolder(it.name));
    add('save', ANDROID ? 'Save to phone' : 'Save a copy', () => saveLib(it));
    add('lock', 'Lock in vault', () => toVault([it.name]));
    add('trash', 'Delete', () => askDelete([it.name]));
    m.hidden = false; menuY = scrollY;
    const r = anchor.getBoundingClientRect(), mw = m.offsetWidth, mh = m.offsetHeight;
    m.style.left = Math.max(8, Math.min(innerWidth - mw - 8, r.right - mw)) + 'px';
    m.style.top = (r.bottom + mh + 8 > innerHeight ? Math.max(8, r.top - mh - 6) : r.bottom + 6) + 'px';
  }
  document.addEventListener('click', e => { if (!e.target.closest('#cardMenu, .lib-more')) $('#cardMenu').hidden = true; });
  let menuY = 0;
  addEventListener('scroll', () => { if (Math.abs(scrollY - menuY) > 60) $('#cardMenu').hidden = true; }, { passive: true });

  // folders
  let folderNames = [];
  function askFolder(names) {
    folderNames = names; $('#folderModal').hidden = false; $('#folderNew').value = '';
    const box = $('#folderPick'); box.innerHTML = '';
    const cur = names.length === 1 ? (lib.items.find(i => i.name === names[0]) || {}).folder || '' : null;
    const mk = (label, val) => { const b = document.createElement('button'); b.className = cur === val ? 'on' : ''; b.innerHTML = (val ? ic('folder', 'xs') : '') + esc(label); b.onclick = () => moveTo(val); box.appendChild(b); };
    mk('No folder', ''); libFolders().forEach(f => mk(f, f));
  }
  async function moveTo(folder) {
    try {
      await api('/api/library/folder', { names: folderNames, folder });
      $('#folderModal').hidden = true; toast(folder ? `Moved to ${folder}` : 'Removed from folder');
      if (lib.selecting) showSelect(false);
      await loadLibrary();
    } catch (e) { toast(e.message); }
  }
  $('#folderGo').onclick = () => { const v = $('#folderNew').value.trim(); if (!v) return toast('Type a folder name or pick one'); moveTo(v); };
  $('#folderNew').addEventListener('keydown', e => { if (e.key === 'Enter') $('#folderGo').click(); });
  $('#folderClose').onclick = () => { $('#folderModal').hidden = true; };

  // tools that make a new file in My Videos
  async function toolJob(path, body, line) {
    try {
      const job = await api(path, body);
      addJob(job, { url: '' });
      setMood('working', line); toast('Working on it. You can watch it in Downloads.');
      return job;
    } catch (e) { toast(e.message); }
  }
  const shrinkLib = name => toolJob('/api/library/shrink', { name }, 'Squeezing it for Messenger…').then(j => j && award('messenger'));
  async function sendToPhone(name) {
    try {
      const r = await api('/api/library/share', { name });
      $('#qrBox').innerHTML = r.svg; $('#qrUrl').textContent = r.url; $('#qrModal').hidden = false;
      setMood('excited', 'Point your phone camera at the code!', 3000); award('phone');
    } catch (e) { toast(e.message); }
  }
  $('#qrClose').onclick = () => { $('#qrModal').hidden = true; };
  $('#qrModal').addEventListener('click', e => { if (e.target.id === 'qrModal') $('#qrModal').hidden = true; });
  $$('#libFilter button').forEach(b => b.onclick = () => {
    $$('#libFilter button').forEach(x => x.classList.toggle('on', x === b)); lib.filter = b.dataset.f; renderLibrary();
  });

  // select several to delete at once
  function showSelect(on) {
    lib.selecting = on; if (!on) lib.sel.clear();
    $('#libSelBar').hidden = !on; $('#libSelect').hidden = on;
    $('#libGrid').classList.toggle('selecting', on);
    $$('.lib-card.sel').forEach(c => c.classList.remove('sel'));
    updSel();
  }
  function toggleSel(name, card) {
    lib.sel.has(name) ? lib.sel.delete(name) : lib.sel.add(name);
    card.classList.toggle('sel', lib.sel.has(name)); updSel();
  }
  function updSel() { $('#libSelN').textContent = `${lib.sel.size} selected`; $('#libSelDel').disabled = !lib.sel.size; }
  $('#libSelect').onclick = () => showSelect(true);
  $('#libSelDone').onclick = () => showSelect(false);
  $('#libSelAll').onclick = () => { const v = libVisible(); const all = v.every(i => lib.sel.has(i.name)); v.forEach(i => all ? lib.sel.delete(i.name) : lib.sel.add(i.name)); renderLibrary(); updSel(); };
  $('#libSelDel').onclick = () => lib.sel.size && askDelete([...lib.sel]);

  // delete with a friendly confirm (no browser pop-up)
  let cfResolve;
  function confirmBox(title, msg) {
    $('#cfTitle').textContent = title; $('#cfMsg').textContent = msg;
    $('#confirmModal').hidden = false; setMood('scared', false);
    return new Promise(r => { cfResolve = r; });
  }
  const cfClose = v => { $('#confirmModal').hidden = true; if (cfResolve) { cfResolve(v); cfResolve = null; } };
  $('#cfYes').onclick = () => cfClose(true);
  $('#cfNo').onclick = () => { cfClose(false); setMood('happy', 'Phew! Keeping it.', 1800); };
  $('#confirmModal').addEventListener('click', e => { if (e.target.id === 'confirmModal') cfClose(false); });
  async function askDelete(names) {
    const one = names.length === 1, it = one && lib.items.find(i => i.name === names[0]);
    const ok = await confirmBox(one ? 'Delete this video?' : `Delete ${names.length} videos?`,
      (one ? `“${(it && it.title) || names[0]}” ` : 'They ') + `will be removed from ${ANDROID ? 'the app' : 'your computer'}. This can't be undone.`);
    if (!ok) return;
    try {
      const r = await api('/api/library/delete', { names });
      const gone = new Set(r.removed || []);
      $$('.lib-card').forEach(c => { if (gone.has(c.dataset.name)) c.classList.add('gone'); });
      if (!$('#player').hidden && lib.list[lib.cur] && gone.has(lib.list[lib.cur].name)) closePlayer();
      setMood('sad', gone.size > 1 ? `Bye bye, ${gone.size} videos!` : 'Bye bye, video!', 2200);
      toast(gone.size ? `Deleted ${gone.size} file${gone.size > 1 ? 's' : ''}` : 'Nothing was deleted');
      lib.items = lib.items.filter(i => !gone.has(i.name)); gone.forEach(n => lib.sel.delete(n));
      $('#libCount').textContent = lib.items.length || '';
      setTimeout(() => { if (lib.selecting && !lib.sel.size) showSelect(false); renderLibrary(); }, 460);
    } catch (e) { toast(e.message); }
  }

  // the player: video or music (Grabby dances along to music)
  const plV = $('#plVideo');
  const plDancer = document.createElement('div');
  plDancer.className = 'mascot'; plDancer.dataset.mood = 'idle'; plDancer.innerHTML = mascot.innerHTML;
  $('.pl-disc').replaceWith(plDancer);
  function openPlayer(name) {
    lib.list = libVisible(); lib.cur = lib.list.findIndex(i => i.name === name);
    if (lib.cur < 0) { lib.list = lib.items; lib.cur = lib.items.findIndex(i => i.name === name); }
    if (lib.cur < 0) { toast('That file is gone.'); return; }
    $('#player').hidden = false; document.body.style.overflow = 'hidden';
    playCur();
    setMood('excited', pick(['Showtime!', 'Grab the popcorn!', 'Enjoy the show!']), 2200);
  }
  function playCur() {
    const it = lib.list[lib.cur]; if (!it) return;
    if (window.grabbyBgStop) window.grabbyBgStop(true);     // the player takes over from background music
    const audio = it.kind === 'audio';
    $('#plTitle').textContent = it.title;
    $('#plMeta').textContent = [it.site, it.label, fmtBytes(it.size), ago(it.added)].filter(Boolean).join(' · ');
    const photo = it.kind === 'photo';
    $('#plStage').classList.toggle('audio', audio); $('#plStage').classList.toggle('photo', photo); $('#plAudio').hidden = !audio;
    $$('track', plV).forEach(t => t.remove());
    $('#plImg').hidden = !photo;
    if (photo) { plV.pause(); plV.removeAttribute('src'); plV.load(); $('#plImg').src = it._src || libUrl(it.name); }
    else {
      $('#plImg').removeAttribute('src');
      (it.subs || []).forEach((s, i) => {
        const t = document.createElement('track'); t.kind = 'subtitles'; t.src = libUrl(s);
        const lang = s.split('.').slice(-2, -1)[0] || 'en'; t.srclang = lang.slice(0, 2); t.label = lang.toUpperCase(); if (i === 0) t.default = true;
        plV.appendChild(t);
      });
      plV.src = it._src || libUrl(it.name);
      const rp = resume[it.name];
      if (rp && rp[0] > 5 && rp[0] < (rp[1] || 1e9) - 8) plV.addEventListener('loadedmetadata', () => { plV.currentTime = rp[0]; toast(`Continuing from ${fmtTime(rp[0])}`); }, { once: true });
      plV.play().catch(() => {});
    }
    $('#plCut').hidden = true;
    $('#plCutBtn').hidden = photo || !lib.ffmpeg;
    $('#plShrink').hidden = it.kind !== 'video' || !lib.ffmpeg || it.size <= 24 * 1048576;
    $('#plPhone').hidden = !lib.lan;
    $('#mkGif').hidden = it.kind !== 'video';
    $('#plPrev').disabled = lib.cur <= 0; $('#plNext').disabled = lib.cur >= lib.list.length - 1;
    $('#plShow').hidden = !lib.canOpen;
    $('#plSaveTxt').textContent = ANDROID ? 'Save to phone' : 'Save copy';
    $('#plDel span') && ($('#plDel span').textContent = 'Delete');
    const inVault = !!it._vault;            // vault files: only play, take out or delete
    $('#player').classList.toggle('vaulted', inVault);
    if (inVault) {
      ['#plCutBtn', '#plShrink', '#plPhone', '#plMove', '#plShow', '#plVault'].forEach(x => $(x).hidden = true);
      $('#plSaveTxt').textContent = 'Take out of vault';
    } else $('#plVault').hidden = !lib.enabled;
    $('#plCut').hidden = true;
  }
  function closePlayer() {
    try { if (fsEl()) (document.exitFullscreen || document.webkitExitFullscreen).call(document); } catch (e) { }
    try { if (window.grabbyHandOver) window.grabbyHandOver(); } catch (e) { }
    $('#cutStart').value = ''; $('#cutEnd').value = '';
    plV.pause(); plV.removeAttribute('src'); plV.load();
    $('#player').hidden = true; $('#player').classList.remove('playing'); document.body.style.overflow = '';
  }
  plV.addEventListener('play', () => { $('#player').classList.add('playing'); plDancer.dataset.mood = 'dance'; });
  plV.addEventListener('pause', () => { $('#player').classList.remove('playing'); plDancer.dataset.mood = 'idle'; });
  let lastSave = 0;
  plV.addEventListener('timeupdate', () => {
    const it = lib.list[lib.cur]; if (!it || !plV.duration) return;
    if (Date.now() - lastSave < 2500) return; lastSave = Date.now();
    resume[it.name] = [Math.round(plV.currentTime), Math.round(plV.duration), Date.now()];
    const keys = Object.keys(resume); if (keys.length > 200) delete resume[keys[0]];
    store.set('resume', resume);
  });
  plV.addEventListener('ended', () => { const it = lib.list[lib.cur]; if (it) { delete resume[it.name]; store.set('resume', resume); } });
  plV.addEventListener('ended', () => { if ($('#plCut').hidden && lib.cur < lib.list.length - 1) { lib.cur++; playCur(); } else plDancer.dataset.mood = 'proud'; });
  plV.addEventListener('error', () => { if (plV.getAttribute('src')) toast("This file can't be played here. Try Save copy."); });
  $('#plClose').onclick = closePlayer;
  $('#plPrev').onclick = () => { if (lib.cur > 0) { lib.cur--; playCur(); } };
  $('#plNext').onclick = () => { if (lib.cur < lib.list.length - 1) { lib.cur++; playCur(); } };
  $('#plSave').onclick = () => { const it = lib.list[lib.cur]; it && it._vault ? vaultOut([it.name]) : saveLib(it); };
  $('#plShow').onclick = () => openFolder(lib.list[lib.cur].name);
  $('#plDel').onclick = () => { const it = lib.list[lib.cur]; it && it._vault ? vaultDelete([it.name]) : askDelete([it.name]); };
  $('#plVault').onclick = () => { const it = lib.list[lib.cur]; if (it) { closePlayer(); toVault([it.name]); } };

  // ---- full screen (works in the phone app too; wide videos turn the phone sideways)
  const fsEl = () => document.fullscreenElement || document.webkitFullscreenElement;
  function toggleFull() {
    try {
      if (fsEl()) { (document.exitFullscreen || document.webkitExitFullscreen).call(document); return; }
      const photo = $('#plStage').classList.contains('photo'), audio = $('#plStage').classList.contains('audio');
      const el = photo || audio ? $('#plStage') : plV;
      const go = el.requestFullscreen || el.webkitRequestFullscreen || el.webkitEnterFullscreen;
      if (!go) return toast("Full screen isn't available here");
      const p = go.call(el, { navigationUI: 'hide' });
      if (p && p.catch) p.catch(() => toast("Full screen isn't available here"));
    } catch (e) { toast("Full screen isn't available here"); }
  }
  function onFullChange() {
    const on = !!fsEl();
    $('#player').classList.toggle('full', on);
    const wide = plV.videoWidth && plV.videoWidth > plV.videoHeight;
    try { if (ANDROID && window.VidGrabAndroid.setLandscape) window.VidGrabAndroid.setLandscape(on && !!wide); } catch (e) { }
    try { if (!ANDROID && on && wide && screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(() => {}); } catch (e) { }
  }
  document.addEventListener('fullscreenchange', onFullChange);
  document.addEventListener('webkitfullscreenchange', onFullChange);
  $('#plFull').onclick = toggleFull;
  plV.addEventListener('dblclick', e => { e.preventDefault(); toggleFull(); });
  $('#plImg').addEventListener('dblclick', toggleFull);
  $('#plShrink').onclick = () => shrinkLib(lib.list[lib.cur].name);
  $('#plPhone').onclick = () => sendToPhone(lib.list[lib.cur].name);
  $('#plMove').onclick = () => askFolder([lib.list[lib.cur].name]);
  // cut panel: ringtone / GIF / clip
  const parseT = v => { v = String(v || '').trim(); if (!v) return null; const p = v.split(':').map(Number); if (p.some(isNaN)) return null; return p.reduce((a, b) => a * 60 + b, 0); };
  function openCut() {
    $('#plCut').hidden = false;
    const t = Math.floor(plV.currentTime || 0);
    if (!$('#cutStart').value) $('#cutStart').value = fmtTime(t);
    if (!$('#cutEnd').value) $('#cutEnd').value = fmtTime(Math.min(t + 30, plV.duration || t + 30));
    updCut();
  }
  const updCut = () => { const a = parseT($('#cutStart').value), b = parseT($('#cutEnd').value); $('#cutLen').textContent = a != null && b != null && b > a ? `${Math.round(b - a)} s` : ''; };
  $('#plCutBtn').onclick = () => $('#plCut').hidden ? openCut() : ($('#plCut').hidden = true);
  $('#cutSetStart').onclick = () => { $('#cutStart').value = fmtTime(plV.currentTime); updCut(); };
  $('#cutSetEnd').onclick = () => { $('#cutEnd').value = fmtTime(plV.currentTime); updCut(); };
  ['#cutStart', '#cutEnd'].forEach(s => $(s).addEventListener('input', updCut));
  const make = what => {
    const a = parseT($('#cutStart').value) || 0, b = parseT($('#cutEnd').value) || 0;
    plV.pause();
    toolJob('/api/library/make', { name: lib.list[lib.cur].name, what, start: a, end: b },
      { ringtone: 'Making your ringtone…', gif: 'Making a GIF…', clip: 'Cutting your clip…' }[what]).then(j => j && award('maker'));
  };
  $('#mkRing').onclick = () => make('ringtone'); $('#mkGif').onclick = () => make('gif'); $('#mkClip').onclick = () => make('clip');
  $('#player').addEventListener('click', e => { if (e.target.id === 'player') closePlayer(); });
  document.addEventListener('keydown', e => {
    if (!$('#confirmModal').hidden && e.key === 'Escape') { cfClose(false); return; }
    if ($('#player').hidden || e.target.matches('input, textarea')) return;
    if (e.key === 'Escape') { if (!fsEl()) closePlayer(); }
    else if (e.key === 'f' || e.key === 'F') toggleFull();
    else if (e.key === 'ArrowRight' && e.shiftKey) $('#plNext').click();
    else if (e.key === 'ArrowLeft' && e.shiftKey) $('#plPrev').click();
  });
  function playByName(name) { if (!lib.loaded) return loadLibrary().then(() => openPlayer(name)); openPlayer(name); }

  // Android Back: close the top-most thing first, then step back through pages. false = leave the app.
  window.grabbyBack = () => {
    try {
      if (fsEl()) { (document.exitFullscreen || document.webkitExitFullscreen).call(document); return true; }
      if (!$('#confirmModal').hidden) { cfClose(false); return true; }
      if (!$('#cardMenu').hidden) { $('#cardMenu').hidden = true; return true; }
      if (!$('#clipPop').hidden) { $('#clipPop').hidden = true; return true; }
      if (!$('#player').hidden) { closePlayer(); return true; }
      const modal = [...document.querySelectorAll('.modal')].reverse().find(m => !m.hidden && m.id !== 'player');
      if (modal) {
        modal.dispatchEvent(new MouseEvent('click', { bubbles: true }));     // same as tapping outside it
        if (!modal.hidden) { const x = modal.querySelector('[data-close], .modal-x, .close, button[id$="Close"], button[id$="Cancel"]'); x ? x.click() : (modal.hidden = true); }
        return true;
      }
      if (curTab === 'library' && lib.selecting) { showSelect(false); return true; }
      if (curTab === 'vault' && !$('#vPwForm').hidden) { $('#vPwForm').hidden = true; return true; }
      while (tabTrail.length && tabTrail[tabTrail.length - 1] === curTab) tabTrail.pop();
      if (tabTrail.length) { goingBack = true; showTab(tabTrail.pop()); goingBack = false; scrollTo(0, 0); return true; }
      if (curTab !== 'download') { goingBack = true; showTab('download'); goingBack = false; scrollTo(0, 0); return true; }
    } catch (e) { goingBack = false; }
    return false;
  };

  /* ------------------------------------------------ BACKGROUND MUSIC
     Music keeps playing when you close the player, switch pages or leave the app, until you press Stop.
     On the phone there's also a media notification and lock-screen controls (MediaService.java). */
  const bgA = new Audio(); bgA.preload = 'auto';
  const np = { list: [], idx: -1 };
  const npItem = () => np.list[np.idx];
  const isMusic = it => it && it.kind === 'audio' && !it._vault;     // vault music stays inside the vault
  function bgLoad(idx, at, play) {
    np.idx = idx; const it = npItem(); if (!it) return bgStop();
    bgA.src = libUrl(it.name);
    if (at) bgA.addEventListener('loadedmetadata', () => { try { bgA.currentTime = at; } catch (e) { } }, { once: true });
    if (play) bgA.play().catch(() => {});
    $('#nowBar').hidden = false; document.body.classList.add('has-now');
    renderNow(); mediaNotify();
  }
  function bgStop(quiet) {
    if (np.idx < 0 && !bgA.src) return;
    bgA.pause(); bgA.removeAttribute('src'); bgA.load();
    np.idx = -1; np.list = [];
    $('#nowBar').hidden = true; document.body.classList.remove('has-now');
    if (!quiet) mediaNotify();
  }
  window.grabbyBgStop = bgStop;
  // the player was showing music: carry on in the background from the same spot
  window.grabbyHandOver = () => {
    const it = lib.list[lib.cur];
    if (!isMusic(it) || plV.paused || plV.ended || !plV.currentSrc) return;
    np.list = lib.list.filter(isMusic);
    bgLoad(np.list.indexOf(it), plV.currentTime, true);
    toast('Still playing. Press ■ to stop');
  };
  function renderNow() {
    const it = npItem(); if (!it) return;
    $('#nbTitle').textContent = it.title;
    $('#nbSub').textContent = [it.site, `${np.idx + 1} of ${np.list.length}`].filter(Boolean).join(' · ');
    $('#nowBar').classList.toggle('on', !bgA.paused);
    $('#nbPrev').disabled = np.idx <= 0 && !(bgA.currentTime > 3);
    $('#nbNext').disabled = np.idx >= np.list.length - 1;
  }
  bgA.addEventListener('play', () => { renderNow(); mediaNotify(); });
  bgA.addEventListener('pause', () => { renderNow(); mediaNotify(); });
  bgA.addEventListener('seeked', mediaNotify);
  bgA.addEventListener('loadedmetadata', () => { renderNow(); mediaNotify(); });
  bgA.addEventListener('timeupdate', () => { const d = bgA.duration; $('#nbBar').style.width = d ? (bgA.currentTime / d * 100).toFixed(1) + '%' : '0'; });
  bgA.addEventListener('ended', () => { if (np.idx < np.list.length - 1) bgLoad(np.idx + 1, 0, true); else { bgA.currentTime = 0; renderNow(); mediaNotify(); } });
  bgA.addEventListener('error', () => { if (bgA.getAttribute('src')) { toast("Couldn't play that song"); if (np.idx < np.list.length - 1) bgLoad(np.idx + 1, 0, true); else bgStop(); } });
  $('#nbPlay').onclick = () => { bgA.paused ? bgA.play().catch(() => {}) : bgA.pause(); };
  $('#nbNext').onclick = () => { if (np.idx < np.list.length - 1) bgLoad(np.idx + 1, 0, true); };
  $('#nbPrev').onclick = () => { if (bgA.currentTime > 3 || np.idx <= 0) bgA.currentTime = 0; else bgLoad(np.idx - 1, 0, true); };
  $('#nbStop').onclick = () => { bgStop(); toast('Music stopped'); };
  $('#nbOpen').onclick = () => {                    // back to the full player, same song, same spot
    const it = npItem(); if (!it) return;
    const at = bgA.currentTime, wasPlaying = !bgA.paused;
    lib.list = np.list.slice(); lib.cur = np.idx;
    bgStop(true);
    $('#player').hidden = false; document.body.style.overflow = 'hidden';
    playCur();
    plV.addEventListener('loadedmetadata', () => { try { plV.currentTime = at; } catch (e) { } if (!wasPlaying) plV.pause(); }, { once: true });
  };
  // leaving the app while the player shows music: hand it to the background player (keeps going)
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && !$('#player').hidden && isMusic(lib.list[lib.cur]) && !plV.paused) closePlayer();
  });
  // which music is playing right now (the player or the background bar)
  function activeMusic() {
    const it = lib.list[lib.cur];
    if (!$('#player').hidden && it && it.kind === 'audio' && plV.currentSrc)
      return { el: plV, it, prev: lib.cur > 0, next: lib.cur < lib.list.length - 1 };
    if (np.idx >= 0 && bgA.getAttribute('src')) return { el: bgA, it: npItem(), prev: np.idx > 0, next: np.idx < np.list.length - 1 };
    return null;
  }
  // phone: media notification + lock-screen controls
  let lastMedia = '';
  function mediaNotify() {
    const B = window.VidGrabAndroid; if (!ANDROID || !B || !B.media) return;
    const m = activeMusic();
    try {
      if (!m) { if (lastMedia) { B.mediaStop(); lastMedia = ''; } return; }
      const key = [m.it.title, m.el.paused, Math.round(m.el.currentTime), m.prev, m.next].join('|');
      if (key === lastMedia) return; lastMedia = key;
      B.media(m.it.title || 'Music', m.it.site || 'Grabby', !m.el.paused, Math.round((m.el.currentTime || 0) * 1000), Math.round((isFinite(m.el.duration) ? m.el.duration : 0) * 1000), m.prev, m.next);
    } catch (e) { }
  }
  ['play', 'pause', 'seeked', 'loadedmetadata', 'emptied'].forEach(ev => plV.addEventListener(ev, () => setTimeout(mediaNotify, 50)));
  // buttons on the notification / lock screen / headphones
  window.grabbyMedia = cmd => {
    const m = activeMusic(); if (!m) return;
    const inPlayer = m.el === plV;
    if (cmd === 'play') m.el.play().catch(() => {});
    else if (cmd === 'pause') m.el.pause();
    else if (cmd === 'toggle') m.el.paused ? m.el.play().catch(() => {}) : m.el.pause();
    else if (cmd === 'next') inPlayer ? (m.next && $('#plNext').click()) : $('#nbNext').click();
    else if (cmd === 'prev') inPlayer ? (m.prev && $('#plPrev').click()) : $('#nbPrev').click();
    else if (cmd === 'stop') { if (inPlayer) { plV.pause(); closePlayer(); } bgStop(); }
    else if (cmd.startsWith('seek:')) { m.el.currentTime = (+cmd.slice(5) || 0) / 1000; }
    setTimeout(mediaNotify, 80);
  };

  /* ------------------------------------------------ VAULT
     Password-locked, encrypted videos / music / pictures. They only show here, after unlocking. */
  const vault = { token: '', setup: false, items: [], filter: 'all', pending: null };
  const vUrl = id => '/api/vault/file/' + id + '?vt=' + encodeURIComponent(vault.token);
  async function vApi(path, body) {
    const r = await fetch(path, { method: body ? 'POST' : 'GET', cache: 'no-store',
      headers: Object.assign({ 'X-Vault': vault.token }, body ? { 'Content-Type': 'application/json' } : {}),
      body: body ? JSON.stringify(body) : undefined });
    let d = {}; try { d = await r.json(); } catch (e) { }
    if (r.status === 403 && vault.token) { vault.token = ''; renderVaultGate(); }
    if (!r.ok || d.error) throw new Error(d.error || `Server error (${r.status})`);
    return d;
  }
  async function loadVault() {
    try {
      const d = await vApi('/api/vault');
      vault.setup = d.setup; vault.items = d.items || [];
      if (!d.unlocked) vault.token = '';
    } catch (e) { vault.token = ''; }
    renderVaultGate();
    if (vault.token) renderVault();
  }
  function renderVaultGate() {
    const open = !!vault.token;
    $('#vGate').hidden = open; $('#vOpen').hidden = !open;
    $('#vSum').textContent = open ? `${vault.items.length} locked` : '';
    if (open) return;
    $('#vGateTitle').textContent = vault.setup ? 'Vault is locked' : 'Make your private vault';
    $('#vGoTxt').textContent = vault.setup ? 'Unlock' : 'Create vault';
    $('#vPw').placeholder = vault.setup ? 'Password' : 'Choose a password (4+ characters)';
    $('#vPw2').hidden = vault.setup; $('#vWarn').hidden = vault.setup; $('#vForgot').hidden = !vault.setup;
  }
  function vaultVisible() { return vault.items.filter(i => vault.filter === 'all' || i.kind === vault.filter); }
  function asPlayerItems(list) {
    return list.map(i => ({ name: i.id, title: i.title, kind: i.kind, size: i.size, added: i.added, site: i.site,
      label: 'Locked in vault', duration: i.duration, subs: [], _src: vUrl(i.id), _vault: true }));
  }
  function renderVault() {
    const g = $('#vGrid'); g.innerHTML = '';
    $('#vSum').textContent = `${vault.items.length} locked`;
    const list = vaultVisible();
    $('#vEmpty').hidden = list.length > 0;
    list.forEach((it, i) => {
      const card = document.createElement('div');
      card.className = 'lib-card vault-card'; card.style.animationDelay = Math.min(i * 35, 420) + 'ms';
      const media = it.kind === 'audio' ? `<span class="lib-audio">${ic('music', 'xl')}</span>`
        : it.kind === 'photo' ? `<img class="photo" alt="" loading="lazy">` : `<video muted preload="metadata" playsinline></video>`;
      const kindIc = { audio: 'music', photo: 'image' }[it.kind] || 'film', kindTxt = { audio: 'Audio', photo: 'Photo' }[it.kind] || 'Video';
      card.innerHTML = `<button class="lib-thumb" title="Open">${media}<span class="lib-kind">${ic('lock', 'xs')}${kindTxt}</span>${it.kind === 'photo' ? '' : '<span class="lib-play"></span>'}<span class="lib-dur" hidden></span></button>
        <div class="lib-body"><div class="lib-title"></div><div class="lib-meta"></div>
        <div class="lib-act"><button class="hov p">${ic(kindIc, 'xs')}<span>${it.kind === 'photo' ? 'View' : 'Play'}</span></button><button class="hov s" title="Back to My Videos">${ic('upload', 'xs')}<span>Take out</span></button><button class="hov del">${ic('trash', 'xs')}<span>Delete</span></button></div></div>`;
      $('.lib-title', card).textContent = it.title;
      $('.lib-meta', card).textContent = [it.site, fmtBytes(it.size), ago(it.added)].filter(Boolean).join(' · ');
      const img = $('img', card), vid = $('video', card), dur = $('.lib-dur', card);
      if (it.duration) { dur.textContent = fmtTime(it.duration); dur.hidden = false; }
      if (img) img.src = vUrl(it.id);
      if (vid) { vid.src = vUrl(it.id) + '#t=1'; hookDur(vid, dur); }
      const open = () => openVaultPlayer(it.id);
      $('.lib-thumb', card).onclick = open; $('.p', card).onclick = open;
      $('.s', card).onclick = () => vaultOut([it.id]);
      $('.del', card).onclick = () => vaultDelete([it.id]);
      g.appendChild(card);
    });
  }
  function openVaultPlayer(id) {
    lib.list = asPlayerItems(vaultVisible()); lib.cur = lib.list.findIndex(i => i.name === id);
    if (lib.cur < 0) return;
    $('#player').hidden = false; document.body.style.overflow = 'hidden';
    playCur();
  }
  $$('#vFilter button').forEach(b => b.onclick = () => { $$('#vFilter button').forEach(x => x.classList.toggle('on', x === b)); vault.filter = b.dataset.f; renderVault(); });
  $('#vForm').onsubmit = async e => {
    e.preventDefault();
    const pw = $('#vPw').value;
    try {
      if (!vault.setup) {
        if (pw.length < 4) return toast('Use at least 4 characters');
        if (pw !== $('#vPw2').value) return toast("The two passwords don't match");
        vault.token = (await vApi('/api/vault/setup', { password: pw })).token;
        vault.setup = true; toast('Vault ready! Add something to lock away.'); setMood('proud', 'Your secrets are safe with me!', 2600);
      } else {
        vault.token = (await vApi('/api/vault/unlock', { password: pw })).token;
        toast('Unlocked');
      }
      $('#vPw').value = ''; $('#vPw2').value = '';
      await loadVault();
      startAutoLock();
      if (vault.pending) { const names = vault.pending; vault.pending = null; toVault(names); }
    } catch (err) { toast(err.message); $('#vPw').select(); setMood('scared', false); setTimeout(() => setMood(baseMood(), false), 1500); }
  };
  function lockVault(quiet) {
    if (!vault.token) return;
    fetch('/api/vault/lock', { method: 'POST', headers: { 'X-Vault': vault.token, 'Content-Type': 'application/json' }, body: '{}' }).catch(() => {});
    vault.token = ''; vault.items = [];
    if (!$('#player').hidden && lib.list[lib.cur] && lib.list[lib.cur]._vault) closePlayer();
    $('#vGrid').innerHTML = ''; renderVaultGate();
    if (!quiet) toast('Vault locked');
  }
  $('#vLock').onclick = () => lockVault();

  // ---- auto-lock: after a chosen time without use, or as soon as you leave the Vault
  const vAuto = () => +store.get('vaultAuto', 300);
  $('#vAuto').value = String(vAuto());
  let vIdleAt = 0, vTick = 0;
  const vActivity = () => { if (vault.token) vIdleAt = Date.now(); };
  ['pointerdown', 'keydown', 'wheel', 'touchstart', 'scroll'].forEach(ev => addEventListener(ev, vActivity, { passive: true, capture: true }));
  plV.addEventListener('timeupdate', () => { const it = lib.list[lib.cur]; if (!plV.paused && it && it._vault) vActivity(); });
  function startAutoLock() {
    clearInterval(vTick); vIdleAt = Date.now();
    const secs = vAuto();
    vApi('/api/vault/autolock', { seconds: secs || 600 }).catch(() => { });
    const tick = () => {
      if (!vault.token) { clearInterval(vTick); $('#vCount').textContent = ''; return; }
      const s = vAuto();
      if (!s) { $('#vCount').textContent = 'Locks when you leave'; return; }
      const left = Math.ceil((vIdleAt + s * 1000 - Date.now()) / 1000);
      if (left <= 0) { lockVault(true); toast('Vault locked automatically'); return; }
      $('#vCount').textContent = left <= 60 ? `Locks in ${left}s` : `Locks in ${Math.ceil(left / 60)} min`;
    };
    tick(); vTick = setInterval(tick, 1000);
  }
  $('#vAuto').onchange = () => {
    store.set('vaultAuto', +$('#vAuto').value);
    if (vault.token) startAutoLock();
    toast('Auto-lock saved');
  };
  window.grabbyTabChanged = name => {
    if (name === 'vault') { vault.fromLib = false; return; }
    if (!vault.token || vAuto() !== 0) return;
    if (name === 'library' && vault.fromLib) return;      // picking files to lock away
    lockVault(true); toast('Vault locked');
  };
  let vHideT;
  document.addEventListener('visibilitychange', () => {        // leaving the app locks the vault
    clearTimeout(vHideT);
    if (document.hidden && vault.token && !vault.picking) vHideT = setTimeout(() => lockVault(true), ANDROID ? 1500 : 60000);
  });
  window.grabbyPaused = () => { if (vault.token && !vault.picking) lockVault(true); };
  $('label[for=vFiles]').addEventListener('click', () => { vault.picking = true; });
  addEventListener('focus', () => setTimeout(() => { vault.picking = false; }, 1500));
  function vBusy(txt) { $('#vBusy').hidden = !txt; if (txt) $('#vBusyTxt').textContent = txt; }
  async function toVault(names) {
    if (!names.length) return;
    if (!vault.token) {
      vault.pending = names; showTab('vault');
      return toast(vault.setup ? 'Unlock the vault to lock these away' : 'Make a vault password first');
    }
    showTab('vault'); vBusy(`Locking ${names.length} file${names.length > 1 ? 's' : ''}…`);
    try {
      const titles = new Set(lib.items.filter(i => names.includes(i.name)).map(i => i.title));
      const r = await vApi('/api/vault/add', { names });
      // forget them everywhere else in the app too
      state.history = state.history.filter(h => !titles.has(h.title)); store.set('history', state.history); updateHistCount(); renderRecent();
      r.moved.forEach(n => delete resume[n]); store.set('resume', resume);
      if (lib.selecting) showSelect(false);
      await loadLibrary(); await loadVault();
      toast(`Locked ${r.moved.length} in the vault`); setMood('proud', 'Locked away! 🔒', 2200);
    } catch (e) { toast(e.message); }
    vBusy('');
  }
  $('#vFromLib').onclick = () => { vault.fromLib = true; showTab('library'); showSelect(true); toast('Pick what to lock, then tap Vault'); };
  $('#vFiles').onchange = async () => {
    vault.picking = false;
    const files = [...$('#vFiles').files]; $('#vFiles').value = '';
    if (!files.length) return;
    const fd = new FormData(); files.forEach(f => fd.append('files', f));
    vBusy(`Locking ${files.length} file${files.length > 1 ? 's' : ''}…`);
    try {
      const r = await fetch('/api/vault/upload', { method: 'POST', headers: { 'X-Vault': vault.token }, body: fd });
      const d = await r.json().catch(() => ({}));
      if (!r.ok || d.error) throw new Error(d.error || 'Upload failed');
      await loadVault(); toast(`Locked ${d.added.length} in the vault. You can delete the originals now.`);
    } catch (e) { toast(e.message); }
    vBusy('');
  };
  async function vaultOut(ids) {
    vBusy('Taking out…');
    try {
      const r = await vApi('/api/vault/out', { ids });
      if (!$('#player').hidden) closePlayer();
      await loadVault(); loadLibrary(); toast(`Moved ${r.names.length} back to My Videos`);
    } catch (e) { toast(e.message); }
    vBusy('');
  }
  async function vaultDelete(ids) {
    if (!await confirmBox('Delete from the vault?', 'This removes it for good. It can\'t be undone.')) return;
    try {
      await vApi('/api/vault/delete', { ids });
      if (!$('#player').hidden) closePlayer();
      await loadVault(); toast('Deleted');
    } catch (e) { toast(e.message); }
  }
  $('#vChange').onclick = () => { $('#vPwForm').hidden = !$('#vPwForm').hidden; if (!$('#vPwForm').hidden) $('#vOld').focus(); };
  $('#vPwCancel').onclick = () => { $('#vPwForm').hidden = true; $('#vPwForm').reset(); };
  $('#vPwForm').onsubmit = async e => {
    e.preventDefault();
    const nw = $('#vNew').value;
    if (nw.length < 4) return toast('Use at least 4 characters');
    if (nw !== $('#vNew2').value) return toast("The new passwords don't match");
    try { await vApi('/api/vault/password', { old: $('#vOld').value, new: nw }); toast('Password changed'); $('#vPwForm').reset(); $('#vPwForm').hidden = true; }
    catch (err) { toast(err.message); }
  };
  $('#vForgot').onclick = async () => {
    if (!await confirmBox('Forgot the password?', "Nobody can open the vault without it. The only way out is to empty the vault: everything in it is deleted for good, and you can make a new password.")) return;
    if (prompt('Type DELETE to empty the vault') !== 'DELETE') return toast('Nothing was deleted');
    try { await api('/api/vault/reset', { confirm: 'DELETE' }); vault.token = ''; await loadVault(); toast('Vault emptied. Make a new password.'); } catch (e) { toast(e.message); }
  };

  /* ------------------------------------------------ MANY LINKS + PLAYLISTS
     Paste many links, or a playlist / channel link, then pick what to grab. */
  const PLAYLIST_RE = /[?&]list=|\/playlist|\/sets\/|\/showcase\/|\/album\/|\/channel\/|\/c\/|\/user\/|\/@[^/?#]+\/?(videos|shorts|streams)?\/?(\?|$)|tiktok\.com\/@[^/?#]+\/?(\?|$)/i;
  const isPlaylistUrl = u => PLAYLIST_RE.test(u) && !/\/video\/\d|\/status\/|\/reel\/|\/p\/|\/watch\?v=[^&]+$/.test(u);
  const findUrls = t => [...new Set((String(t).match(/https?:\/\/[^\s<>"']+/g) || []).map(u => u.replace(/[),.;!?]+$/, '')))];
  const batch = { items: [], kind: '' };
  let plSeq = 0;
  async function loadPlaylist(url) {
    const seq = ++plSeq;
    showBatch('Looking for videos…', '', []); $('#batchSkel').hidden = false;
    try {
      const r = await api('/api/playlist', { url });
      if (seq !== plSeq) return;
      if (!r.playlist) { $('#batchCard').hidden = true; return; }
      showBatch(r.title, [r.site, r.uploader, `${r.items.length} videos`].filter(Boolean).join(' · '), r.items, 'playlist');
      flash('excited', 2600, `Whoa, ${r.items.length} videos! Pick the ones you want.`);
    } catch (e) { if (seq === plSeq) { $('#batchCard').hidden = true; oops(e.message); } }
  }
  function showBatch(title, sub, items, kind) {
    batch.items = items.map(x => Object.assign({ on: true }, x)); batch.kind = kind || '';
    $('#batchTitle').textContent = title; $('#batchSub').textContent = sub;
    $('#batchCard').hidden = false; $('#batchSkel').hidden = true;
    renderBatch();
  }
  function renderBatch() {
    const box = $('#batchList'); box.innerHTML = '';
    box.hidden = !batch.items.length;
    batch.items.forEach((it, i) => {
      const r = document.createElement('label');
      r.className = 'b-row' + (it.on ? '' : ' off'); r.style.animationDelay = Math.min(i * 25, 400) + 'ms';
      r.innerHTML = `<input type="checkbox" ${it.on ? 'checked' : ''}>${it.thumbnail ? '<img alt="" loading="lazy">' : ''}<span class="bt"></span><span class="bd"></span>`;
      if (it.thumbnail) $('img', r).src = it.thumbnail;
      $('.bt', r).textContent = it.title || it.url;
      $('.bd', r).textContent = it.duration ? fmtTime(it.duration) : (it.title ? '' : (() => { try { return new URL(it.url).hostname.replace('www.', ''); } catch (e) { return ''; } })());
      $('input', r).onchange = e => { it.on = e.target.checked; r.classList.toggle('off', !it.on); updBatch(); };
      box.appendChild(r);
    });
    updBatch();
  }
  function updBatch() {
    const n = batch.items.filter(i => i.on).length;
    $('#batchN').textContent = `${n} of ${batch.items.length} picked`;
    $('#batchAll').checked = n === batch.items.length;
    const what = state.kind === 'audio' ? 'MP3' : state.kind === 'photo' ? 'photos' : 'videos';
    $('#goTxt').textContent = !$('#batchCard').hidden && batch.items.length ? `Download ${n} ${n === 1 ? what.replace(/s$/, '') : what}` : $('#goTxt').textContent;
    if ($('#batchCard').hidden || !batch.items.length) updateGoText();
  }
  $('#batchAll').onchange = e => { batch.items.forEach(i => i.on = e.target.checked); renderBatch(); };
  $('#batchClose').onclick = () => { $('#batchCard').hidden = true; batch.items = []; updateGoText(); };
  ['#kindSeg button', '#qualityChips', '#abrChips'].forEach(s => $$(s).forEach(b => b.addEventListener('click', () => setTimeout(() => { if (!$('#batchCard').hidden) updBatch(); }, 0))));
  const batchActive = () => !$('#batchCard').hidden && batch.items.some(i => i.on);
  async function startBatch() {
    const picked = batch.items.filter(i => i.on);
    if (!picked.length) return toast('Pick at least one');
    $('#goBtn').disabled = true;
    setMood('working', `On it! ${picked.length} in line. I grab 3 at a time.`);
    for (const it of picked) {
      try {
        const body = Object.assign({ url: it.url, kind: state.kind, quality: state.quality, audio: state.audio, abr: state.abr, title: it.title !== it.url ? it.title : undefined, thumbnail: it.thumbnail }, optBody());
        const job = await api('/api/download', body);
        addJob(job, body);
      } catch (e) { toast(e.message); }
    }
    $('#goBtn').disabled = false;
    if (picked.length >= 5) award('batch');
    $('#batchCard').hidden = true; batch.items = []; updateGoText();
    urlIn.value = ''; $('#clearUrl').hidden = true; resetPreview();
    if (innerWidth <= 980) setTimeout(() => $('.queue-card').scrollIntoView({ behavior: 'smooth', block: 'start' }), 120);
  }
  // the Download button handles a batch when one is open
  $('#goBtn').onclick = () => batchActive() ? startBatch() : startDownload();

  // "Paste many links"
  $('#multiBtn').onclick = () => { $('#multiModal').hidden = false; $('#multiTxt').value = ''; updMulti(); setTimeout(() => $('#multiTxt').focus(), 50); };
  $('#multiClose').onclick = () => { $('#multiModal').hidden = true; };
  const updMulti = () => { const n = findUrls($('#multiTxt').value).length; $('#multiGoTxt').textContent = n ? `Add ${n} link${n > 1 ? 's' : ''}` : 'Add links'; $('#multiGo').disabled = !n; };
  $('#multiTxt').addEventListener('input', updMulti);
  $('#multiGo').onclick = () => { openMulti(findUrls($('#multiTxt').value)); $('#multiModal').hidden = true; };
  function openMulti(urls) {
    if (!urls.length) return;
    if (urls.length === 1) { urlIn.value = urls[0]; urlIn.dispatchEvent(new Event('input')); clearTimeout(previewT); loadPreview(); return; }
    showBatch(`${urls.length} links`, 'Pasted links', urls.map(u => ({ url: u, title: '' })), 'multi');
    flash('excited', 2400, `${urls.length} links! Ready when you are.`);
    $('#batchCard').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  // pasting several links into the box opens the picker
  urlIn.addEventListener('paste', e => {
    const t = (e.clipboardData || window.clipboardData).getData('text');
    const urls = findUrls(t);
    if (urls.length > 1) { e.preventDefault(); openMulti(urls); }
  });

  /* ------------------------------------------------ DOWNLOAD LATER (runs on this computer at night) */
  const later = { enabled: false, items: [] };
  async function loadLater(r) {
    try { r = r || await fetch('/api/later', { cache: 'no-store' }).then(x => x.json()); } catch (e) { return; }
    later.enabled = !!r.enabled; later.items = r.items || [];
    $('#laterBtn').hidden = !later.enabled; $('#laterCard').hidden = !later.enabled;
    if (!later.enabled) return;
    $('#laterTime').value = r.time; $('#laterWifiTgl').hidden = !r.android; $('#laterWifi').checked = r.wifi_only;
    $('#laterCount').textContent = later.items.length || '';
    $('#laterEmpty').hidden = !!later.items.length; $('#laterStart').hidden = !later.items.length; $('#laterClear').hidden = !later.items.length;
    const box = $('#laterList'); box.innerHTML = '';
    later.items.forEach(it => {
      const r = document.createElement('div'); r.className = 'l-row';
      r.innerHTML = `${it.thumbnail ? '<img alt="">' : ''}<div class="lt"></div><span class="lk"></span><button class="icon-btn hov" title="Remove">${ic('x')}</button>`;
      if (it.thumbnail) $('img', r).src = it.thumbnail;
      $('.lt', r).textContent = it.title || it.url;
      $('.lk', r).textContent = { audio: 'MP3', photo: 'Photo' }[it.req && it.req.kind] || 'MP4';
      $('button', r).onclick = async () => loadLater(await api('/api/later', { action: 'remove', id: it.id }));
      box.appendChild(r);
    });
  }
  const timeLabel = t => { const [h, m] = t.split(':').map(Number); return `${(h % 12) || 12}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
  $('#laterBtn').onclick = async () => {
    const req = Object.assign({ kind: state.kind, quality: state.quality, audio: state.audio, abr: state.abr }, optBody());
    let items;
    if (batchActive()) items = batch.items.filter(i => i.on).map(i => ({ url: i.url, title: i.title, thumbnail: i.thumbnail, req }));
    else {
      const url = urlIn.value.trim();
      if (!isUrl(url)) { shake(); setMood('confused', 'Paste a link first, then tap Later.', 3000); return; }
      const info = state.info && state.info.url === url ? state.info : null;
      items = [{ url, title: info && info.title, thumbnail: info && info.thumbnail, req: Object.assign({ title: info && info.title, thumbnail: info && info.thumbnail, site: info && info.site }, req) }];
    }
    try {
      const r = await api('/api/later', { action: 'add', items });
      loadLater(r); award('later');
      setMood('sleepy', `Saved for later! I'll grab ${items.length > 1 ? 'them' : 'it'} at ${timeLabel(r.time)}.`, 3200);
      if (batchActive()) { $('#batchCard').hidden = true; batch.items = []; updateGoText(); }
      urlIn.value = ''; $('#clearUrl').hidden = true; resetPreview();
      $('#laterCard').scrollIntoView({ behavior: 'smooth', block: 'center' });
    } catch (e) { toast(e.message); }
  };
  $('#laterTime').onchange = async () => { loadLater(await api('/api/later', { action: 'settings', time: $('#laterTime').value })); toast('Starts at ' + timeLabel($('#laterTime').value)); };
  $('#laterWifi').onchange = async () => loadLater(await api('/api/later', { action: 'settings', wifi_only: $('#laterWifi').checked }));
  $('#laterClear').onclick = async () => loadLater(await api('/api/later', { action: 'clear' }));
  $('#laterStart').onclick = async () => {
    try {
      const r = await api('/api/later', { action: 'start' });
      (r.started || []).forEach(j => addJob(j, { url: j.url || '' }));
      loadLater(r); setMood('working', "Okay, starting them now!");
    } catch (e) { toast(e.message); }
  };

  /* ------------------------------------------------ CLIPBOARD WATCHER
     When you come back to Grabby after copying a link, he offers to grab it. */
  const seenClips = new Set(store.get('seenClips', []));
  let clipBusy = false, clipUrl = '';
  async function checkClipboard() {
    if (!$('#optClip').checked || clipBusy || document.hidden) return;
    clipBusy = true;
    try {
      let t = '';
      if (ANDROID) t = window.VidGrabAndroid.getClipboard() || '';
      else if (navigator.clipboard && navigator.clipboard.readText) {
        if (navigator.permissions) {
          try { const p = await navigator.permissions.query({ name: 'clipboard-read' }); if (p.state === 'denied') return; } catch (e) {}
        }
        t = await navigator.clipboard.readText();
      }
      handleClip(t);
    } catch (e) { /* no permission: stay quiet */ }
    finally { clipBusy = false; }
  }
  function handleClip(t) {
    if (!$('#optClip').checked) return;
    const u = findUrls(t)[0];
    if (!u || seenClips.has(u) || u === urlIn.value.trim() || state.history.some(h => h.url === u)) return;
    seenClips.add(u); store.set('seenClips', [...seenClips].slice(-40));
    clipUrl = u;
    if (store.get('autoGo', false)) { showTab('download'); startDownload({ url: u }); toast('Downloading the link you copied'); return; }
    $('#clipUrl').textContent = u; $('#clipPop').hidden = false;
    flash('surprised', 2200, 'Ooh, you copied a link!');
  }
  window.grabbyClipboard = t => { try { handleClip(t); } catch (e) {} };   // the phone app hands copied links in here
  const hideClip = () => { $('#clipPop').hidden = true; };
  $('#clipNo').onclick = hideClip;
  $('#clipGo').onclick = () => { hideClip(); showTab('download'); startDownload({ url: clipUrl }); };
  $('#clipLook').onclick = () => { hideClip(); showTab('download'); urlIn.value = clipUrl; urlIn.dispatchEvent(new Event('input')); clearTimeout(previewT); loadPreview(); };
  addEventListener('focus', () => setTimeout(checkClipboard, 250));
  document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(checkClipboard, 250); });

  /* =====================================================================
     GRABBY HUB – daily gift, outfits closet, sticker album, Hugot of the Day.
     Everything is saved in this browser / phone app.
     ===================================================================== */
  const OUTFITS = [
    ['cap', 'head', 'Cap', 'Daily gift'], ['party', 'head', 'Party hat', 'Daily gift'], ['santa', 'head', 'Santa hat', 'Daily gift'],
    ['ears', 'head', 'Cat ears', 'Daily gift'], ['bow', 'head', 'Bow', 'Daily gift'], ['flower', 'head', 'Flower', 'Daily gift'],
    ['ninja', 'head', 'Ninja band', 'Daily gift'], ['nerd', 'face', 'Nerd glasses', 'Daily gift'], ['stache', 'face', 'Mustache', 'Daily gift'],
    ['bowtie', 'neck', 'Bow tie', 'Daily gift'], ['scarf', 'neck', 'Scarf', 'Daily gift'], ['cape', 'neck', 'Hero cape', 'Daily gift'],
    ['grad', 'head', 'Grad cap', 'Sticker: 50 downloads'], ['halo', 'head', 'Halo', 'Sticker: 7-day streak'], ['crown', 'head', 'Crown', 'Sticker: 100 downloads'],
  ];
  const GIFTABLE = OUTFITS.filter(o => o[3] === 'Daily gift').map(o => o[0]);
  const STICKERS = [
    ['first', 'First Grab', 'Download your first video', 'excited'], ['youtube', 'YouTuber', 'Download from YouTube', 'proud', { head: 'cap' }],
    ['facebook', 'FB Friend', 'Download from Facebook', 'wink'], ['instagram', 'Insta Star', 'Download from Instagram', 'cool'],
    ['tiktok', 'TikToker', 'Download from TikTok', 'dance'], ['x', 'Tweety', 'Download from X / Twitter', 'salute'],
    ['reddit', 'Redditor', 'Download from Reddit', 'curious'], ['music', 'DJ Grabby', 'Save your first MP3', 'music'],
    ['photo', 'Shutterbug', 'Save a photo', 'happy', { face: 'nerd' }], ['night', 'Night Owl', 'Download after midnight', 'sleepy'],
    ['early', 'Early Bird', 'Download between 5 and 7 AM', 'yawn', { head: 'flower' }], ['ten', 'Getting Started', '10 downloads', 'highfive'],
    ['fifty', 'Collector', '50 downloads', 'proud', { head: 'grad' }], ['hundred', 'Legend', '100 downloads', 'love', { head: 'crown', neck: 'cape' }],
    ['batch', 'Bulk Buddy', 'Grab 5 or more at once', 'laughing'], ['messenger', 'Messenger Pro', 'Make a Messenger-size video', 'kiss'],
    ['maker', 'Creator', 'Make a ringtone, GIF or clip', 'proud', { head: 'party' }], ['streak3', 'On Fire', '3-day download streak', 'excited'],
    ['streak7', 'Unstoppable', '7-day download streak', 'cool', { head: 'halo' }], ['subs', 'Bookworm', 'Download with subtitles', 'thinking', { face: 'nerd' }],
    ['phone', 'Phone Pal', 'Send a video to your phone', 'wink'], ['later', 'Night Shift', 'Schedule a download for later', 'sleepy', { head: 'santa' }],
    ['boxes', 'Gift Hunter', 'Open 7 daily gifts', 'blush', { neck: 'bowtie' }], ['shiny', 'Shiny Grabby', 'Super rare from the daily gift', 'proud', { extra: 'shiny' }],
  ];
  const STICKER_OUTFIT = { fifty: 'grad', streak7: 'halo', hundred: 'crown' };
  const HUGOT = [
    "Buti pa 'yung video, na-save ko. Ikaw, hindi.", 'Sana all, may download button.', "Hindi lahat ng buffering, may ending.",
    'Sa 1080p kita nakilala, sa 144p mo ako iniwan.', 'Hindi ako MP3, pero paulit-ulit kitang pinapakinggan.', 'May expiration ang link. Sana pati ang feelings ko.',
    'Na-trim ko na ang video. Sana ganun din kadali mag-move on.', 'Ikaw ang pinakamabagal kong download: matagal, pero worth it.', "Kahit walang Wi-Fi, connected pa rin ako sa'yo.",
    "Hindi na kita kailangang i-screenshot. Naka-save ka na sa puso ko.", 'Na-cancel mo ako na parang download na 99% na.', 'Sana ako na lang ang video na pinapanood mo nang paulit-ulit.',
    '25 MB lang ang limit sa Messenger, pero unlimited ang pagmamahal ko.', "Na-shrink ko na ang video. Ang hindi ko ma-shrink, ang pagka-miss ko sa'yo.", 'Error: Hindi ma-download ang feelings mo. Private daw.',
    'Bakit ka pa mag-stream kung puwede mo naman akong i-download?', "Ang dali mong i-save, ang hirap mong burahin.", 'Hindi ako ringtone, pero sana ako ang tumunog sa puso mo.',
    'Ginawa kitang GIF: paulit-ulit, walang tunog, pero napapangiti pa rin ako.', "Tulog na ang lahat, pero gising pa rin ang downloads ko. Parang ako sa'yo.", "Kung may 'Continue watching' lang sana ang love story natin.",
    'Akala ko HD ka, blurred pala ang intentions mo.', 'Walang skip ad sa pagmamahal ko.', 'Sa dami ng na-save ko, ikaw lang ang hindi ko ma-delete.',
    'Iba talaga ang tama ng 320 kbps. Parang ikaw.', "Nag-loading ako nang matagal, 'Video unavailable' ka pala.", 'Okay lang maging offline. Nandito pa rin ang mga na-save natin.',
    'Tinag mo ako sa memes, pero hindi sa future mo.', "Na-sort ko na lahat ng folders ko. Ikaw na lang ang hindi ko alam kung saan ilalagay.", 'Sine-save ko lahat ng slides mo. Lahat ng chances.',
    'May subtitles na nga, hindi mo pa rin ako maintindihan.', 'Ang buhay ay parang download: minsan stuck sa 99%. Laban lang!', 'Sana kasing bilis ni Grabby ang reply mo.',
    "I-burn in mo na lang ako sa buhay mo, para hindi na ako ma-off.", 'Hindi ako app, pero lagi akong nandito kapag kailangan mo.', "Kung data lang ang pagmamahal ko, naka-unli ka.",
    'One tap lang ako, pero hanggang ngayon hindi mo pa rin ako pinipili.', 'Ang playlist natin, naka-shuffle. Pati ang ending.', 'Hindi ako backup, pero lagi mo akong binabalikan.',
  ];
  const G = Object.assign({ dl: 0, days: 0, lastDay: '', streak: 0, best: 0, boxes: 0, lastBox: '', owned: [], wear: {}, stickers: {}, hugotShift: 0 }, store.get('grabby', {}));
  const saveG = () => store.set('grabby', G);
  const dayKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const yesterday = () => { const d = new Date(); d.setDate(d.getDate() - 1); return dayKey(d); };
  const mascotSVG = mascot.querySelector('svg').outerHTML;
  function miniGrabby(mood, outfit) {
    const m = document.createElement('div');
    m.className = 'mascot'; m.dataset.mood = mood || 'idle';
    Object.entries(outfit || {}).forEach(([k, v]) => { if (v) m.dataset[k] = v; });
    m.innerHTML = mascotSVG; return m;
  }
  // dress every Grabby on screen (the big one, the flyer, the player dancer, the hub)
  function applyOutfit() {
    $$('.mascot').forEach(m => {
      if (m.closest('.sticker, .c-item, #giftMe')) return;
      ['head', 'face', 'neck', 'extra'].forEach(k => { if (G.wear[k]) m.dataset[k] = G.wear[k]; else delete m.dataset[k]; });
    });
  }
  function award(id) {
    if (G.stickers[id]) return;
    const s = STICKERS.find(x => x[0] === id); if (!s) return;
    G.stickers[id] = Date.now();
    const o = STICKER_OUTFIT[id]; if (o && !G.owned.includes(o)) G.owned.push(o);
    saveG();
    setTimeout(() => {
      toast(`New sticker: ${s[1]}!` + (o ? ' + a new outfit' : ''));
      if (!flying) setMood('excited', `You unlocked the “${s[1]}” sticker! See it in the Grabby tab.`, 3600);
      $('#boxDot').dataset.sticker = '1'; $('#boxDot').hidden = false;
    }, 1400);
    renderHub(id);
  }
  // called when any download or tool job finishes
  function recordDone(j) {
    const d = j.data;
    if (d.tool) return;
    G.dl++;
    const today = dayKey();
    if (G.lastDay !== today) { G.streak = G.lastDay === yesterday() ? G.streak + 1 : 1; G.best = Math.max(G.best, G.streak); G.lastDay = today; G.days++; }
    saveG();
    award('first');
    const site = (d.site || '').toLowerCase();
    if (site.includes('youtube')) award('youtube'); if (site.includes('facebook')) award('facebook'); if (site.includes('instagram')) award('instagram');
    if (site.includes('tiktok')) award('tiktok'); if (site.includes('twitter') || site === 'x') award('x'); if (site.includes('reddit')) award('reddit');
    if (d.kind === 'audio') award('music'); if (d.kind === 'photo') award('photo');
    if (/subtitles/.test(d.label || '')) award('subs'); if (/Messenger/.test(d.label || '')) award('messenger');
    const h = new Date().getHours(); if (h < 4) award('night'); if (h >= 5 && h < 7) award('early');
    if (G.dl >= 10) award('ten'); if (G.dl >= 50) award('fifty'); if (G.dl >= 100) award('hundred');
    if (G.streak >= 3) award('streak3'); if (G.streak >= 7) award('streak7');
    updGift(); renderHub();
  }
  const giftReady = () => G.lastDay === dayKey() && G.lastBox !== dayKey();
  function updGift() {
    const ready = giftReady(), opened = G.lastBox === dayKey();
    const btn = $('#giftBtn');
    btn.classList.toggle('ready', ready); btn.classList.toggle('locked', !ready && !opened); btn.classList.toggle('opened', opened);
    $('#giftOpen').disabled = !ready;
    $('#giftMsg').textContent = ready ? 'Your gift is ready! What could it be?' : opened ? 'Come back tomorrow for another gift.' : 'Download anything today to unlock your gift!';
    $('#giftHint').textContent = `${G.boxes} opened`;
    $('#boxDot').hidden = !(ready || $('#boxDot').dataset.sticker);
  }
  let giftItem = null;
  async function openGift() {
    if (!giftReady()) return;
    G.lastBox = dayKey(); G.boxes++; saveG();
    const btn = $('#giftBtn'); btn.classList.remove('ready'); btn.classList.add('shake');
    $('#giftOpen').disabled = true;
    setMood('excited', 'Ooh, ano kaya \'to?', 2000);
    await new Promise(r => setTimeout(r, 1500));
    btn.classList.remove('shake'); btn.classList.add('pop'); confetti(btn);
    const left = GIFTABLE.filter(o => !G.owned.includes(o));
    let title, text, outfit = null;
    if (!G.stickers.shiny && Math.random() < 0.06) {
      award('shiny');
      title = 'SUPER RARE: Shiny Grabby!'; text = 'Only a few people ever get this. Grabby sparkles now!'; giftItem = ['shiny', 'extra']; outfit = { extra: 'shiny' };
    } else if (left.length) {
      const id = pick(left), o = OUTFITS.find(x => x[0] === id);
      G.owned.push(id); giftItem = [id, o[1]]; outfit = { [o[1]]: id };
      title = `You got: ${o[2]}!`; text = 'Wear it now or find it later in the Closet.';
    } else {
      giftItem = null; title = 'You got: a dance party!'; text = pick(HUGOT);
    }
    if (G.boxes >= 7) award('boxes');
    saveG();
    $('#giftMe').innerHTML = ''; $('#giftMe').appendChild(miniGrabby(outfit ? 'proud' : 'dance', outfit || G.wear));
    $('#giftTitle').textContent = title; $('#giftText').textContent = text;
    $('#giftWear').hidden = !giftItem;
    $('#giftModal').hidden = false;
    setTimeout(() => { btn.classList.remove('pop'); updGift(); renderHub(); }, 900);
  }
  $('#giftBtn').onclick = () => giftReady() ? openGift() : toast($('#giftMsg').textContent);
  $('#giftOpen').onclick = openGift;
  $('#giftOk').onclick = () => { $('#giftModal').hidden = true; };
  $('#giftWear').onclick = () => {
    if (giftItem) { G.wear[giftItem[1]] = giftItem[0]; saveG(); applyOutfit(); renderHub(); }
    $('#giftModal').hidden = true; setMood('proud', 'How do I look?', 2600);
  };

  function renderHub(newSticker) {
    if (!$('#tab-grabby').classList.contains('on') && !newSticker) return;
    const owned = G.owned.length, got = Object.keys(G.stickers).length;
    $('#gsDl').textContent = G.dl; $('#gsStreak').textContent = G.lastDay === dayKey() || G.lastDay === yesterday() ? G.streak : 0;
    $('#gsSt').textContent = `${got}/${STICKERS.length}`; $('#gsOut').textContent = `${owned}/${OUTFITS.length}`;
    $('#albumHint').textContent = `${got} of ${STICKERS.length} collected`;
    if (!$('#gMe').firstChild) {
      const me = miniGrabby('idle'); me.id = 'hubMe'; $('#gMe').appendChild(me);
      me.onclick = () => { let m; do { m = pick(TAP_POOL); } while (m === me.dataset.mood); me.dataset.mood = ''; void me.offsetWidth; me.dataset.mood = m; clearTimeout(me._t); me._t = setTimeout(() => me.dataset.mood = 'idle', 1900); };
    }
    applyOutfit();
    // closet
    const cl = $('#closet'); cl.innerHTML = '';
    const none = document.createElement('div'); none.className = 'c-item' + (!G.wear.head && !G.wear.face && !G.wear.neck ? ' on' : '');
    none.appendChild(miniGrabby('idle')); none.insertAdjacentHTML('beforeend', '<b>Just me</b><small>No outfit</small>');
    none.onclick = () => { G.wear = { extra: G.wear.extra }; saveG(); applyOutfit(); renderHub(); };
    cl.appendChild(none);
    OUTFITS.forEach(([id, slot, name, how]) => {
      const has = G.owned.includes(id), on = G.wear[slot] === id;
      const t = document.createElement('div'); t.className = 'c-item' + (on ? ' on' : '') + (has ? '' : ' locked');
      t.appendChild(miniGrabby(has ? 'happy' : 'idle', has ? { [slot]: id } : {}));
      t.insertAdjacentHTML('beforeend', `<b>${has ? esc(name) : '???'}</b><small>${has ? (on ? 'Tap to take off' : 'Tap to wear') : esc(how)}</small>`);
      t.onclick = () => {
        if (!has) return toast(`Locked. Get it from: ${how}`);
        G.wear[slot] = on ? null : id; saveG(); applyOutfit(); renderHub();
        if (!on) setMood('proud', pick(['Bagay ba?', 'Pogi ko diba?', 'Fashion icon!', 'How do I look?']), 2400);
      };
      cl.appendChild(t);
    });
    if (G.stickers.shiny) {
      const on = G.wear.extra === 'shiny';
      const t = document.createElement('div'); t.className = 'c-item' + (on ? ' on' : '');
      t.appendChild(miniGrabby('proud', { extra: 'shiny' })); t.insertAdjacentHTML('beforeend', `<b>Shiny</b><small>Super rare!</small>`);
      t.onclick = () => { G.wear.extra = on ? null : 'shiny'; saveG(); applyOutfit(); renderHub(); };
      cl.appendChild(t);
    }
    // album
    const al = $('#album'); al.innerHTML = '';
    STICKERS.forEach(([id, name, hint, mood, outfit], i) => {
      const has = !!G.stickers[id];
      const s = document.createElement('div'); s.className = 'sticker' + (has ? '' : ' locked') + (id === newSticker ? ' new' : '');
      s.style.animationDelay = Math.min(i * 30, 500) + 'ms';
      s.appendChild(miniGrabby(mood, outfit));
      s.insertAdjacentHTML('beforeend', `<b>${has ? esc(name) : '???'}</b><small>${esc(hint)}</small>`);
      s.title = has ? `${name}: unlocked ${new Date(G.stickers[id]).toLocaleDateString()}` : hint;
      al.appendChild(s);
    });
    // hugot
    renderHugot();
  }
  const hugotIndex = () => { const n = Math.floor(Date.now() / 864e5) + G.hugotShift; return ((n * 7) % HUGOT.length + HUGOT.length) % HUGOT.length; };
  function renderHugot() {
    $('#hugotTxt').textContent = HUGOT[hugotIndex()];
    $('#hugotDate').textContent = new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  }
  $('#hugotNext').onclick = () => { G.hugotShift++; saveG(); renderHugot(); flash('laughing', 1600, pick(['Aray ko!', 'Ouch, tinamaan ako!', 'Huhu, relate.'])); };
  $('#hugotShare').onclick = () => shareHugot(HUGOT[hugotIndex()]);

  // draws the share card (1080 × 1080) with Grabby and the line
  function hugotCanvas(text) {
    const cv = document.createElement('canvas'); cv.width = 1080; cv.height = 1080;
    const x = cv.getContext('2d');
    x.fillStyle = '#fff'; x.fillRect(0, 0, 1080, 1080);
    x.fillStyle = '#111'; x.fillRect(64, 64, 980, 980); x.fillStyle = '#fff'; x.fillRect(48, 48, 970, 970);
    x.lineWidth = 8; x.strokeStyle = '#111'; x.strokeRect(48, 48, 970, 970);
    x.fillStyle = '#111'; x.font = '800 40px system-ui, Segoe UI, Roboto, sans-serif'; x.fillText('HUGOT OF THE DAY', 110, 150);
    x.font = '900 150px Georgia, serif'; x.fillText('“', 96, 300);
    let size = 66; const maxW = 840; const words = text.split(' ');
    let lines;
    do {
      x.font = `800 ${size}px system-ui, Segoe UI, Roboto, sans-serif`;
      lines = []; let cur = '';
      words.forEach(w => { const t = cur ? cur + ' ' + w : w; if (x.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; });
      lines.push(cur); size -= 4;
    } while (lines.length * (size * 1.3) > 470 && size > 34);
    size += 4; x.font = `800 ${size}px system-ui, Segoe UI, Roboto, sans-serif`;
    lines.forEach((l, i) => x.fillText(l, 110, 330 + i * size * 1.3));
    // Grabby
    const gx = 830, gy = 830;
    x.lineWidth = 7; x.lineJoin = 'round'; x.lineCap = 'round'; x.strokeStyle = '#111';
    x.beginPath(); x.moveTo(gx, gy - 92); x.lineTo(gx, gy - 125); x.stroke();
    x.beginPath(); x.arc(gx, gy - 134, 12, 0, 7); x.fillStyle = '#111'; x.fill();
    x.beginPath(); x.moveTo(gx - 92, gy + 20); x.quadraticCurveTo(gx - 120, gy + 30, gx - 128, gy + 58); x.stroke();
    x.beginPath(); x.arc(gx - 129, gy + 64, 14, 0, 7); x.fillStyle = '#fff'; x.fill(); x.stroke();
    x.beginPath(); x.moveTo(gx + 92, gy + 20); x.quadraticCurveTo(gx + 125, gy - 5, gx + 132, gy - 40); x.stroke();
    x.beginPath(); x.arc(gx + 133, gy - 47, 14, 0, 7); x.fillStyle = '#fff'; x.fill(); x.stroke();
    const rr = (X, Y, W, H, R) => { x.beginPath(); x.moveTo(X + R, Y); x.arcTo(X + W, Y, X + W, Y + H, R); x.arcTo(X + W, Y + H, X, Y + H, R); x.arcTo(X, Y + H, X, Y, R); x.arcTo(X, Y, X + W, Y, R); x.closePath(); };
    rr(gx - 100, gy - 92, 200, 204, 98); x.fillStyle = '#fff'; x.fill(); x.lineWidth = 8; x.stroke();
    x.lineWidth = 7;
    [[-34, -20], [34, -20]].forEach(([dx, dy]) => { x.beginPath(); x.arc(gx + dx, gy + dy + 8, 15, Math.PI * 1.1, Math.PI * 1.9); x.stroke(); });
    x.fillStyle = '#d8d8d8'; [[-62, 18], [62, 18]].forEach(([dx, dy]) => { x.beginPath(); x.ellipse(gx + dx, gy + dy, 15, 8, 0, 0, 7); x.fill(); });
    x.beginPath(); x.arc(gx, gy + 14, 20, 0.15 * Math.PI, 0.85 * Math.PI); x.stroke();
    rr(gx - 46, gy + 46, 92, 42, 14); x.fillStyle = '#111'; x.fill();
    x.fillStyle = '#fff'; x.beginPath(); x.moveTo(gx, gy + 78); x.bezierCurveTo(gx - 16, gy + 66, gx - 20, gy + 54, gx - 9, gy + 52); x.bezierCurveTo(gx - 4, gy + 51, gx, gy + 56, gx, gy + 58);
    x.bezierCurveTo(gx, gy + 56, gx + 4, gy + 51, gx + 9, gy + 52); x.bezierCurveTo(gx + 20, gy + 54, gx + 16, gy + 66, gx, gy + 78); x.fill();
    x.fillStyle = '#111'; x.font = '900 46px system-ui, Segoe UI, Roboto, sans-serif'; x.fillText('Grabby', 110, 920);
    x.font = '600 28px system-ui, Segoe UI, Roboto, sans-serif'; x.fillStyle = '#555'; x.fillText('Save any video in HD. Free.', 110, 962);
    return cv;
  }
  async function shareHugot(text) {
    const cv = hugotCanvas(text);
    const blob = await new Promise(r => cv.toBlob(r, 'image/png'));
    const file = new File([blob], 'grabby-hugot.png', { type: 'image/png' });
    try {
      if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], text: text + ' #Grabby' }); return; }
    } catch (e) { if (e.name === 'AbortError') return; }
    if (ANDROID || (lib.enabled && innerWidth <= 760)) {      // the phone app can't save a picture directly: keep it in My Videos
      try {
        const data = cv.toDataURL('image/png');
        const r = await api('/api/library/card', { data });
        toast('Saved to My Videos › Photos'); loadLibrary();
        if (ANDROID) { const a = document.createElement('a'); a.href = libUrl(r.name, true); a.download = r.name; document.body.appendChild(a); a.click(); a.remove(); }
        return;
      } catch (e) {}
    }
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'grabby-hugot.png';
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast('Card saved. Post it on Facebook!');
  }

  /* ------------------------------------------------ USE GRABBY ANYWHERE (owner login + Go online) */
  let ownerInfo = null, onPoll = null;
  async function loadOwner() {
    try { ownerInfo = await fetch('/api/owner', { cache: 'no-store' }).then(r => r.json()); } catch (e) { return; }
    const o = ownerInfo;
    if (o.android) { $('#onlineCard').hidden = true; $('#loginCard').hidden = true; $('#sideLogin').hidden = true; return; }
    $('#onlineCard').hidden = !o.owner;
    $('#loginCard').hidden = o.local;
    $('#sideLogin').hidden = o.owner;
    $('#loginOpen').hidden = o.owner; $('#logoutBtn').hidden = !o.owner || o.local;
    $('#loginWho').textContent = o.owner ? "You're logged in as the owner on this device." : 'Are you the owner? Log in to get My Videos, Download later and your settings here too.';
    $('#pwLabel').textContent = o.has_password ? 'Change owner password' : 'Owner password';
    $('#pwHint').textContent = o.has_password ? 'Your password is set. You can change it here; that logs out every other device.' : 'Set a password first. With it, only you get My Videos, Later and the tip settings from outside. Friends who open your link can still download.';
    if (o.owner && o.online) renderOnline(o.online);
  }
  function renderOnline(t) {
    const st = $('#onStatus'); st.className = 'online-status ' + t.status;
    $('#onText').textContent = { on: 'Online', starting: 'Going online…', off: 'Offline' }[t.status];
    $('#onNote').textContent = t.error ? t.error : t.note || '';
    $('#onLink').hidden = !t.url;
    if (t.url && $('#onUrl').textContent !== t.url) { $('#onUrl').textContent = t.url; $('#onQr').innerHTML = t.qr; }
    $('#onGoTxt').textContent = t.status === 'off' ? 'Go online' : t.status === 'on' ? 'Go offline' : 'Starting…';
    $('#onGo').disabled = t.status === 'starting' || (t.status === 'on' && ownerInfo && !ownerInfo.local);
    $('#onAuto').checked = !!t.auto;
    clearInterval(onPoll);
    if (t.status === 'starting') onPoll = setInterval(async () => { try { const r = await fetch('/api/online', { cache: 'no-store' }).then(x => x.json()); renderOnline(r); if (r.status === 'on') { setMood('excited', "We're online! Scan the code with your phone.", 3600); confetti($('#onLink')); } } catch (e) {} }, 1200);
  }
  $('#onGo').onclick = async () => {
    const cur = $('#onStatus').classList.contains('on') ? 'stop' : 'start';
    try { renderOnline(await api('/api/online', { action: cur })); if (cur === 'stop') setMood('sleepy', 'Offline again. Only this computer can use me now.', 2600); }
    catch (e) { toast(e.message); if (/password/i.test(e.message)) $('#pwNew').focus(); }
  };
  $('#onAuto').onchange = async () => { try { renderOnline(await api('/api/online', { action: 'auto', value: $('#onAuto').checked })); } catch (e) { toast(e.message); } };
  $('#onCopy').onclick = async () => { try { await navigator.clipboard.writeText($('#onUrl').textContent); toast('Link copied'); } catch (e) { toast($('#onUrl').textContent); } };
  $('#onOpen').onclick = () => window.open($('#onUrl').textContent, '_blank', 'noopener');
  $('#pwSave').onclick = async () => {
    const pw = $('#pwNew').value;
    try { await api('/api/owner/password', { password: pw }); $('#pwNew').value = ''; toast('Owner password saved'); setMood('proud', 'Password set! Only you get the owner stuff now.', 2600); loadOwner(); }
    catch (e) { toast(e.message); }
  };
  $('#pwNew').addEventListener('keydown', e => { if (e.key === 'Enter') $('#pwSave').click(); });
  const openLogin = () => { $('#loginModal').hidden = false; $('#loginErr').hidden = true; $('#loginPw').value = ''; setTimeout(() => $('#loginPw').focus(), 50); };
  $('#sideLogin').onclick = openLogin; $('#loginOpen').onclick = openLogin;
  $('#loginClose').onclick = () => { $('#loginModal').hidden = true; };
  $('#loginGo').onclick = async () => {
    try { await api('/api/owner/login', { password: $('#loginPw').value }); toast('Welcome back!'); setTimeout(() => location.reload(), 400); }
    catch (e) { $('#loginErr').textContent = e.message; $('#loginErr').hidden = false; setMood('confused', 'Hmm, that password is not right.', 2400); }
  };
  $('#loginPw').addEventListener('keydown', e => { if (e.key === 'Enter') $('#loginGo').click(); });
  $('#logoutBtn').onclick = async () => { await api('/api/owner/logout', {}); location.reload(); };

  /* ------------------------------------------------ THE PHONE APP: download card + "update available" */
  async function loadAppInfo() {
    let a; try { a = await fetch('/api/appinfo', { cache: 'no-store' }).then(r => r.json()); } catch (e) { return; }
    $$('#tab-apps .owner-only').forEach(el => el.hidden = !a.owner || ANDROID);
    if (ANDROID) { $('#getAppCard').hidden = true; return; }
    $('.ga-row', $('#getAppCard')).hidden = !a.available;
    $('#gaNone').hidden = a.available || a.owner;
    $('#getAppCard').hidden = !a.available && !a.owner;
    if (a.available) { $('#gaQr').innerHTML = a.qr; $('#gaBtn').href = '/get-app'; $('#gaVer').textContent = `Version ${a.version} · free · always the newest version`; }
    $('#gaOwner').hidden = !a.owner;
    $('#gaOwnerTxt').textContent = a.repo ? `Published from GitHub (${a.repo}). New versions appear automatically.`
      : a.local ? `Sharing the APK you uploaded (${fmtBytes(a.local.size)}). Upload a newer one any time. Note: without GitHub, installed apps can't update themselves.`
      : 'Not published yet. Upload the Grabby.apk you built in Android Studio, or set up GitHub releases so the app can update itself.';
  }
  $('#gaFile').onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    const fd = new FormData(); fd.append('file', f);
    toast('Uploading the app…');
    try { const r = await fetch('/api/app/upload', { method: 'POST', body: fd }).then(x => x.json()); if (r.error) throw new Error(r.error); toast('App uploaded! People can download it now.'); loadAppInfo(); }
    catch (err) { toast(err.message); }
    e.target.value = '';
  };
  let upInfo = null;
  async function checkUpdate(force) {
    if (!ANDROID && !DESKTOP && !force) return;   // the phone and Windows apps update themselves; your own PC copy gets new files from you
    const last = store.get('upCheck', 0);
    if (!force && Date.now() - last < 6 * 3600e3 && !store.get('upNewer', false)) return;
    try { upInfo = await fetch('/api/update' + (force ? '?force=1' : ''), { cache: 'no-store' }).then(r => r.json()); } catch (e) { return; }
    store.set('upCheck', Date.now()); store.set('upNewer', !!upInfo.newer);
    if (!upInfo.newer) { $('#upBanner').hidden = true; $('#updateCard').hidden = true; return; }
    $('#upBannerTxt').textContent = `Grabby ${upInfo.latest} is out! Tap to update`;
    $('#upBanner').hidden = false;
    $('#upTitle').textContent = `Grabby ${upInfo.latest} is out! (you have ${upInfo.current})`;
    $('#upNotes').textContent = upInfo.notes || 'New features and fixes.';
    $('#updateCard').hidden = false;
    setTimeout(() => setMood('excited', `Psst! A new version of me is out: ${upInfo.latest}. Tap the black bar to update!`, 5000), 2500);
    if (ANDROID && window.VidGrabAndroid.notify && store.get('notifiedVer', '') !== upInfo.latest) {   // once per version
      store.set('notifiedVer', upInfo.latest);
      try { window.VidGrabAndroid.notify('update', `Grabby ${upInfo.latest} is out!`, (upInfo.notes || 'New features and fixes.').split('\n').filter(Boolean).slice(0, 3).join(' · ') + ' Tap to update.', 'apps'); } catch (e) { }
    }
  }
  function doUpdate() {
    if (!upInfo || !upInfo.url) return;
    if (DESKTOP) {
      toast('Downloading the new Grabby… open Grabby-Windows.exe when it finishes. It replaces this one.');
      location.href = upInfo.url; return;
    }
    toast('Downloading the new Grabby… open it when it finishes to install.');
    if (ANDROID && window.VidGrabAndroid.openUrl) window.VidGrabAndroid.openUrl(upInfo.url); else location.href = upInfo.url;
  }
  $('#upBanner').onclick = () => { showTab('apps'); };
  $('#upGo').onclick = doUpdate;

  /* ------------------------------------------------ SETTINGS */
  var grabbyOn = () => store.get('grabbyOn', true);
  var flyMode = () => store.get('grabbyFly', 'roam');
  const FLY_HINT = { home: 'He stays in his spot at the top and never flies off.', roam: 'He visits buttons with tips and follows you when you scroll.', always: 'He flies around the whole app all the time. Drag him anywhere you like!' };
  function applyGrabbySettings() {
    document.body.classList.toggle('no-grabby', !grabbyOn());
    document.body.classList.toggle('no-talk', !store.get('grabbyTalk', true));
    $('#setGrabby').checked = grabbyOn();
    $('#setTalk').checked = store.get('grabbyTalk', true);
    $$('#setFly button').forEach(b => b.classList.toggle('on', b.dataset.v === flyMode()));
    $('#flyHint').textContent = FLY_HINT[flyMode()];
    $('#flyRow').style.opacity = $('#talkRow').style.opacity = grabbyOn() ? 1 : .45;
    $('#setFlyReset').hidden = !store.get('dockPos', null);
    try { flyer.classList.toggle('always', flyMode() === 'always'); } catch (e) { /* not built yet */ }
  }
  $('#setGrabby').onchange = e => {
    store.set('grabbyOn', e.target.checked); applyGrabbySettings();
    if (typeof checkDock === 'function') checkDock();
    if (e.target.checked) setMood('excited', "I'm back! Did you miss me?", 2600);
  };
  $('#setTalk').onchange = e => { store.set('grabbyTalk', e.target.checked); applyGrabbySettings(); };
  $$('#setFly button').forEach(b => b.onclick = () => {
    store.set('grabbyFly', b.dataset.v); applyGrabbySettings();
    setTimeout(() => { if (typeof checkDock === 'function') checkDock(); }, 50);
    if (b.dataset.v === 'always') toast('Grabby is flying! Drag him to move him.');
  });
  $('#setFlyReset').onclick = () => { store.set('dockPos', null); applyGrabbySettings(); toast('Grabby is back in the corner'); };
  $('#setAutoGo').checked = store.get('autoGo', false);
  $('#setAutoGo').onchange = e => store.set('autoGo', e.target.checked);
  function syncDefaults() {
    $$('#setKind button').forEach(b => b.classList.toggle('on', b.dataset.v === state.kind));
    $$('#setQual button').forEach(b => b.classList.toggle('on', b.dataset.v === state.quality));
  }
  $$('#setKind button').forEach(b => b.onclick = () => { setKind(b.dataset.v); syncDefaults(); toast('Saved'); });
  $$('#setQual button').forEach(b => b.onclick = () => { state.quality = b.dataset.v; store.set('quality', b.dataset.v); renderQualities(); syncDefaults(); toast('Saved'); });
  if (ANDROID) {
    $('#autosaveLbl').textContent = 'Save to my phone automatically';
    $('#autosaveSub').textContent = 'Puts a copy in Downloads/Grabby, so it shows in your Gallery and music apps.';
  } else {
    $('#autosaveSub').textContent = 'For people using your link. On this computer, downloads are kept in My Videos.';
  }
  // ---- Phone app: sign in to sites (private posts) + the self-updating download engine
  function loadSites() {
    try {
      if (!ANDROID || !window.VidGrabAndroid.signIn) return;
      $('#sitesCard').hidden = false;
      let s = [];
      try { s = JSON.parse(window.VidGrabAndroid.signedInSites() || '[]'); } catch (e) { }
      $('#siteList').textContent = s.length ? 'Signed in: ' + s.join(', ') : 'Not signed in anywhere yet.';
      $('#siteOut').hidden = !s.length;
    } catch (e) { }
  }
  $$('#siteBtns [data-site]').forEach(b => b.onclick = () => window.VidGrabAndroid && window.VidGrabAndroid.signIn(b.dataset.site));
  $('#siteGo').onclick = () => {
    let u = $('#siteUrl').value.trim();
    if (!u || !window.VidGrabAndroid) return;
    if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
    window.VidGrabAndroid.signIn(u);
  };
  $('#siteOut').onclick = () => { window.VidGrabAndroid.signOutAll(); setTimeout(loadSites, 400); toast('Signed out of all sites'); };
  window.grabbySignedIn = n => {
    loadSites();
    toast(n ? 'Signed in! Private posts from that site can download now.' : "Didn't see a sign-in. Log in on the site first, then tap Done.");
  };
  let engReady = false;
  function renderEngine(r) {
    engReady = !!r.ready;
    $('#engTxt').textContent = r.checking ? 'Looking for a newer engine…'
      : r.ready ? `New engine (yt-dlp ${r.ready}) is ready. Restart Grabby to use it.`
      : `yt-dlp ${r.version}. Updates itself, so sites keep working.`;
    $('#engBtnTxt').textContent = r.ready ? 'Restart now' : 'Update engine';
  }
  async function loadEngine(check) {
    if (!ANDROID) return;
    $('#engRow').hidden = false;
    try {
      const r = await fetch('/api/engine', { method: check ? 'POST' : 'GET', cache: 'no-store' }).then(r => r.json());
      renderEngine(r);
      if (!check) return;
      for (let i = 0; i < 80; i++) {
        await new Promise(ok => setTimeout(ok, 1500));
        const r2 = await fetch('/api/engine', { cache: 'no-store' }).then(r => r.json());
        renderEngine(r2);
        if (!r2.checking) {
          toast(r2.ready ? 'New engine downloaded. Tap Restart now.' : r2.error ? "Couldn't check right now. Try again later." : 'You already have the newest engine.');
          break;
        }
      }
    } catch (e) { }
  }
  $('#engBtn').onclick = () => {
    if (engReady && window.VidGrabAndroid && window.VidGrabAndroid.restartApp) window.VidGrabAndroid.restartApp();
    else loadEngine(true);
  };
  async function loadSettingsInfo() {
    syncDefaults(); applyGrabbySettings(); loadSites(); loadEngine(false);
    try {
      const h = await fetch('/api/health', { cache: 'no-store' }).then(r => r.json());
      const v = `Grabby ${h.version}${ANDROID ? ' for Android' : ''} · yt-dlp ${h.ytdlp || '?'}`;
      $('#setVer').textContent = 'v' + h.version; $('#setVerTxt').textContent = v;
      state.health = h;
    } catch (e) {}
    const log = store.get('errlog', []);
    $('#errLog').hidden = !log.length;
    $('#errLog').textContent = log.length ? 'Recent problems:\n' + log.map(x => `${x.t}  ${x.url}\n  → ${x.msg}`).join('\n') : '';
  }
  $('#setUpdate').onclick = async () => {
    $('#setVerTxt').textContent = 'Checking…';
    await checkUpdate(true);
    const u = upInfo || {};
    $('#setVerTxt').textContent = u.configured === false ? 'Updates are not set up yet.' : u.error ? "Couldn't check. Are you online?" :
      u.newer ? `Version ${u.latest} is ready! Tap the black bar on the Download page.` : `You have the newest version (${u.current}).`;
    if (u.newer) showTab('apps');
  };
  $('#setReport').onclick = async () => {
    const h = state.health || {};
    let st = {};
    if (ANDROID) { try { st = await fetch('/api/selftest', { cache: 'no-store' }).then(r => r.json()); } catch (e) { } }
    const txt = ['Grabby problem report', `Version: ${h.version} ${ANDROID ? '(Android app)' : '(PC)'}`, `yt-dlp: ${h.ytdlp}`, `ffmpeg: ${h.ffmpeg ? 'yes' : 'no'}${st.ffmpeg ? ' (' + st.ffmpeg + ')' : ''}`, `YouTube helper: ${h.youtube ? 'yes' : 'no'}${st.qjs ? ' (' + st.qjs + ')' : ''}`, ...(ANDROID ? [`Signed in to sites: ${st.cookies ? 'yes' : 'no'}`] : []),
      `Device: ${navigator.userAgent}`, '', ...store.get('errlog', []).map(x => `${x.t}  ${x.url}\n  ${x.msg}`)].join('\n');
    $('#errLog').hidden = false; $('#errLog').textContent = txt;
    try { await navigator.clipboard.writeText(txt); toast('Report copied. Paste it in a message.'); } catch (e) { toast('Long-press the report to copy it'); }
  };
  $('#setClearHist').onclick = async () => {
    if (!state.history.length) return toast('History is already empty');
    if (await confirmBox('Clear history?', 'This removes the History list. Your saved videos stay.')) { state.history = []; store.set('history', []); updateHistCount(); renderHistory(); renderRecent(); toast('History cleared'); }
  };

  /* ------------------------------------------------ coffee widget + support (no personal names shown) */
  const cupPrice = () => (state.tips && +state.tips.cup_price) || 20;
  const total = () => state.cups * cupPrice();
  function syncCups() {
    $$('.cup-n').forEach(b => b.classList.toggle('on', +b.dataset.n === state.cups));
    $$('.cup-custom').forEach(i => { if (document.activeElement !== i) i.value = state.cups; });
    $$('.cup-total').forEach(t => t.textContent = '₱' + total().toLocaleString());
    $$('.cup-ic .ic').forEach(s => { s.classList.remove('play'); void s.getBoundingClientRect(); s.classList.add('play'); });
  }
  function setCups(n) {
    n = Math.max(1, Math.min(500, Math.round(+n) || 1));
    state.cups = n; store.set('cups', n); syncCups(); renderSupport(false);
    const ps = $('#paySteps'); if (ps) ps.hidden = true;
    if (n >= 5) flash('love', 2200, n >= 10 ? 'WOW. That is a LOT of coffee.' : 'So much coffee! You are amazing.');
  }
  $$('.cup-n').forEach(b => b.onclick = () => setCups(b.dataset.n));
  $$('.cup-custom').forEach(i => i.oninput = () => { if (i.value) setCups(i.value); });

  async function loadTips(refill = true) {
    try { state.tips = await api('/api/config'); } catch (e) { state.tips = null; return; }
    const t = state.tips;
    $('#tipCard').hidden = !t.configured;
    $('#sideTip').hidden = !t.configured || t.is_owner;
    if (t.message) $('#tipCardMsg').textContent = t.message;
    $('#ownerCard').hidden = !t.is_owner;
    $('#restartBtn').hidden = !t.is_owner;
    if (t.is_owner && refill) fillOwner();
    if (t.is_owner) showQr();
    syncCups();
    renderSupport();
  }
  function renderSupport(full = true) {
    const t = state.tips; if (!t) return;
    $('#supMsg').textContent = t.message || '';
    const amt = total().toLocaleString(), cards = [];
    const qrAmt = t.qrph ? `/api/tip/qr?amount=${total()}` : '';
    if (t.gcash_number || t.gcash_qr) cards.push(`
      <div class="pay"><div class="pay-h"><div class="pay-logo">G</div><div><b>GCash</b><small>${qrAmt ? `₱${amt} is filled in for you` : t.gcash_qr ? 'Scan the QR or send to the number' : 'Send to the number'}</small></div></div>
        ${qrAmt ? `<img class="qr" src="${qrAmt}" alt="GCash QR for ₱${amt}">` : t.gcash_qr ? `<img class="qr" src="${esc(t.gcash_qr)}?v=${Date.now() % 100000}" alt="GCash QR code">` : ''}
        ${qrAmt && PHONE ? `<button class="btn blue pill hov pay-go" data-pay="gcash">${ic('external')}Tip ₱${amt} with GCash</button>` : ''}
        ${t.gcash_number ? `<div class="num"><span>${esc(t.gcash_number)}</span><button class="btn ghost pill sm hov" data-copy="${esc(t.gcash_number)}">${ic('copy')}Copy</button></div>` : ''}
        <p class="how">${qrAmt ? (PHONE ? `Tap the button: Grabby saves this QR to your Gallery and opens GCash. Then <b>QR → Upload QR</b> and pick it. <b>₱${amt}</b> fills in by itself.` : `Scan with GCash, Maya or your bank app. <b>₱${amt}</b> fills in by itself.`) : `Open GCash → <b>${t.gcash_qr ? 'Scan QR' : 'Send Money'}</b> → enter <b>₱${amt}</b>.${t.gcash_qr ? ' On a phone, save the QR image and use “Upload QR” in GCash.' : ''}`}</p></div>`);
    if (t.maya_number || qrAmt) cards.push(`
      <div class="pay"><div class="pay-h"><div class="pay-logo">M</div><div><b>Maya</b><small>${qrAmt ? `₱${amt} is filled in for you` : 'Send to the number'}</small></div></div>
        ${qrAmt && PHONE ? `<button class="btn blue pill hov pay-go" data-pay="maya">${ic('external')}Tip ₱${amt} with Maya</button>` : ''}
        ${t.maya_number ? `<div class="num"><span>${esc(t.maya_number)}</span><button class="btn ghost pill sm hov" data-copy="${esc(t.maya_number)}">${ic('copy')}Copy</button></div>` : ''}
        <p class="how">${qrAmt ? (PHONE ? `Tap the button: Grabby saves the QR and opens Maya. Then <b>Scan → Upload QR</b> (the picture icon) and pick it. <b>₱${amt}</b> fills in by itself.` : `Scan the GCash QR with Maya: it works there too, with <b>₱${amt}</b> filled in.`) : `Open Maya → <b>Send money</b> → paste the number → <b>₱${amt}</b>.`}</p></div>`);
    if (t.paypal_me) cards.push(`
      <div class="pay"><div class="pay-h"><div class="pay-logo">P</div><div><b>PayPal</b><small>Card or PayPal account</small></div></div>
        <p class="how">The amount is filled in for you.</p>
        <a class="btn blue pill hov" target="_blank" rel="noopener" href="https://paypal.me/${encodeURIComponent(t.paypal_me)}/${total()}PHP">${ic('external')}Tip ₱${amt} with PayPal</a></div>`);
    if (t.kofi) cards.push(`
      <div class="pay"><div class="pay-h"><div class="pay-logo">${ic('coffee', 'loop')}</div><div><b>Ko-fi</b><small>Card or PayPal, no account needed</small></div></div>
        <a class="btn red pill hov" target="_blank" rel="noopener" href="https://ko-fi.com/${encodeURIComponent(t.kofi)}">${ic('external')}Open Ko-fi</a></div>`);
    if (t.custom_url) cards.push(`
      <div class="pay"><div class="pay-h"><div class="pay-logo">${ic('heart', 'loop')}</div><div><b>${esc(t.custom_label) || 'Support link'}</b><small>Opens in a new tab</small></div></div>
        <a class="btn ghost pill hov" target="_blank" rel="noopener" href="${esc(t.custom_url)}">${ic('external')}Open</a></div>`);
    const grid = $('#payGrid');
    if (full || grid.children.length !== cards.length) grid.innerHTML = cards.join('');
    else { // only refresh amounts without replaying card animations
      const tmp = document.createElement('div'); tmp.innerHTML = cards.join('');
      [...grid.children].forEach((c, i) => { c.querySelectorAll('.how, a.btn, img.qr, .pay-go, .pay-h small').forEach((n, k) => { const src = tmp.children[i].querySelectorAll('.how, a.btn, img.qr, .pay-go, .pay-h small')[k]; if (src) n.outerHTML = src.outerHTML; }); });
    }
    $('#payEmpty').hidden = cards.length > 0;
    $('#payEmpty p').textContent = t.is_owner ? "Tips aren't set up yet. Fill in your tip settings below." : "Tips aren't set up yet.";
    $$('#payGrid [data-copy]').forEach(b => b.onclick = async () => { try { await navigator.clipboard.writeText(b.dataset.copy); toast('Number copied'); playIcon(b); } catch (e) { toast(b.dataset.copy); } });
    $$('#payGrid [data-pay]').forEach(b => b.onclick = () => payWith(b.dataset.pay));
  }
  // ---- one tap to tip: save a QR with the amount in it, then open GCash / Maya
  const PAY_APPS = { gcash: ['GCash', 'com.globe.gcash.android', 'QR → Upload QR'], maya: ['Maya', 'com.paymaya', 'Scan → Upload QR (picture icon)'] };
  function payWith(app) {
    const [name, pkg, where] = PAY_APPS[app], amt = total(), file = `grabby-tip-${amt}-pesos.png`;
    count(`tip/${app}/${amt}/${myCountry()}`);
    const a = document.createElement('a');                    // 1. save the QR picture (Gallery / Downloads)
    a.href = `/api/tip/qr?amount=${amt}&fmt=png&dl=1`; a.download = file;
    document.body.appendChild(a); a.click(); a.remove();
    const steps = $('#paySteps');
    steps.innerHTML = `<b>Almost done! Thank you ♥</b><ol><li>${ANDROID ? 'Grabby saved' : 'Your phone saved'} <b>${file}</b>${ANDROID ? ' to your Gallery (Downloads/Grabby)' : ''}.</li><li>In ${name}, tap <b>${where}</b> and choose that picture.</li><li><b>₱${amt.toLocaleString()}</b> is filled in. Just confirm.</li></ol>`;
    steps.hidden = false; steps.scrollIntoView({ behavior: 'smooth', block: 'center' });
    setMood('love', `₱${amt.toLocaleString()}?! You're the best!`, 3500);
    setTimeout(() => {                                         // 2. open the app
      let opened = false;
      try { opened = ANDROID && window.VidGrabAndroid.openApp && window.VidGrabAndroid.openApp(pkg); } catch (e) { }
      if (!opened) toast(ANDROID ? `${name} isn't installed on this phone` : `Now open ${name} on your phone`);
    }, ANDROID ? 1500 : 300);
  }
  const CFG_FIELDS = { cfgMsg: 'message', cfgCup: 'cup_price', cfgAsk: 'ask_every', cfgGNum: 'gcash_number', cfgMaya: 'maya_number', cfgPaypal: 'paypal_me', cfgKofi: 'kofi', cfgCustomUrl: 'custom_url', cfgCustomLabel: 'custom_label' };
  function fillOwner() { Object.entries(CFG_FIELDS).forEach(([id, k]) => { $('#' + id).value = state.tips[k] ?? ''; }); }
  function showQr() {
    const img = $('#qrPreview');
    img.hidden = !state.tips.gcash_qr; if (state.tips.gcash_qr) img.src = state.tips.gcash_qr + '?v=' + Date.now();
    $('#qrRemove').hidden = !state.tips.gcash_qr;
  }
  $('#cfgSave').onclick = async () => {
    const body = {}; Object.entries(CFG_FIELDS).forEach(([id, k]) => body[k] = $('#' + id).value);
    try { await api('/api/config', body); toast('Tip settings saved'); playIcon($('#cfgSave')); await loadTips(); setMood('proud', 'Saved. Now people can buy you a coffee.', 4000); }
    catch (e) { toast(e.message); }
  };
  $('#qrFile').onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    const fd = new FormData(); fd.append('file', f);
    try {
      const r = await fetch('/api/qr', { method: 'POST', body: fd }); const d = await r.json();
      if (!r.ok || d.error) throw new Error(d.error || 'Upload failed');
      toast('QR uploaded'); await loadTips(false);
    } catch (err) { toast(err.message); }
    e.target.value = '';
  };
  $('#qrRemove').onclick = async () => { await fetch('/api/qr?remove=1', { method: 'POST' }); toast('QR removed'); loadTips(false); };

  function maybeAskTip() {
    const n = store.get('doneCount', 0) + 1; store.set('doneCount', n);
    const t = state.tips; if (!t || !t.configured || t.is_owner) return;
    const every = +t.ask_every || 0; if (!every || n % every) return;
    setTimeout(() => {
      $('#tipModalTitle').textContent = `You've grabbed ${n} video${n === 1 ? '' : 's'}!`;
      $('#tipModalMsg').textContent = t.message || 'If Grabby saved you time, a small tip keeps it free.';
      $('#tipModal').hidden = false; setMood('love');
    }, 2000);
  }
  $('#tipClose').onclick = $('#tipNo').onclick = () => { $('#tipModal').hidden = true; setMood('wink', 'No worries. Happy grabbing!', 2000); };
  $('#tipYes').onclick = () => { $('#tipModal').hidden = true; showTab('support'); };
  $('#tipModal').onclick = e => { if (e.target.id === 'tipModal') $('#tipModal').hidden = true; };

  /* ------------------------------------------------ apps tab / health */
  async function loadHealth() {
    try {
      const h = await api('/api/health');
      state.ffmpeg = h.ffmpeg; applyFfmpeg();
      $('#stFf').textContent = h.ffmpeg ? 'Installed' : 'Not installed';
      $('#stFf').className = h.ffmpeg ? 'ok' : 'no';
      $('#stYt').textContent = h.ytdlp;
    } catch (e) {}
  }
  $('#restartBtn').onclick = async () => {
    try { await api('/api/restart', {}); toast('Restarting Grabby…'); setMood('sleepy', 'Restarting... back in a second.');
      setTimeout(function wait() { fetch('/api/health').then(() => location.reload()).catch(() => setTimeout(wait, 700)); }, 1500);
    } catch (e) { toast(e.message); }
  };

  // shadow under the top bar once the page is scrolled
  addEventListener('scroll', () => $('.mtop').classList.toggle('scrolled', scrollY > 4), { passive: true });
  if ('serviceWorker' in navigator && !ANDROID) navigator.serviceWorker.register('/sw.js').catch(() => {});
  if (ANDROID) try {   // phone app: no PC setup steps, no ffmpeg on the phone
    $('#getAppCard').hidden = true; $$('#tab-apps .owner-only').forEach(c => { c.hidden = true; c.classList.add('android-off'); });
    const note = document.createElement('div'); note.className = 'box app-card';
    note.innerHTML = `<h3>${ic('phone')}You're using the Grabby app</h3><p>In Facebook, Instagram, TikTok or X, tap <b>Share → Grabby</b> and the download starts by itself. Every download is kept in <b>My Videos</b> and saved to your phone's <b>Downloads/Grabby</b> folder, so it shows in your Gallery. You can change this in <b>Settings</b>.</p><button class="btn ghost sm hov" id="chkUp"><i data-ic="repeat" class="sm"></i>Check for updates</button> <span class="hint" id="chkUpTxt"></span>`;
    setTimeout(() => { const b = $('#chkUp'); if (b) b.onclick = async () => { $('#chkUpTxt').textContent = 'Checking…'; await checkUpdate(true); $('#chkUpTxt').textContent = upInfo && upInfo.configured === false ? 'Updates are not set up yet.' : upInfo && upInfo.newer ? `Version ${upInfo.latest} is ready above!` : upInfo && upInfo.error ? "Couldn't check. Are you online?" : `You have the newest version (${upInfo ? upInfo.current : ''}).`; }; }, 0);
    $('#tab-apps .page-h').after(note);
    $('#ffWarn span').innerHTML = '<b>Phone app:</b> videos are saved as the best single file the site offers, and audio as M4A. MP3 conversion and trimming are in the PC version.';
  } catch (e) { console.warn('phone setup', e); }


  /* =====================================================================
     FLYING GRABBY – takes off from his spot, flies a curved path to a label,
     lands with a squash, points and gives a tip, then flies home.
     Principles: anticipation (crouch), arcs, banking into turns, trail,
     follow-through (antenna lags), squash & stretch on landing.
     ===================================================================== */
  const reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const flyer = document.createElement('div');
  flyer.className = 'flyer';
  flyer.innerHTML = `<div class="mascot mini" data-mood="flying">${mascot.innerHTML}</div><div class="fly-bubble" hidden></div>`;
  document.body.appendChild(flyer);
  const flyM = flyer.querySelector('.mascot'), flyB = flyer.querySelector('.fly-bubble');
  // ---- Incognito Grabby: in the Vault he puts on a fedora, shades, a trench coat and a fake moustache
  const spyHome = $('#vSpy');
  if (spyHome) spyHome.innerHTML = `<div class="mascot spy" data-mood="idle">${mascot.innerHTML}</div>`;
  const SPY_LINES = ['Shh… I saw nothing. 🕶️', 'Going incognito…', 'Nobody knows I\'m here.', 'Top secret stuff. My lips are sealed.', 'Disguise: ON. Name: Mr. Grab.'];
  let wasIncog = false;
  window.grabbyIncognito = on => {
    document.body.classList.toggle('incog', on);
    if (on && !wasIncog) {
      try { if (flyer.classList.contains('on') && typeof bubbleFly === 'function') { bubbleFly(pick(SPY_LINES)); setTimeout(() => { flyB.hidden = true; }, 2600); } } catch (e) { }
    }
    wasIncog = on;
  };
  let flying = false, abortFly = false, cur = { x: 0, y: 0 }, flip = 1;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const easeIO = t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  const fSize = () => innerWidth <= 760 ? 64 : 84;
  const bez = (a, b, c, d, t) => { const u = 1 - t; return { x: u*u*u*a.x + 3*u*u*t*b.x + 3*u*t*t*c.x + t*t*t*d.x, y: u*u*u*a.y + 3*u*u*t*b.y + 3*u*t*t*c.y + t*t*t*d.y }; };
  function setFly(m) { if (flyM.dataset.mood !== m) { flyM.dataset.mood = ''; void flyM.offsetWidth; flyM.dataset.mood = m; } }
  function place(p, tilt = 0) {
    cur = p;
    flyer.style.transform = `translate(${p.x.toFixed(1)}px,${p.y.toFixed(1)}px)`;
    flyM.style.setProperty('--tilt', tilt.toFixed(1) + 'deg');
    flyM.style.setProperty('--flip', flip);
    flyM.style.setProperty('--lag', (-tilt * 1.6).toFixed(1) + 'deg');
    if (!flyB.hidden && bubW) fitBubble();
  }
  // keep Grabby's speech bubble fully on screen while he flies around
  let bubW = 0, bubH = 0;
  function fitBubble() {
    const s = fSize(), cx = cur.x + s / 2, W = innerWidth;
    const left = cx - bubW / 2;
    let shift = 0;
    if (left + bubW > W - 8) shift = W - 8 - (left + bubW);
    if (left + shift < 8) shift = 8 - left;
    flyB.style.setProperty('--shift', Math.round(shift) + 'px');
    flyB.classList.toggle('below', cur.y - bubH < 6);
  }
  function homePoint() { const r = mascot.getBoundingClientRect(), s = fSize(); return { x: r.left + r.width / 2 - s / 2, y: r.top + r.height / 2 - s / 2 }; }
  function perch(el) {
    const r = el.getBoundingClientRect(), s = fSize();
    const x = Math.min(innerWidth - s - 6, Math.max(6, r.left + Math.min(r.width - s * .35, Math.max(s * .2, r.width * .78)) - s * .5));
    let y = r.top - s * .84;
    if (y < 6) y = r.bottom - s * .12;
    return { x, y };
  }
  const visible = el => {
    if (!el || !el.isConnected || !el.offsetParent) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.top > 40 && r.bottom < innerHeight - 30;
  };
  function trail(p) {
    const s = fSize(), d = document.createElement('div');
    d.className = 'trail'; document.body.appendChild(d);
    const x = p.x + s / 2 - 4 - flip * s * .1, y = p.y + s * .92;
    d.animate([{ transform: `translate(${x}px,${y}px) scale(1)`, opacity: .55 }, { transform: `translate(${x - flip * 10}px,${y + 14}px) scale(.2)`, opacity: 0 }], { duration: 520, easing: 'ease-out' }).onfinish = () => d.remove();
  }
  function puffs(p, n = 7) {
    const s = fSize(), cx = p.x + s / 2, cy = p.y + s * .95;
    for (let i = 0; i < n; i++) {
      const a = Math.PI + (i / (n - 1)) * Math.PI, d = document.createElement('div');
      d.className = 'puff'; document.body.appendChild(d);
      d.animate([{ transform: `translate(${cx - 6}px,${cy - 6}px) scale(.4)`, opacity: .9 }, { transform: `translate(${cx - 6 + Math.cos(a) * 34}px,${cy - 6 + Math.sin(a) * 10 + 6}px) scale(1.1)`, opacity: 0 }], { duration: 520, easing: 'cubic-bezier(.2,.8,.3,1)' }).onfinish = () => d.remove();
    }
  }
  function squash() {
    flyM.querySelector('svg').animate([{ transform: 'scale(1.28,.72) translateY(10px)' }, { transform: 'scale(.92,1.1) translateY(-6px)' }, { transform: 'none' }], { duration: 560, easing: 'cubic-bezier(.34,1.56,.64,1)' });
  }
  function flyTo(to, arc = 110, speed = 1) {
    const tgt = typeof to === 'function' ? to : () => to;
    to = tgt();
    const from = { ...cur }, dist = Math.hypot(to.x - from.x, to.y - from.y);
    const dur = Math.max(700, Math.min(1800, 500 + dist * 1.3)) / speed;
    const top = Math.min(from.y, to.y) - arc;
    const c1 = { x: from.x + (to.x - from.x) * .2, y: Math.max(8, top) }, c2 = { x: from.x + (to.x - from.x) * .8, y: Math.max(8, top + arc * .35) };
    setFly('flying');
    return new Promise(res => {
      const t0 = performance.now(); let prev = from, lastT = 0, vx = 0;
      const step = now => {
        const t = Math.min(1, (now - t0) / dur); to = tgt();
        const p = bez(from, c1, c2, to, easeIO(t));
        vx = vx * .8 + (p.x - prev.x) * .2;
        if (Math.abs(vx) > .4) flip = vx < 0 ? -1 : 1;
        const tilt = Math.max(-24, Math.min(24, vx * 2.2));
        const bob = Math.sin(now / 95) * 2.5 * Math.sin(Math.PI * t);
        place({ x: p.x, y: p.y + bob }, tilt);
        if (now - lastT > 38 && t < .97) { trail(p); lastT = now; }
        prev = p;
        if (t < 1) requestAnimationFrame(step); else { place(to, 0); res(); }
      };
      requestAnimationFrame(step);
    });
  }
  async function wait(ms) { const end = performance.now() + ms; while (performance.now() < end) { if (abortFly) return false; await sleep(80); } return true; }
  function bubbleFly(text) {
    flyB.textContent = text; flyB.hidden = false; flyB.classList.remove('below'); flyB.style.setProperty('--shift', '0px');
    flyB.style.animation = 'none';   // measure at full size, not mid pop-in
    const r = flyB.getBoundingClientRect();
    bubW = r.width; bubH = r.height;
    fitBubble();
    void flyB.offsetWidth; flyB.style.animation = '';
  }
  async function takeOff() {
    mascot.classList.add('crouch'); say(pick(LINES.away));
    await sleep(260);
    mascot.classList.remove('crouch');
    flip = 1; place(homePoint()); flyer.classList.add('on'); setFly('flying');
    mascot.classList.add('away'); puffs(cur);
  }
  async function landHome() {
    flyB.hidden = true;
    await flyTo(homePoint(), 80, 1.15);
    puffs(cur);
    flyer.classList.remove('on');
    mascot.classList.remove('away'); mascot.classList.add('land');
    setTimeout(() => mascot.classList.remove('land'), 600);
    setMood(baseMood(), false);
  }
  // fly to an element, point at it and say something, then come back
  async function visit(el, line, mood = 'pointing', stay = 3400) {
    if (!grabbyOn() || flyMode() === 'home') return;
    if (flying || reduceMotion || !visible(el) || !visible(mascot) || !$('#tab-download').classList.contains('on')) return;
    flying = true; abortFly = false;
    try {
      await takeOff();
      const target = perch(el);
      await flyTo(target);
      squash(); puffs(target, 5);
      const r = el.getBoundingClientRect();
      flip = (r.left + r.width / 2) < target.x + fSize() / 2 - 12 ? -1 : 1; place(target, 0);
      setFly(mood); el.classList.add('grabby-target'); bubbleFly(line);
      const stick = () => { if (el.isConnected) place(perch(el), 0); };
      addEventListener('scroll', stick, { passive: true }); addEventListener('resize', stick);
      await wait(stay);
      if (!abortFly) { setFly('wink'); await wait(500); }
      removeEventListener('scroll', stick); removeEventListener('resize', stick);
      el.classList.remove('grabby-target');
      await landHome();
    } finally { flying = false; abortFly = false; setTimeout(checkDock, 60); }
  }
  // triple-tap: a loop-the-loop around his spot
  async function joyride() {
    if (flying || reduceMotion) return;
    flying = true; abortFly = false;
    try {
      await takeOff();
      const h = homePoint(), R = Math.min(110, innerWidth / 5), dir = h.y - R * 1.6 < 10 ? -1 : 1;
      setFly('flying'); bubbleFly('Wheeeee!');
      const t0 = performance.now(), dur = 1700;
      await new Promise(res => {
        let lastT = 0;
        const step = now => {
          const t = Math.min(1, (now - t0) / dur), a = easeIO(t) * Math.PI * 2;
          const p = { x: h.x + Math.sin(a) * R, y: h.y - dir * (1 - Math.cos(a)) * R * .75 };
          flip = Math.cos(a) >= 0 ? 1 : -1;
          place(p, Math.cos(a) * 20 * flip);
          if (now - lastT > 38) { trail(p); lastT = now; }
          if (t < 1) requestAnimationFrame(step); else res();
        };
        requestAnimationFrame(step);
      });
      flyB.hidden = true; place(h, 0); squash(); puffs(h);
      flyer.classList.remove('on'); mascot.classList.remove('away'); mascot.classList.add('land');
      setTimeout(() => mascot.classList.remove('land'), 600);
      setMood('laughing', 'That was fun!', 2000);
    } finally { flying = false; setTimeout(checkDock, 60); }
  }
  flyM.addEventListener('click', () => {
    if (Date.now() - justDragged < 400) return;      // that was a drag, not a tap
    if (docked) { dockTap(); return; }
    setFly('laughing'); bubbleFly('Hehe! Okay, going home.'); abortFly = true;
  });

  /* ---------------------------------------------------------------------
     FOLLOW-ALONG – when you scroll his spot off screen, Grabby takes off
     and hovers in the corner so he's always in view. He leans and drifts
     with your scrolling, mirrors his moods, and flies home when his spot
     comes back. Tap him for a reaction; double-tap to fly back to the top.
     --------------------------------------------------------------------- */
  var docked = false, dockBusy = false, dockRAF = 0, dockMoodT, dockSayT;   // var: setMood may ask before this line runs
  var lastSY = scrollY, vel = 0, drift = 0, driftV = 0, lastMove = 0;
  const topInset = () => { const t = $('.mtop'); return t && getComputedStyle(t).position === 'sticky' ? t.getBoundingClientRect().bottom : 0; };
  const bottomInset = () => { const s = $('.side'); return s && getComputedStyle(s).position === 'fixed' ? s.getBoundingClientRect().height : 0; };
  function dockPoint() {
    const s = fSize(), m = innerWidth <= 760 ? 10 : 22;
    const p = store.get('dockPos', null);      // where you dragged him to (as a share of the screen)
    if (p) return { x: Math.max(4, Math.min(innerWidth - s - 4, p.x * innerWidth - s / 2)), y: Math.max(topInset() + 4, Math.min(innerHeight - bottomInset() - s - 4, p.y * innerHeight - s / 2)) };
    return { x: innerWidth - s - m, y: innerHeight - bottomInset() - s - (innerWidth <= 760 ? 14 : 26) };
  }
  // is his home spot (mostly) off screen?  hysteresis so he doesn't flap at the edge
  function homeGone() {
    if (flyMode() === 'always') return true;
    if (flyMode() === 'home') return false;
    if (!mascot.offsetParent) return true;
    const r = mascot.getBoundingClientRect(), top = topInset();
    return docked ? !(r.top > top - r.height * .1 && r.bottom < innerHeight - bottomInset() + r.height * .1)
                  : (r.bottom < top + r.height * .35 || r.top > innerHeight - bottomInset() - r.height * .35);
  }
  async function checkDock() {
    if (!grabbyOn()) { if (docked) dockOff(); return; }
    if (reduceMotion || dockBusy) return;
    const gone = homeGone();
    if (gone && !docked && !flying) await dockOut();
    else if (!gone && docked) await dockHome();
  }
  function dockOff() {           // Grabby switched off: vanish at once
    cancelAnimationFrame(dockRAF); clearTimeout(dockSayT);
    flyB.hidden = true; flyer.classList.remove('on', 'always');
    docked = false; flying = false; dockBusy = false;
    mascot.classList.remove('away');
  }
  async function dockOut() {
    flying = true; docked = true; dockBusy = true; abortFly = false;
    const s = fSize();
    let start;
    if (mascot.offsetParent) { const h = homePoint(); start = { x: h.x, y: Math.max(-s - 10, Math.min(innerHeight + 10, h.y)) }; }
    else start = { x: innerWidth + 10, y: dockPoint().y - 40 };
    flip = -1; place(start); flyer.classList.add('on'); setFly('flying');
    mascot.classList.add('away');
    await flyTo(dockPoint, 70, 1.35);
    squash();
    if (Math.random() < .55) dockSay(pick(LINES.follow));
    drift = driftV = 0; lastSY = scrollY; vel = 0;
    dockBusy = false;
    if (docked) dockLoop();
    setTimeout(checkDock, 60);   // he may already be needed back home
  }
  async function dockHome() {
    dockBusy = true; cancelAnimationFrame(dockRAF);
    clearTimeout(dockSayT); flyB.hidden = true;
    await flyTo(homePoint, 80, 1.3);
    puffs(cur); flyer.classList.remove('on');
    mascot.classList.remove('away'); mascot.classList.add('land');
    setTimeout(() => mascot.classList.remove('land'), 600);
    docked = false; flying = false; dockBusy = false;
    setMood(baseMood(), Math.random() < .5 ? pick(LINES.back) : false);
    setTimeout(checkDock, 60);
  }
  // hover in place, lean into the scroll and lag behind it like he's catching up
  function dockLoop() {
    cancelAnimationFrame(dockRAF);
    const step = now => {
      if (!docked || dockBusy) return;
      const dy = scrollY - lastSY; lastSY = scrollY;
      vel = vel * .82 + dy * .18;
      if (Math.abs(dy) > .5) lastMove = now;
      // spring: scrolling pulls him the other way, then he flies back to his spot
      const target = Math.max(-46, Math.min(46, -vel * 2.4));
      driftV = (driftV + (target - drift) * .12) * .78; drift += driftV;
      const d = dockPoint(), bob = Math.sin(now / 420) * 4, sway = Math.sin(now / 900) * 3;
      flip = -1;
      place({ x: d.x + sway, y: d.y + drift + bob }, Math.max(-22, Math.min(22, vel * 1.6)) + Math.sin(now / 700) * 2);
      dockRAF = requestAnimationFrame(step);
    };
    dockRAF = requestAnimationFrame(step);
  }
  function dockSay(text, ms = 2200) {
    clearTimeout(dockSayT); bubbleFly(text);
    dockSayT = setTimeout(() => { flyB.hidden = true; }, ms);
  }
  // mirror the big Grabby's moods while he's out
  function dockMirror(mood, line) {
    if (!docked || dockBusy) return;
    clearTimeout(dockMoodT);
    if (mood === 'idle' || mood === 'working') { setFly('flying'); return; }
    setFly(mood);
    if (line && ['done', 'happy', 'excited', 'sad', 'angry', 'shrug', 'love', 'surprised'].includes(mood)) dockSay(line, 2600);
    dockMoodT = setTimeout(() => { if (docked) setFly('flying'); }, 2400);
  }
  let dockTaps = [];
  function dockTap() {
    const now = Date.now(); dockTaps = dockTaps.filter(t => now - t < 380); dockTaps.push(now);
    clearTimeout(dockMoodT);
    if (dockTaps.length >= 2) { dockTaps = []; setFly('excited'); dockSay('Going up!', 1200); window.scrollTo({ top: 0, behavior: 'smooth' }); return; }
    let m; do { m = pick(TAP_POOL); } while (m === lastPick); lastPick = m;
    setFly(m); dockSay(pick(LINES[m] || LINES.follow), 1800);
    if (m === 'sneeze') setTimeout(() => puffs(cur, 9), 700);
    dockMoodT = setTimeout(() => { if (docked) setFly('flying'); }, 1900);
  }
  addEventListener('scroll', () => { if (!dockBusy) checkDock(); }, { passive: true });
  addEventListener('resize', () => { if (!dockBusy) checkDock(); });

  // tour stops: Grabby visits these now and then while you're idle
  const TOUR = [
    ['#menu .box-h h2', 'Pick MP4 for video or MP3 for music.'],
    ['#qualityChips', '1080p is the sweet spot. Best grabs up to 4K.'],
    ['#pasteBtn', "Tap Paste and I'll check your link."],
    ['.queue-card .box-h h2', 'Your downloads land right here.'],
    ['#adv summary', 'Trim, rename and more are in here.'],
    ['.platforms', 'I work with all of these, plus 1,800 more.'],
    ['#goBtn', 'Ready? Hit the big button!'],
    ['#tipCard', 'A coffee keeps my propeller spinning!'],
    ['.nav-btn[data-tab=history]', 'Everything you grabbed is saved in History.'],
  ];
  setInterval(() => {
    if (!grabbyOn() || flyMode() === 'home' || document.hidden || document.activeElement === urlIn || !$('#tipModal').hidden) return;
    const stops = () => TOUR.map(([s, l]) => [$(s), l]).filter(([el]) => visible(el));
    if (flyMode() === 'always') {      // always flying: he roams from his corner, then comes back
      if (!docked || dockBusy || dragging || Math.random() > .55) return;
      const st = stops();
      if (st.length && Math.random() < .8) { const [el, l] = pick(st); roam(el, l); } else roamLoop();
      return;
    }
    if (flying || activeCount() || mascot.dataset.mood !== 'idle') return;
    if (Math.random() > .3) return;
    const st = stops();
    if (st.length) { const [el, l] = pick(st); visit(el, l); }
  }, 12000);

  // always-flying mode: visit a button and come back to the corner
  async function roam(el, line) {
    dockBusy = true; cancelAnimationFrame(dockRAF); flyB.hidden = true;
    try {
      await flyTo(() => perch(el));
      squash(); puffs(cur, 5);
      const r = el.getBoundingClientRect();
      flip = (r.left + r.width / 2) < cur.x + fSize() / 2 - 12 ? -1 : 1; place(cur, 0);
      setFly('pointing'); el.classList.add('grabby-target'); bubbleFly(line);
      const stick = () => { if (el.isConnected) place(perch(el), 0); };
      addEventListener('scroll', stick, { passive: true });
      await sleep(3400);
      removeEventListener('scroll', stick);
      el.classList.remove('grabby-target'); flyB.hidden = true; setFly('wink'); await sleep(450);
      await flyTo(dockPoint, 70, 1.2);
    } finally {
      setFly('flying'); dockBusy = false;
      if (docked && grabbyOn()) dockLoop(); else checkDock();
    }
  }
  async function roamLoop() {        // a happy loop-the-loop near his corner
    dockBusy = true; cancelAnimationFrame(dockRAF);
    try {
      const h = dockPoint(), R = Math.min(70, innerWidth / 6), t0 = performance.now(), dur = 1500;
      setFly('laughing');
      await new Promise(res => {
        const step = now => {
          const t = Math.min(1, (now - t0) / dur), a = easeIO(t) * Math.PI * 2;
          flip = Math.cos(a) >= 0 ? -1 : 1;
          const p = { x: h.x - Math.sin(a) * R, y: h.y - (1 - Math.cos(a)) * R * .8 };
          place(p, Math.cos(a) * 18); if (t < 1) requestAnimationFrame(step); else res();
        };
        requestAnimationFrame(step);
      });
      place(h, 0); squash();
    } finally { setFly('flying'); dockBusy = false; if (docked && grabbyOn()) dockLoop(); }
  }

  // drag the flying Grabby anywhere; he remembers the spot
  let dragging = false, dragStart = null, justDragged = 0;
  flyM.style.touchAction = 'none';
  flyM.addEventListener('pointerdown', e => {
    if (!docked || dockBusy) return;
    dragStart = { x: e.clientX, y: e.clientY, ox: cur.x, oy: cur.y, id: e.pointerId };
    if (e.pointerType === 'mouse') e.preventDefault();          // no text selection while dragging
    document.documentElement.classList.add('grabby-drag');
  });
  addEventListener('pointermove', e => {
    if (!dragStart || e.pointerId !== dragStart.id) return;
    const dx = e.clientX - dragStart.x, dy = e.clientY - dragStart.y;
    if (!dragging && Math.hypot(dx, dy) < 8) return;
    if (!dragging) { dragging = true; dockBusy = true; cancelAnimationFrame(dockRAF); flyer.classList.add('dragging'); setFly('surprised'); flyB.hidden = true; }
    place({ x: dragStart.ox + dx, y: dragStart.oy + dy }, Math.max(-20, Math.min(20, dx / 6)));
  });
  addEventListener('pointerup', () => {
    if (dragging) {
      const s = fSize();
      store.set('dockPos', { x: (cur.x + s / 2) / innerWidth, y: (cur.y + s / 2) / innerHeight });
      flyer.classList.remove('dragging'); dragging = false; dockBusy = false; justDragged = Date.now();
      squash(); setFly('happy'); setTimeout(() => setFly('flying'), 900);
      drift = driftV = 0; dockLoop();
      $('#setFlyReset').hidden = false;
    }
    dragStart = null; document.documentElement.classList.remove('grabby-drag');
  });

  // small idle fidgets so Grabby never looks frozen
  setInterval(() => {
    if (mascot.dataset.mood !== 'idle' || flying || !grabbyOn()) return;
    const f = pick(['f-look', 'f-stretch', 'f-hop', 'f-twitch', 'f-blink', 'f-wave', 'f-look', 'f-blink']);
    mascot.classList.add(f); setTimeout(() => mascot.classList.remove(f), 1800);
  }, 7000);

  /* ------------------------------------------------ boot */
  setKind(state.kind);
  renderQualities();
  updateHistCount();
  renderRecent();
  updateQueueHead();
  syncCups();
  loadHealth();
  loadTips();
  loadLibrary();
  loadLater();
  loadOwner();
  applyGrabbySettings(); setTimeout(() => checkDock(), 600);
  loadAppInfo();
  setTimeout(() => checkUpdate(), 3000);
  applyOutfit(); updGift(); renderHugot();
  const P = new URLSearchParams(location.search);
  const incoming = P.get('url');
  if (incoming) {
    urlIn.value = incoming; $('#clearUrl').hidden = false;
    const k = P.get('kind') || (P.get('fmt') === 'mp3' ? 'audio' : P.get('fmt') === 'mp4' ? 'video' : null);
    if (k) setKind(k);
    history.replaceState(null, '', '/');
    if (P.get('auto') === '1') {
      setMood('surprised', P.get('shared') ? 'Got your shared link. Grabbing it now!' : 'Link received. Grabbing it now!');
      startDownload();
      loadPreview();
    } else {
      if (P.get('shared')) say('Got your shared link. Choose a format.');
      loadPreview();
    }
  } else {
    setTimeout(() => say("Hi! I'm Grabby. Paste a link and I'll grab it for you."), 300);
  }

  /* ------------------------------------------------ settings: anonymous counts */
  (() => {
    const el = $('#optStats'); if (!el) return;
    $('#statsRow').hidden = !COUNTER;
    el.checked = store.get('optStats', true);
    el.onchange = () => { store.set('optStats', el.checked); toast(el.checked ? 'Thanks for helping Grabby grow!' : 'Counts are off'); };
  })();

  /* ------------------------------------------------ ADMIN (owner only): downloads, visitors, tips */
  (() => {
    const tab = $('#tab-admin'); if (!tab) return;
    $$('.admin-entry').forEach(b => b.hidden = false);
    const peso = n => '₱' + Number(n || 0).toLocaleString(undefined, { maximumFractionDigits: 2 });
    const num = n => Number(n || 0).toLocaleString();
    const flag = cc => `<span class="cc">${/^[A-Z]{2}$/.test(cc || '') && cc !== 'XX' ? cc : '?'}</span>`;   // emoji flags don't show on Windows
    const CN = { PH: 'Philippines', US: 'United States', SG: 'Singapore', JP: 'Japan', KR: 'South Korea', AE: 'UAE', SA: 'Saudi Arabia', QA: 'Qatar', KW: 'Kuwait',
      HK: 'Hong Kong', TW: 'Taiwan', MY: 'Malaysia', ID: 'Indonesia', TH: 'Thailand', VN: 'Vietnam', IN: 'India', AU: 'Australia', GB: 'United Kingdom', CA: 'Canada', XX: 'Unknown', '??': 'Unknown' };
    const cname = cc => CN[cc] || cc;
    const APPN = { gcash: 'GCash', maya: 'Maya', paypal: 'PayPal', kofi: 'Ko-fi', other: 'Other' };
    const PLAT = { android: 'Android app', windows: 'Windows app', 'web-phone': 'Website on phones', 'web-pc': 'Website on computers' };
    let days = 30, info = null, stats = null, busy = false;

    const bars = (rows, total) => rows.length ? rows.map(r => `<div class="adm-row"><span class="adm-lbl">${r.label}</span>
      <span class="adm-bar"><i style="width:${total ? Math.max(3, 100 * r.n / total) : 0}%"></i></span><b>${r.show ?? num(r.n)}</b></div>`).join('') : '';
    function kpi(label, value, sub, icon) { return `<div class="kpi box"><span class="kpi-l">${ic(icon, 'xs')}${label}</span><b class="kpi-v">${value}</b><small>${sub || ''}</small></div>`; }

    function render() {
      const gh = (stats && stats.github) || [], c = stats && stats.counter, ev = c ? c.events : null;
      const apk = gh.reduce((a, r) => a + r.apk, 0), exe = gh.reduce((a, r) => a + r.exe, 0);
      const tips = (info && info.tips) || [], tipSum = tips.reduce((a, t) => a + (+t.amount || 0), 0);
      const sumObj = o => Object.values(o || {}).reduce((a, b) => a + b, 0);
      const taps = ev ? ev.tips.reduce((a, t) => a + t.count, 0) : null;
      const range = days === 365 ? 'last year' : `last ${days} days`;
      $('#admKpis').innerHTML =
        kpi('Total downloads', num(apk + exe), `${num(apk)} Android · ${num(exe)} Windows`, 'download') +
        kpi('Website visitors', c ? num(c.visitors) : '—', c ? range : 'connect GoatCounter', 'globe') +
        kpi('App opens', ev ? num(sumObj(ev.opens)) : '—', ev ? `once per person a day, ${range}` : 'connect GoatCounter', 'phone') +
        kpi('New installs', ev ? num(sumObj(ev.installs)) : '—', ev ? range : 'connect GoatCounter', 'sparkle') +
        kpi('Tip taps', taps == null ? '—' : num(taps), taps == null ? 'connect GoatCounter' : range, 'heart') +
        kpi('Tips received', peso(tipSum), `${tips.length} tip${tips.length === 1 ? '' : 's'} logged`, 'coffee');

      // downloads by version
      if (stats && stats.github_error) $('#admRel').innerHTML = `<p class="hint">${esc(stats.github_error)}</p>`;
      else if (gh.length) {
        const max = Math.max(...gh.map(r => r.apk + r.exe), 1);
        $('#admRel').innerHTML = `<div class="adm-legend"><span><i class="sw a"></i>Android</span><span><i class="sw w"></i>Windows</span></div>` + gh.map(r => `<div class="adm-row">
          <span class="adm-lbl">${esc(r.tag)}<small>${esc(r.date)}</small></span>
          <span class="adm-bar two"><i class="a" style="width:${100 * r.apk / max}%"></i><i class="w" style="width:${100 * r.exe / max}%"></i></span><b>${num(r.apk + r.exe)}</b></div>`).join('');
      } else $('#admRel').innerHTML = '<p class="hint">No releases yet.</p>';

      // visitors per day
      if (c && c.daily.length) {
        const mx = Math.max(...c.daily.map(d => d.n), 1);
        $('#admVisTot').textContent = num(c.visitors) + ' visitors';
        $('#admDaily').innerHTML = `<div class="adm-cols">${c.daily.map(d => `<span title="${esc(d.day)}: ${d.n}"><i style="height:${Math.max(2, 100 * d.n / mx)}%"></i></span>`).join('')}</div>
          <div class="adm-axis"><span>${esc(c.daily[0].day)}</span><span>max ${num(mx)} a day</span><span>${esc(c.daily[c.daily.length - 1].day)}</span></div>`;
      } else { $('#admVisTot').textContent = ''; $('#admDaily').innerHTML = `<p class="hint">${c ? 'No visitors in this range yet.' : 'Connect GoatCounter to see visitors.'}</p>`; }

      if (c && c.countries.length) {
        const t = c.countries.reduce((a, x) => a + x.count, 0);
        $('#admCountries').innerHTML = bars(c.countries.slice(0, 12).map(x => ({ label: `${flag(x.id)} ${esc(x.name)}`, n: x.count })), c.countries[0].count) +
          `<small class="hint">${num(t)} visits and app events, by country.</small>`;
      } else $('#admCountries').innerHTML = `<p class="hint">${c ? 'Nothing yet.' : 'Connect GoatCounter to see countries.'}</p>`;

      if (ev) {
        const rows = Object.entries(ev.opens).map(([k, n]) => ({ label: esc(PLAT[k] || k), n })).sort((a, b) => b.n - a.n);
        const grabs = Object.entries(ev.grabs).map(([k, n]) => ({ label: esc(k.charAt(0).toUpperCase() + k.slice(1)), n })).sort((a, b) => b.n - a.n).slice(0, 8);
        $('#admApp').innerHTML = (rows.length ? `<small class="adm-sub">Opens per day, by where</small>` + bars(rows, rows[0].n) : '<p class="hint">No app opens yet.</p>') +
          `<div class="adm-mini"><span>${ic('download', 'xs')}APK clicks on the website <b>${num(ev.apk)}</b></span><span>${ic('download', 'xs')}EXE clicks <b>${num(ev.exe)}</b></span></div>` +
          (grabs.length ? `<small class="adm-sub">Downloads made in Grabby, by site</small>` + bars(grabs, grabs[0].n) : '');
        if (ev.tips.length) {
          const by = (key, lab) => { const m = {}; ev.tips.forEach(t => { const k = t[key]; m[k] = (m[k] || 0) + t.count; });
            const r = Object.entries(m).map(([k, n]) => ({ label: lab(k), n })).sort((a, b) => b.n - a.n); return bars(r, r[0].n); };
          const value = ev.tips.reduce((a, t) => a + t.amount * t.count, 0);
          $('#admTapWrap').innerHTML = `<div class="adm-mini"><span>Tapped amounts add up to <b>${peso(value)}</b></span></div>
            <div class="adm-3"><div><small class="adm-sub">By amount</small>${by('amount', k => peso(k))}</div>
            <div><small class="adm-sub">By app</small>${by('app', k => esc(APPN[k] || k))}</div>
            <div><small class="adm-sub">By country</small>${by('country', k => `${flag(k)} ${esc(cname(k))}`)}</div></div>`;
        } else $('#admTapWrap').innerHTML = '<p class="hint">No tip taps in this range yet.</p>';
        $('#admPages').innerHTML = c.pages.length ? bars(c.pages.slice(0, 10).map(x => ({ label: esc(x.title || x.path) + `<small>${esc(x.path)}</small>`, n: x.count })), c.pages[0].count) : '<p class="hint">No page views yet.</p>';
      } else {
        ['#admApp', '#admPages'].forEach(id => $(id).innerHTML = '<p class="hint">Connect GoatCounter to see this.</p>');
        $('#admTapWrap').innerHTML = '<p class="hint">Connect GoatCounter to count tip taps.</p>';
      }
      const errs = [stats && stats.counter_error].filter(Boolean);
      $('#admErr').hidden = !errs.length; $('#admErr').textContent = errs.join(' ');
      $('#admSetup').hidden = !!(info && info.has_token) && !errs.length;
      $('#admWhen').textContent = stats ? 'Updated ' + new Date(stats.time * 1000).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : '';
      renderTips();
    }

    function renderTips() {
      const tips = (info && info.tips) || [];
      $('#admTipTot').textContent = peso(tips.reduce((a, t) => a + (+t.amount || 0), 0));
      if (!tips.length) { $('#admTips').innerHTML = '<p class="hint">No tips logged yet. Add the ones from your GCash / Maya history above.</p>'; return; }
      const byC = {}; tips.forEach(t => byC[t.country] = (byC[t.country] || 0) + (+t.amount || 0));
      $('#admTips').innerHTML = `<div class="adm-mini">${Object.entries(byC).sort((a, b) => b[1] - a[1]).map(([k, v]) => `<span>${flag(k)} ${esc(cname(k))} <b>${peso(v)}</b></span>`).join('')}</div>
        <table><thead><tr><th>Date</th><th>Name</th><th>Amount</th><th>App</th><th>Country</th><th>Note</th><th></th></tr></thead><tbody>` +
        tips.map(t => `<tr><td>${esc(t.date)}</td><td>${esc(t.name) || '<span class="hint">Anonymous</span>'}</td><td><b>${peso(t.amount)}</b></td>
          <td>${esc(APPN[t.app] || t.app)}</td><td>${flag(t.country)} ${esc(cname(t.country))}</td><td>${esc(t.note)}</td>
          <td><button class="icon-btn sm hov" data-tdel="${esc(t.id)}" title="Delete">${ic('trash', 'xs')}</button></td></tr>`).join('') + '</tbody></table>';
      $$('#admTips [data-tdel]').forEach(b => b.onclick = async () => {
        if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.classList.add('red'); toast('Tap again to delete'); setTimeout(() => { b.dataset.sure = ''; b.classList.remove('red'); }, 2500); return; }
        try { const r = await api('/api/admin/tips', { delete: b.dataset.tdel }); info.tips = r.tips; render(); toast('Deleted'); } catch (e) { toast(e.message); }
      });
    }

    async function load(force) {
      if (busy) return; busy = true; $('#admRefresh').classList.add('spin');
      try {
        info = await api('/api/admin');
        $('#admSite').value = info.site || ''; $('#admTokHint').textContent = info.has_token ? `(saved ${info.token_hint})` : '';
        render();
        stats = await api(`/api/admin/stats?days=${days}${force ? '&force=1' : ''}`);
        render();
      } catch (e) { toast(e.message); }
      busy = false; $('#admRefresh').classList.remove('spin');
    }
    window.grabbyAdmin = () => load(false);
    $('#admRefresh').onclick = () => load(true);
    $$('#admRange button').forEach(b => b.onclick = () => { $$('#admRange button').forEach(x => x.classList.toggle('on', x === b)); days = +b.dataset.d; load(false); });
    $('#admSave').onclick = async () => {
      try { await api('/api/admin/settings', { site: $('#admSite').value.trim(), token: $('#admTok').value.trim() || null }); $('#admTok').value = ''; toast('Connected'); load(true); }
      catch (e) { toast(e.message); }
    };
    // tip form
    const CCS = ['PH', 'US', 'CA', 'AU', 'GB', 'SG', 'JP', 'KR', 'HK', 'TW', 'MY', 'ID', 'TH', 'VN', 'IN', 'AE', 'SA', 'QA', 'KW', '??'];
    $('#tCountry').innerHTML = CCS.map(c => `<option value="${c}">${cname(c)}</option>`).join('');
    $('#tDate').value = new Date().toISOString().slice(0, 10);
    $('#tAdd').onclick = async () => {
      const body = { date: $('#tDate').value, name: $('#tName').value, amount: $('#tAmt').value, app: $('#tApp').value, country: $('#tCountry').value, note: $('#tNote').value };
      try { const r = await api('/api/admin/tips', body); info.tips = r.tips; ['#tName', '#tAmt', '#tNote'].forEach(i => $(i).value = ''); render(); toast('Tip added. Thank you, ' + (body.name || 'kind stranger') + '!'); playIcon($('#tAdd')); }
      catch (e) { toast(e.message); }
    };
  })();
})();
