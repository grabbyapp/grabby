// Grabby service worker: makes the app installable and caches the app shell.
const CACHE = 'grabby-v6';
const SHELL = ['/', '/static/app.css', '/static/app.js', '/static/icons/icon-192.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  // never cache API calls, downloads or the share redirect
  if (e.request.method !== 'GET' || url.pathname.startsWith('/api/') || url.pathname === '/share') return;
  // network first, fall back to cache when the computer is off
  e.respondWith(
    fetch(e.request).then(r => {
      const copy = r.clone();
      caches.open(CACHE).then(c => c.put(e.request, copy));
      return r;
    }).catch(() => caches.match(e.request).then(r => r || caches.match('/')))
  );
});
